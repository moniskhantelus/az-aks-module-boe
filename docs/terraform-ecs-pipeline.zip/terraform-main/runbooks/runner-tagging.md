# EIC Catalog Terraform Multi-Cloud Runner Tagging

- [EIC Catalog Terraform Multi-Cloud Runner Tagging](#eic-catalog-terraform-multi-cloud-runner-tagging)
  - [Overview](#overview)
    - [Multiple runner types](#multiple-runner-types)
    - [Multiple clouds](#multiple-clouds)
  - [Tagging Pattern](#tagging-pattern)
    - [Provide a list of runners tags - Responsibility of Project Team](#provide-a-list-of-runners-tags---responsibility-of-project-team)
    - [Establish and integrate the provided runners tags to the Terraform pipeline template - Responsibility of EIC Catalog](#establish-and-integrate-the-provided-runners-tags-to-the-terraform-pipeline-template---responsibility-of-eic-catalog)
  - [Usage](#usage)
    - [AWS](#aws)
    - [Azure/GCP](#azuregcp)

## Overview

The Terraform module and service pipelines are designed to support Terraform deployments into AWS, Azure and GCP in the EIC environemnts. This runbook is intended to provide information on how to use the pipelines to run on shared or group GitLab runners as required by the requirements of each pipeline.

### Multiple runner types

GitLab Runners in the EIC environment are owned and managed by different teams depends on type:

- **Shared Runners**: Boeing-owned Runner Kubernetes clusters.
- **Group Runners**: Deployed on demand. Owned and managed by the Project team.
- **Specific Runners**: Similar to Group Runners. Deployed on demand. Owned and managed by the Project team.

### Multiple clouds

The GitLab Runner tagging pattern needs to be dynamic and easily customized for different cloud requirements:

- **AWS**: Always requires group or specific runners to use the Instance Profile of the runner since AWS Access Keys are not allowed in the EIC environment.
- **Azure**: Can leverage K8s runners but might requires group/specific runners in case of specific network requirement.
- **GCP**: Can leverage K8s runners but might requires group/specific runners in case of specific network requirement.

## Tagging Pattern

To serve these various scenarios the pipeline was designed to handle custom runner tags.

### Provide a list of runners tags - Responsibility of Project Team

This aspect is changed per project's context since the group and specific runners are owned by the project team. Each project team might organize their runner tags differently so the tag list should be defined at a project's terraform service level.

- From the terraform service template, the project team is responsible for providing a list of runner tags corresponding to the project's setup.
- The tags list does not have to be job-specific unless it is neccessary.

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_1
    file: service/pipeline.yml

default:
  tags:
    - aws
    - terraform
    - docker
    - any-project-specified-tag
```

### Establish and integrate the provided runners tags to the Terraform pipeline template - Responsibility of EIC Catalog

ECS Catalog manages and develops the core terraform pipeline template. The pipeline template is shared across multiple teams so the template itself does not contain any specific runner tags. It only orchestrates stage/job definition and functionality; establishes the provided terraform-tags list to corresponding jobs.

- **For terraform-related jobs**, runner tags can be inherited from service pipeline level via `default: / tags:` if defined. If there is a tf job that needs to be added or deleted, ECS Catalog team will be responsible to populate the change. No action needed from Project team.
- **For non-terraform-related jobs**, runner tags are set to default to blank which results in Boeing K8s runners to be always picked unless those jobs are specifically overwritten with tags specified.

```yml
# -------------------------
# Terraform jobs
# -------------------------
validate_tf:
  # inherit default runner tags from service pipeline
  # otherwise use Boeing k8s

apply_tf:
  # inherit default runner tags from service pipeline
  # otherwise use Boeing k8s

new_tf_job:
  # inherit default runner tags from service pipeline
  # otherwise use Boeing k8s
  # no action needed from project team to pickup the newly added job

# -------------------------
# Non-terraform jobs
# -------------------------

checkout_shared_pipeline_scripts:
  # always pickup k8s runners
  tags:
    - ''

secret_detection:
  # always pickup k8s runners
  tags:
    - ''

other_jobs:
  # always pickup k8s runners
  tags:
    - ''
```

## Usage

### AWS

A dedicated GitLab Runner with a proper IAM Role is required to be set up in the target AWS account to be able to integrate this pipeline template. Any AWS Access Key will be force eliminated on the CI pipeline due to EIC Security Policies. The following sample describes GitLab Runner tags configuration for AWS terraform-related jobs:

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_1
    file: /module/pipeline.yml

default:
  tags:
    - aws
    - terraform
    - docker
```

### Azure/GCP

Most ECS Azure and GCP deployments can be provisioned on the Boeing GitLab Kubernetes Cluster Shared Runners using a service principal. Therefore, no additional GitLab Runner configuration is required.

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_1
    file: /service/pipeline.yml
```

A private GitLab Runner with additional network configuration and GitLab Runner tags may be required for a deployment that requires specific network access/configuration (private endpoint, vnet peering, etc). The following example describes a GitLab Runner tags configuration for terraform-related jobs in Azure that require specific network access/configuration:

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_1
    file: /service/pipeline.yml

default:
  tags:
    - azure
    - terraform
    - docker
```

Project teams can also overwrite runner tags at job level in the terraform service pipeline. When there is any change from the ECS Catalog tf pipeline to add/remove/rename a job, the child pipeline has to be updated accordingly.

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_1
    file: /service/pipeline.yml

default:
  tags:
    - azure
    - terraform
    - docker

terratest:
  tags:
    - azure
    - terraform
    - shell
```
