# Onboarding to Coverity with Terraform GitLab Pipeline Template  
  
This document provides a step-by-step guide to onboarding to Coverity when using the Catalog Terraform GitLab pipeline template. Follow the steps below to create a Coverity project, request the service account, ensure that the service account is added to the correct Active Directory (AD) group and integrate Coverity into your pipeline.  

---  
  
## Request a Project in Coverity  
  
To create a new project in Coverity using ATOMS, please refer to the documentation and the video linked below for guidance.
  
* [Provision Project on ATOMS Document](https://dev-sec-docs.web.boeing.com/coverity-overview/#step-1-provision-project-on-atomshttpsatomswebboeingcom)
* [Coverity Video Series Episode 1: Provisioning a new Coverity Connect Project](https://insite.web.boeing.com/culture/viewMedia.do?mediaId=177521)
  
ATOMS will create a project and two streams associated with the project, a Development Stream (Dev), and a Production Stream (Prod). Only the production stream will be tracked for Information Technology (IT) compliance and imported into CAIRO.

In addition to the streams, AD groups that control access to them will also be provisioned and membership to the groups can be managed through [ADTools](https://adtools.web.boeing.com/).

![Coverity Streams](references/sample-coverity-streams.png)

Once the project is created, make sure to note down the project and streams details, as you will need them during pipeline integration.

## Access Coverity Connect

Coverity Connect is the central issue management system for Coverity.

If you have already used ATOMS to provision your account, determine the Coverity Connect Server your project is assigned to by visiting ATOMS to find out which server your project is on.

![Coverity Project](references/sample-coverity-project.png)

Refer to the documentation below for the URLs for the Enteprise Coverity Connect servers. Make sure to note down Coverity Connect Backend URL, as you will need them during pipeline integration.

* [Coverity Server URLs](https://dev-sec-docs.web.boeing.com/coverity-overview/#coverity-connect)
  
## Request a NOS AD Service Account  
  
To scan your project with Coverity, request a NOS AD service account through [MARS](https://mars.web.boeing.com/). Note that the owner of the service account should have an NOS AD ADM account and badge to be able to manage the service account in CyberArk.

MARS > Request/Manage Accounts > Request Accounts > Request a Non-standard (non-enduser) Windows Account > Controlled Service Account (SVC) > Next -> Provide the required information in Form -> Submit

Ensure the service account is added to all necessary Active Directory groups associated with any/all Coverity projects you’ll be using it for.

**Please note** that scanning is limited to the `ADMIN` AD group. Ensure that your service account is added to this group by your project's focal. The synchronization between the AD server and Coverity may take up to 24 hours, during which your service account won't be able to perform scans.

### Generate the Authentication Key using Service Account

To generate the Authentication Key that is used in the pipeline, please follow the steps outlined below.

* Ensure coverity analysis is downloaded and added to the path. Please refer to the document [here](https://dev-sec-docs.web.boeing.com/coverity-overview/#option-1-desktop-analysis) for guidance.
* Use this command: `cov-manage-im --url https://gide-phxld<x>.vmpc1.cloud.boeing.com -user <svc_account_name> --mode auth-key --create --output-file auth-key-<x>`
* Hit return and enter the password when prompted
* Save the keyfile which is now `auth-key-<x>`

Please store the key file in a secure location, as it is required for pipeline integration.

## Integrate Coverity into Terraform Pipeline.

### Prerequisites

Before starting, ensure you have proper GitLab CI/CD variables configured in your group or repository. Please refer `Variables` section in [README](../README.md) to understand the required and optional CI variables for Coverity, along with their descriptions to know their purpose.

### Configuring Coverity in GitLab CI/CD Pipeline

If you are using the module or service pipeline, the Coverity job is already integrated. For more details, please refer to the README of the [module](../module/README.md) pipeline or [service](../service/README.md) pipeline. Additionally, refer to the README in the [shared](../.shared/README.md) pipeline to understand how to use `.coverity` extends in downstream pipelines as utilities.

## Support and Assistance

If you encounter any issues or need assistance during the onboarding process, please refer to the appropriate support channels below:

* **Pipeline Issues**: For any issues related to the pipeline setup, execution, or configuration, please contact the Catalog Support Team through [ECS Catalog](https://mattermost.web.boeing.com/devhub/channels/ecs-catalog) Mattermost channel.

* **Coverity Issues**: If you face any issues related to Coverity, such as stream configuration, user access, permissions, authentication: or server-related concerns, please reach out to [Coverity](https://mattermost.web.boeing.com/devhub/channels/coverity) Mattermost channel.

--- 

# References

*  <https://dev-sec-docs.web.boeing.com/coverity-overview>