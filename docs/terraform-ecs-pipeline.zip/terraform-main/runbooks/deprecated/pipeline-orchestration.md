# ECS Terraform Pipeline Orchestration

## Overview

The ECS Terraform Pipeline supports multiple environment deployments in a single repository with utilized pipeline implementation. This runbook is intended to provide information on how to manage the pipeline as well as taking avantage to extend the Terraform pipeline to multiple deployments in different environments/accounts/subscriptions.

- [[DEPRECATED] ECS Terraform Pipeline Orchestration](#deprecated-ecs-terraform-pipeline-orchestration)
  - [Overview](#overview)
  - [Key Features](#key-features)
    - [Default pipeline](#default-pipeline)
    - [Extendable pipeline](#extendable-pipeline)
  - [Repository Structure](#repository-structure)
    - [Example Deployments (examples/*) - Recommended for Module Template](#example-deployments-examples---recommended-for-module-template)
    - [Environmental Deployments (environments/*) - Recommended for Service Template](#environmental-deployments-environments---recommended-for-service-template)
  - [Pipeline Implementation](#pipeline-implementation)
    - [Environmental Deployments (environments/*)](#environmental-deployments-environments)
      - [Default Pipeline](#default-pipeline-1)
      - [Extended Pipeline](#extended-pipeline)
    - [Example Deployments (examples/*)](#example-deployments-examples)
      - [Default Pipeline](#default-pipeline-2)
      - [Extended Pipeline](#extended-pipeline-1)
  - [Use cases](#use-cases)
    - [Environmental Deployments (environments/*)](#environmental-deployments-environments-1)
      - [Terraform Service - Use case #1](#terraform-service---use-case-1)
      - [Terraform Service - Use case #2](#terraform-service---use-case-2)
      - [Terraform Service - Use case #3](#terraform-service---use-case-3)
    - [Example Deployments (examples/*)](#example-deployments-examples-1)
      - [Terraform Module - Use case #1](#terraform-module---use-case-1)
      - [Terraform Module - Use case #2](#terraform-module---use-case-2)

## Key Features

### Default pipeline

The EIC Terraform Pipeline provides an embedded single deployment pipeline with minimum declaration in the Terraform repository:

```yml
# Module pipeline
include:
  - project: ecs-catalog/pipelines/terraform
    ref: module_3.1
    file: /service/pipeline.yml
```

```yml
# Service pipeline using environments/*
include:
  - project: ecs-catalog/pipelines/terraform
    ref: module_3.1
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: "environments/ci" 
```

```yml
# Service pipeline using examples/*
include:
  - project: ecs-catalog/pipelines/terraform
    ref: module_3.1
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: "examples/complete" 
```

### Extendable pipeline

The EIC Terraform Pipeline offers job extensions that are utilized and ready to be integrated. Those job extensions take job variables as function inputs to minimize coding effort of the Project Team. Instead, Project Teams can focus on pipeline orchestration with multiple jobs, environments and flows. For more details, refer to the [Pipeline Implementation](#pipeline-implementation) section.

```yml
# Example of a job extension
apply:dev:
  extends: .apply
  variables:
    TF_TEMPLATE_DIR: examples/complete
    TF_VAR_FILE: examples/complete/terraform.tfvars
    TF_TERRATEST_DIR: tests/examples/complete
```

## Repository Structure

The following tree describes the standard structure of an EIC Terraform Service repository:

> **Important Note:** `environments/*` and `examples/*` are 2 different deployment methods that are both supported by the EIC Terraform pipeline, however, for most cases only one of the 2 methods is sufficient to be applied in a repository. See table below that briefly describes major differences between the 2 methods.

```
.
├── environments                            - Deployment input dir (Recommended)
│   ├── ci                                  - Deployment input for CI environment
│   │   ├── backend.tf                      - *Extended environmental terraform configuration
│   │   ├── terraform.tfvars                - Deployement input variables
│   │   └── terraform.tfvars.sh             - *Extended input handler
│   ├── dev                                 - Deployment input for DEV environment
│   │   ├── backend.tf
│   │   ├── terraform.tfvars
│   │   └── terraform.tfvars.sh
├── examples                                - Deployment test (Traditional)
│   └── complete
│       ├── main.tf
│       ├── outputs.tf
│       ├── README.md
│       ├── terraform.tfvars
│       ├── variables.tf
│       └── versions.tf
├── tests                                   - Terratest dir for integration test / deployment verification
│   ├── utilities
│   │   └── backend.go                      - An utility to setup remote backend for terratest
│   ├── environments                        - Terratest for the coressponding environments/<name> deployment
│   │   ├── ci
│   │   │   └── ci_test.go
│   │   └── dev
│   │       └── dev_test.go
│   ├── examples                            - Terratest for the corressponding examples/<name> deployment
│   │   └── complete
│   │       └── example_test.go
│   └── README.md
├── .gitignore
├── .gitlab-ci.yml
├── .terraform-docs.yml
├── markdown-lint.config
├── metadata.json
├── ARCHITECTURE.md
├── CHANGELOG.md
├── LICENSE
├── README.md
├── variables.tf                            - Deployment input declaration
├── main.tf                                 - Main terraform template
├── outputs.tf                              - Deployment outputs
└── versions.tf                             - Module package management
```

|                         | `environments/*`                                                                                                                                              | `examples/*`                                                                                                                                                                                                                             |
| ----------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| *Repository Structure*  | Provides an extended configuration and deployment input of the main template in root.                                                                         | Provides a full deployment testing context with the main template in root participated as a module in the example template.                                                                                                              |
| *Pros*                  | Avoid duplication of template `variables`, `outputs`, `versions`, etc. That helps to keep the deployment template clean and easy to maintain.                 | Allows bigger context of deployment testing. The main template in root can participate in the deployment context as a module along with other side deployments.                                                                          |
| *Cons*                  | Cannot be applied for template that requires dynamic prequisite deployments.                                                                                  | Duplicates `variables`, `outputs`, `versions` and other files that costs maintainance effort.                                                                                                                                            |
| *Pipeline Availability* | Terraform `service` pipeline only.                                                                                                                            | Both Terraform `service` and `module` pipeline.                                                                                                                                                                                          |
| *When to use?*          | Best for Terraform Service template when the main template itself is a complete deployment context. Eg: Baseline Linux, Baseline Windows, GitLab Runner, etc. | Best for Terraform Module template where the main template itself is NOT a complete deployment context. Eg: `EBS` module template development requires a CI EC2 instance as a dynamic prequisite deployment for the integration testing. |

### Example Deployments (examples/*) - Recommended for Module Template

The `examples/*` is a common testing method for the Terraform community. The example template can simulate a testing deployment context and then includes the main template (in the root directory) to perform a full deployment test.

This method is recommended for Terraform template that cannot be provisioned alone by itself. It usually requires another dynamic prequisite deployment to be deployed along with. For example, the EBS volume module template provides an EBS deployment. But the EBS volume cannot be provisioned by itself and requires an EC2 instance as a prequisite to test with. The example template will first deploy an EC2 instance, then deploy the EBS module template to attach to the EC2 instance. Reference: [Catalog AWS EBS Volume Terraform Module Example Deployment](https://git.web.boeing.com/ECS-Catalog/iac/terraform/aws/terraform-aws-ebs-volume/-/blob/main/examples/complete/main.tf)

Downside of this method is the code redundancy between the example template and the main template (in the root directory); it takes time and effort to maintain.

### Environmental Deployments (environments/*) - Recommended for Service Template

The `environments/*` is a custom method to deploy Terraform Service templates in the most simplified way. The main template of the service itself is a complete deployment context that includes all the resources needed for the deployment. *Eg: Baseline Linux, Baseline Windows, GitLab Runner, etc*. The only missing part in the picture is the Cloud provider configuration *(eg: AWS default region, Azure Gov cloud declaration)* and the deployment input (tfvars) to the template. With that approach, the `environments/*` directory provides the following files:

- `backend.tf`:
  - This file contains the provider config per environment and enable remote state config on demand.
  - AWS default region for dev/ci/test, Azure default Gov Cloud, etc.
  - Enable S3 backend for AWS, Enable Storage backend for Azure, etc.
- `terraform.tfvars`:
  - non-sensitive deployment input.
- `terraform.tfvars.sh`: 
  - sensitive deployment input. This file only export TF_VAR_name with value of CI variables. No actual plaintext for sensitive information. The pipeline needs extra handling for this every time we run tf jobs.
  - overwritable deployment input
  - extra handling for variables and other default pipeline configuration in job level

## Pipeline Implementation

> ***Note**: For more information about Terraform pipeline tagging management, refer to [Runner Tagging documentation](runner-tagging.md).*

### Environmental Deployments (environments/*)

#### Default Pipeline

The following table describes variables that control the default built-in deployment:

| CI Variables              | Required | Default Value | Description                                                                                                                                                                                      |
| ------------------------- | -------- | ------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `TF_DEFAULT_PIPELINE_DIR` | `false`  | *N/A*         | Relative path to the extended environmental terraform template. If this variable is unset, the default deployment will be omitted.<br>*Eg: environments/ci, environments/dev, environments/prod* |

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_3.1
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: "environments/ci" 
```

#### Extended Pipeline

The following table describes job-variables that control the extended deployments:

| CI Variables               | Required | Default Value                                                                   | Description                                                                                                                                                |
| -------------------------- | -------- | ------------------------------------------------------------------------------- | ---------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `TF_EXTENDED_TEMPLATE_DIR` | `true`   | *N/A*                                                                           | Relative path to the extended environmental terraform template.<br>*Eg: environments/dev, environments/prod*                                               |
| `TF_TEMPLATE_DIR`          | `false`  | `${CI_PROJECT_DIR}`                                                             | The directory that contains main terraform template.                                                                                                       |
| `TF_VAR_FILE`              | `false`  | `${TF_EXTENDED_TEMPLATE_DIR}/terraform.tfvars`                                  | The deployment input value.                                                                                                                                |
| `TF_TERRATEST_DIR`         | `false`  | `tests/$(realpath --relative-to=${CI_PROJECT_DIR} ${TF_EXTENDED_TEMPLATE_DIR})` | Relative path to the terratest directory of the corresponding environment.<br>*Eg: tests/environments/ci, tests/environments/dev, tests/environments/prod* |

For more information, refer to [Use cases](#use-cases)

### Example Deployments (examples/*)

#### Default Pipeline

The following table describes variables that control the default built-in deployment:

| CI Variables              | Required | Module Pipeline Default Value | Service Pipeline Default Value | Description                                                                                                                                                                                |
| ------------------------- | -------- | ----------------------------- | ------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| `TF_DEFAULT_PIPELINE_DIR` | `false`  | `examples/complete`           | *N/A*                          | Relative path to the default example template. In service pipeline, if this variable is unset, the default deployment will be omitted.<br>*Eg: examples/complete, examples/complete/linux* |

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: module_3.1
    file: /service/pipeline.yml
```

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_3.1
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_EXAMPLE_DIR: examples/complete
```

#### Extended Pipeline

The following table describes job-variables that control the extended deployments:

| CI Variables       | Required | Default Value                                                          | Description                                                                                             |
| ------------------ | -------- | ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------- |
| `TF_TEMPLATE_DIR`  | `true`   | *N/A*                                                                  | The directory that contains example terraform template.                                                 |
| `TF_VAR_FILE`      | `false`  | `${TF_TEMPLATE_DIR}/terraform.tfvars`                                  | The deployment input value.                                                                             |
| `TF_TERRATEST_DIR` | `false`  | `tests/$(realpath --relative-to=${CI_PROJECT_DIR} ${TF_TEMPLATE_DIR})` | Relative path to the terratest directory of the coreessponding example.<br>*Eg: tests/examples/complete |

For more information, refer to [Use cases](#use-cases)

## Use cases

All uses cases applied with branching models to ensure the isolation of development and release.

### Environmental Deployments (environments/*)

#### Terraform Service - Use case #1

![image info](references/service-single-env.PNG)

`Requirements:`

- A single pipeline to support Terraform Service development.

`Repository structrure:`

```
.
├── environments
│   └── ci
│       ├── backend.tf
│       ├── terraform.tfvars
│       └── terraform.tfvars.sh
├── tests
│   ├── utilities
│   │   └── backend.go
│   └── environments
│       └── ci
│           └── ci_test.go
├── ...
├── versions.tf
├── variables.tf
├── outputs.tf
└── main.tf
```

`Pipeline setup:`

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_3.1
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: "environments/ci"

default:
  tags:
    - aws
    - terraform
    - docker
```

#### Terraform Service - Use case #2

![image info](references/service-single-env.PNG)

`Requirements:`

- A single pipeline to support Terraform Service development.
- In branch, deploy to `ci` environment.
- In main, deploy to `dev` environment.

`Repository structrure:`

```
.
├── environments
│   ├── ci
│   │   ├── backend.tf
│   │   ├── terraform.tfvars
│   │   └── terraform.tfvars.sh
│   └── dev
│       ├── backend.tf
│       ├── terraform.tfvars
│       └── terraform.tfvars.sh
├── tests
│   ├── utilities
│   │   └── backend.go
│   └── environments
│       ├── ci
│       │   └── ci_test.go
│       └── dev
│           └── dev_test.go
├── ...
├── versions.tf
├── variables.tf
├── outputs.tf
└── main.tf
```

`Pipeline setup:`

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_3.1
    file: /service/pipeline.yml

workflow:
  rules:
    - if: $CI_COMMIT_REF_NAME !=  "main"
      variables:
        TF_DEFAULT_PIPELINE_DIR: "environments/ci"
    - if: $CI_COMMIT_REF_NAME == "main"
      variables:
        TF_DEFAULT_PIPELINE_DIR: "environments/dev"

default:
  tags:
    - aws
    - terraform
    - docker

```

#### Terraform Service - Use case #3

![image info](references/service-multi-accounts.PNG)

`Requirements:`

- In branch:
  - 1 CI deployment to verify the service template. 
- In main:
  - 1 CI deployment to verify the service template.
  - 1 dev deployment run after the CI deployment; manual job; credential set in `dev` environment scope in GitLab CI variables

`Repository structrure:`

```
.
├── environments
│   ├── ci
│   │   ├── backend.tf
│   │   ├── terraform.tfvars
│   │   └── terraform.tfvars.sh
│   └── dev
│       ├── backend.tf
│       ├── terraform.tfvars
│       └── terraform.tfvars.sh
├── tests
│   ├── utilities
│   │   └── backend.go
│   └── environments
│       ├── ci
│       │   └── ci_test.go
│       └── dev
│           └── dev_test.go
├── ...
├── versions.tf
├── variables.tf
├── outputs.tf
└── main.tf
```

`Pipeline setup:`

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: feature/3.1.0
    file: /service/pipeline.yml

stages:
  - checkout
  - secret_detection
  - prereq
  - find_changed
  - validate
  - documentation
  - deploy
  - test
  - deploy:dev  # Dedicated stage for dev to run after CI deployment
  - test:dev    # Dedicated stage for dev to run after CI deployment
  - destroy
  - publish
  - tag

# Default deployment

variables:
  TF_DEFAULT_PIPELINE_DIR: "environments/ci"

default:
  tags:
    - aws
    - terraform
    - docker

# Extended dev deployment

validate_tf:dev:
  environment: dev
  when: manual
  extends: .validate_tf
  variables:
    TF_EXTENDED_TEMPLATE_DIR: environments/dev
  only:
    refs:
      - main
  tags:
    - aws-<account-id>
    - docker

apply:dev:
  stage: deploy:dev
  environment: dev
  when: manual
  extends: .apply
  variables:
    TF_EXTENDED_TEMPLATE_DIR: environments/dev
  only:
    refs:
      - main
  tags:
    - aws-<account-id>
    - docker
    - us-gov-west-1

terratest:dev:
  stage: test:dev
  environment: dev
  when: manual
  extends: .terratest
  variables:
    TF_EXTENDED_TEMPLATE_DIR: environments/dev
  only:
    refs:
      - main
  tags:
    - aws-<account-id>
    - docker
    - us-gov-west-1

destroy:dev:
  environment: dev
  when: manual
  extends: .destroy
  variables:
    TF_EXTENDED_TEMPLATE_DIR: environments/dev
  only:
    refs:
      - main
  tags:
    - aws-<account-id>
    - docker
    - us-gov-west-1
```

### Example Deployments (examples/*)

#### Terraform Module - Use case #1

![image info](references/module-single-env.PNG)

`Requirements:`

- A single pipeline to deploy the example template.

`Repository structrure:`

```
.
├── examples
│   └── complete
│       ├── main.tf
│       ├── terraform.tfvars
│       └── versions.tf
├── tests
│   └── examples
│       └── complete
│           └── example_test.go
├── ...
├── versions.tf
├── variables.tf
├── outputs.tf
└── main.tf
```

`Pipeline setup:`

```yml

include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_3.1
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: "examples/complete"

default:
  tags:
    - aws
    - terraform
    - docker
```

#### Terraform Module - Use case #2

![image info](references/module-multi-examples.PNG)

`Requirements:`

- Deploy 2 examples in parallel for `linux` and `windows` platforms.
- Omit the default pipeline because the job name needs to include the platform name

`Repository structrure:`

```
.
├── examples
│   └── complete
|       ├── linux
│       |   ├── main.tf
│       |   ├── terraform.tfvars
│       |   └── versions.tf
|       └── windows
│           ├── main.tf
│           ├── terraform.tfvars
│           └── versions.tf
├── tests
│   └── examples
│       └── complete
|           ├── linux
│           |   └── example_test.go
|           └── windows
│               └── example_test.go
├── ...
├── versions.tf
├── variables.tf
├── outputs.tf
└── main.tf
```

`Pipeline setup:`

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_3.1
    file: /module/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: "" # Set to blank to dismiss default pipeline

default:
  tags:
    - terraform
    - aws
    - docker

# Linux example deployment

validate_tf_linux:
  extends: .validate_tf
  variables:
    TF_TEMPLATE_DIR: examples/complete/linux

apply_linux:
  extends: .apply
  variables:
    TF_TEMPLATE_DIR: examples/complete/linux

terratest_linux:
  extends: .terratest
  variables:
    TF_TEMPLATE_DIR: examples/complete/linux
  dependencies:
    - find_changed_tf
    - apply_linux

compliance_test_linux:
  extends: .compliance_test
  variables:
    TF_TEMPLATE_DIR: examples/complete/linux

destroy_linux:
  extends: .destroy
  variables:
    TF_TEMPLATE_DIR: examples/complete/linux
  dependencies:
    - find_changed_tf
    - apply_linux

# Windows example deployment

validate_tf_windows:
  extends: .validate_tf
  variables:
    TF_TEMPLATE_DIR: examples/complete/windows

apply_windows:
  extends: .apply
  variables:
    TF_TEMPLATE_DIR: examples/complete/windows

terratest_windows:
  extends: .terratest
  variables:
    TF_TEMPLATE_DIR: examples/complete/windows
  dependencies:
    - find_changed_tf
    - apply_windows

compliance_test_windows:
  extends: .compliance_test
  variables:
    TF_TEMPLATE_DIR: examples/complete/windows

destroy_windows:
  extends: .destroy
  variables:
    TF_TEMPLATE_DIR: examples/complete/windows
  dependencies:
    - find_changed_tf
    - apply_windows
```
