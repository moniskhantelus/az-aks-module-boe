# Checkov Guideline

- [Checkov Guideline](#checkov-guideline)
  - [Overview](#overview)
  - [Global Checkov Exclusions](#global-checkov-exclusions)
  - [Resolving Checkov Findings](#resolving-checkov-findings)
    - [Checkov Scan Summary](#checkov-scan-summary)
    - [Checkov Scan Details](#checkov-scan-details)
    - [Steps for Resolving a Failed Check](#steps-for-resolving-a-failed-check)
      - [Refer the Prisma Cloud Guideline for Fixing](#refer-the-prisma-cloud-guideline-for-fixing)
      - [Decide If a Fix is Needed](#decide-if-a-fix-is-needed)
      - [Identify the Affected Source Code File](#identify-the-affected-source-code-file)
      - [Apply the Suggested Fix](#apply-the-suggested-fix)
  - [References](#references)

## Overview

Checkov is a static code analysis tool for scanning infrastructure as code (IaC) files for misconfigurations that may lead to security or compliance problems. Checkov includes more than 750 predefined policies to check for common misconfiguration issues. In addition, Checkov also supports custom policies (Python or YAML format) in accordance with user's specific needs.

Checkov has been integrated into Terraform Shared Pipeline template via `checkov` job, see [README.md](../.shared/README.md#checkov) for usage.

## Global Checkov Exclusions

Checkov job allows users to override `CHECKOV_EXCLUDED_CHECKS` [variable](../.shared/README.md#excluding-checks) for a list of check IDs to be excluded from the scan. Beside of these pipeline level exclusions, ECS Catalog team also maintains a list of global exclusions within the Terraform Shared Pipeline which users can't override. These global exclusions are identified, justified, tracked, reviewed and applied periodically so pipelines consistently enforce checks while enabling legitimate, documented exceptions per environment ([AWS](../.shared/scripts/checkov/exclusion/aws.yaml), [Azure](../.shared/scripts/checkov/exclusion/azure.yaml), [GCP](../.shared/scripts/checkov/exclusion/gcp.yaml)) and [globally](../.shared/scripts/checkov/exclusion/global.yaml).

Example of global exclusion:

```yaml
- check_id: "CKV_TF_1"
  check_name: "Ensure Terraform module sources use a commit hash"
  reason: "Known false positive as ECS Catalog is publishing modules to SRES artifactory instead of Version Control System (VCS)"
  type: "module"
  entities: ["module"]
  category: "terraform-policies"
  reference: "https://docs.prismacloud.io/en/enterprise-edition/policy-reference/supply-chain-policies/terraform-policies/ensure-terraform-module-sources-use-git-url-with-commit-hash-revision"
  owners: ["ecs-catalog"]
  created_date: "2026-05-01"
  reviewed_date: "2026-05-30"
  environment: "global"
  severity: "medium"
  status: "active"
```

## Resolving Checkov Findings

### Checkov Scan Summary

Checkov scan summary can be found from the `checkov` job log. It summarizes how many checks are passed, failed or skipped. For example:

```bash
       _               _
   ___| |__   ___  ___| | _______   __
  / __| '_ \ / _ \/ __| |/ / _ \ \ / /
 | (__| | | |  __/ (__|   < (_) \ V /
  \___|_| |_|\___|\___|_|\_\___/ \_/
By Prisma Cloud | version: 3.2.500 
Update available 3.2.500 -> 3.2.529
Run pip3 install -U checkov to update 
terraform scan results:
Passed checks: 5, Failed checks: 1, Skipped checks: 0
```

### Checkov Scan Details

Checkov scan also provides details for each check, either `PASSED` or `FAILED`. Focus on the `FAILED` checks, which need to be resolved later.

Example of `PASSED` checks (can be ignored):

```bash
Check: CKV_TF_2: "Ensure Terraform module sources use a tag with a version number"
	PASSED for resource: s3_bucket_patch_logs[0]
	File: /main.tf:42-64
	Guide: https://docs.prismacloud.io/en/enterprise-edition/policy-reference/supply-chain-policies/terraform-policies/ensure-terraform-module-sources-use-tag
```

Example of `FAILED` checks (need to be resolved):

```bash
Check: CKV_AWS_23: "Ensure every security group and rule has a description"
	FAILED for resource: aws_security_group.efs_sg
	File: /modules/aws-efs-csi-driver/main.tf:35-54
	Guide: https://docs.prismacloud.io/en/enterprise-edition/policy-reference/aws-policies/aws-networking-policies/networking-31
		35 | resource "aws_security_group" "efs_sg" {
		36 |   name        = "${var.cluster_name}-efs-sg"
		37 |   description = "Allow inbound traffic from VPC"
		38 |   vpc_id      = var.vpc_id
		39 | 
		40 |   ingress {
		41 |     description = "Allow inbound traffic from VPC"
		42 |     from_port   = 2049
		43 |     to_port     = 2049
		44 |     protocol    = "tcp"
		45 |     cidr_blocks = data.aws_vpc.selected.cidr_block_associations[*].cidr_block
		46 |   }
		47 | 
		48 |   egress {
		49 |     from_port   = 0
		50 |     to_port     = 0
		51 |     protocol    = "-1"
		52 |     cidr_blocks = ["0.0.0.0/0"]
		53 |   }
		54 | }
```

More details can be found in the `checkov_report.json` job artifact. For example:

```json
{
  "check_type": "terraform",
  "results": {
    "passed_checks": [
      ...
    ],
    "failed_checks": [
      {
        "check_id": "CKV_AWS_23",
        "bc_check_id": "BC_AWS_NETWORKING_31",
        "check_name": "Ensure every security group and rule has a description",
        "check_result": {
          "result": "FAILED",
          "evaluated_keys": [
            "description",
            "egress/[0]"
          ]
        },
        "code_block": [
          [35, "resource \"aws_security_group\" \"efs_sg\" {\n"
          ],
          [36, "  name        = \"${var.cluster_name}-efs-sg\"\n"
          ],
          [37, "  description = \"Allow inbound traffic from VPC\"\n"
          ],
          [38, "  vpc_id      = var.vpc_id\n"
          ],
          [39, "\n"
          ],
          [40, "  ingress {\n"
          ],
          [41, "    description = \"Allow inbound traffic from VPC\"\n"
          ],
          [42, "    from_port   = 2049\n"
          ],
          [43, "    to_port     = 2049\n"
          ],
          [44, "    protocol    = \"tcp\"\n"
          ],
          [45, "    cidr_blocks = data.aws_vpc.selected.cidr_block_associations[*].cidr_block\n"
          ],
          [46, "  }\n"
          ],
          [47, "\n"
          ],
          [48, "  egress {\n"
          ],
          [49, "    from_port   = 0\n"
          ],
          [50, "    to_port     = 0\n"
          ],
          [51, "    protocol    = \"-1\"\n"
          ],
          [52, "    cidr_blocks = [\"0.0.0.0/0\"]\n"
          ],
          [53, "  }\n"
          ],
          [54, "}\n"
          ]
        ],
        "file_path": "/modules/aws-efs-csi-driver/main.tf",
        "file_abs_path": "/builds/ECS-Catalog/services/terraform/aws/terraform-eks/modules/aws-efs-csi-driver/main.tf",
        "repo_file_path": "/modules/aws-efs-csi-driver/main.tf",
        "file_line_range": [35, 54],
        "resource": "aws_security_group.efs_sg",
        "evaluations": null,
        "check_class": "checkov.terraform.checks.resource.aws.SecurityGroupRuleDescription",
        "fixed_definition": null,
        "entity_tags": null,
        "caller_file_path": null,
        "caller_file_line_range": null,
        "resource_address": null,
        "severity": null,
        "bc_category": null,
        "benchmarks": null,
        "description": null,
        "short_description": null,
        "vulnerability_details": null,
        "connected_node": null,
        "guideline": "https://docs.prismacloud.io/en/enterprise-edition/policy-reference/aws-policies/aws-networking-policies/networking-31",
        "details": [],
        "check_len": null,
        "definition_context_file_path": "/builds/ECS-Catalog/services/terraform/aws/terraform-eks/modules/aws-efs-csi-driver/main.tf"
      },
      ...
    ],
    "skipped_checks": [],
    "parsing_errors": []
  },
  ...
}
```

### Steps for Resolving a Failed Check

#### Refer the Prisma Cloud Guideline for Fixing

Prisma Cloud has provided a fixing guideline for every check. Look into the `FAILED` check details and find the guideline URL. For example:

```bash
Guide: https://docs.prismacloud.io/en/enterprise-edition/policy-reference/aws-policies/aws-networking-policies/networking-31
```

Open that URL, you can find the policy details (including severity), description and steps to fix. For example:

> **Policy Details**
>
> * Checkov ID: `CKV_AWS_23`
> * Severity: `LOW`
>
> **Description**
>
> This policy ensures that each security group rule has a description to help identify the purpose of the rule. Descriptions improve the manageability and understanding of security group rules.
>
> **Fix**
>
> Add a description to your ingress or egress rule.
> ```
> resource "aws_security_group" "example" {
>   name        = var.es_domain
>   description = "Allow inbound traffic to ElasticSearch from VPC CIDR"
>   vpc_id      = var.vpc
>
>
>   ingress {
>     cidr_blocks = ["10.0.0.0/16"]
>    + description = "What does this rule enable"
>     from_port   = 80
>     protocol    = "tcp"
>     to_port     = 80
>   }
> }
> ```

#### Decide If a Fix is Needed

The severity info gives an idea on how a finding is prioritized. Findings that have `INFO` severity are typically non-vulnerables or non-critical advisory information. Those with `LOW` are minimal risks and can be fixed when time permits. Meanwhile, `HIGH` and `CRITICAL` are significant or severe risks that should be resolved immediately.

In case there are valid reasons to ignore a finding (like due to business needs, or false positives, etc.), consider to include it in `CHECKOV_EXCLUDED_CHECKS` [variable](../.shared/README.md#excluding-checks) and document the rationale.

#### Identify the Affected Source Code File

If a finding needs to be fixed, find the affected source code file from check details. For example:

```bash
File: /modules/aws-efs-csi-driver/main.tf:35-54
```

Locate the lines of code:

```bash
35 | resource "aws_security_group" "efs_sg" {
36 |   name        = "${var.cluster_name}-efs-sg"
37 |   description = "Allow inbound traffic from VPC"
38 |   vpc_id      = var.vpc_id
39 | 
40 |   ingress {
41 |     description = "Allow inbound traffic from VPC"
42 |     from_port   = 2049
43 |     to_port     = 2049
44 |     protocol    = "tcp"
45 |     cidr_blocks = data.aws_vpc.selected.cidr_block_associations[*].cidr_block
46 |   }
47 | 
48 |   egress {
49 |     from_port   = 0
50 |     to_port     = 0
51 |     protocol    = "-1"
52 |     cidr_blocks = ["0.0.0.0/0"]
53 |   }
54 | }
```

#### Apply the Suggested Fix

```bash
35 | resource "aws_security_group" "efs_sg" {
36 |   name        = "${var.cluster_name}-efs-sg"
37 |   description = "Allow inbound traffic from VPC"
38 |   vpc_id      = var.vpc_id
39 | 
40 |   ingress {
41 |     description = "Allow inbound traffic from VPC"
42 |     from_port   = 2049
43 |     to_port     = 2049
44 |     protocol    = "tcp"
45 |     cidr_blocks = data.aws_vpc.selected.cidr_block_associations[*].cidr_block
46 |   }
47 | 
48 |   egress {
       + description = "Allow all outbound traffic from the security group to the entire Internet"
49 |     from_port   = 0
50 |     to_port     = 0
51 |     protocol    = "-1"
52 |     cidr_blocks = ["0.0.0.0/0"]
53 |   }
54 | }
```

That should fix the finding!

## References

- Checkov Documentation
  - [What is Checkov](https://www.checkov.io/1.Welcome/What%20is%20Checkov.html)
  - [Quick Start](https://www.checkov.io/1.Welcome/Quick%20Start.html)
  - [CLI Command Reference](https://www.checkov.io/2.Basics/CLI%20Command%20Reference.html)
  - [Terraform Resource Scans](https://www.checkov.io/5.Policy%20Index/terraform.html)
- Prisma Cloud TechDocs
  - [Terraform Policies](https://docs.prismacloud.io/en/enterprise-edition/policy-reference/supply-chain-policies/terraform-policies/terraform-policies)
  - [AWS Policies](https://docs.prismacloud.io/en/enterprise-edition/policy-reference/aws-policies/aws-policies)
  - [Azure Policies](https://docs.prismacloud.io/en/enterprise-edition/policy-reference/azure-policies/azure-policies)
  - [Google Cloud Policies](https://docs.prismacloud.io/en/enterprise-edition/policy-reference/google-cloud-policies/google-cloud-policies)