[![release](https://img.shields.io/badge/release-public%20preview-blue.svg?style=flat)](hhttps://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#public-preview)
[![build status](/../../../badges/main/pipeline.svg)](#)
[![version](https://img.shields.io/badge/version-5.0.0-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)

# Terraform Service Pipeline

The `service/pipeline.yml` pipeline contains stages and jobs for the Terraform service pipeline. This pipeline inherits from `.shared/pipeline.yml`.

- [Terraform Service Pipeline](#terraform-service-pipeline)
  - [Variables](#variables)
  - [Stages](#stages)
    - [checkout](#checkout)
    - [secret\_detection](#secret_detection)
    - [find\_changed](#find_changed)
    - [validate](#validate)
    - [documentation](#documentation)
    - [deploy](#deploy)
    - [test](#test)
    - [destroy](#destroy)
    - [tag](#tag)
  - [Usage](#usage)

## Variables

For general Terraform pipeline variable setup, refer to [Pipeline Variables](../README.md#variables) section.

## Stages

The full pipeline has the following stages:

```text
checkout > secret_detection > prereq > find_changed > validate > documentation > deploy > test > destroy > tag
```

- Terraform pipeline will follow guidance from [terrafrom guidance](https://git.web.boeing.com/ECS-Catalog/guidance/terraform) to align with the security and operational profile of an ECS environment and the build/deployment pipelines to support them.
- Terraform pipeline extends from [general pipeline](https://git.web.boeing.com/ECS-Catalog/pipelines/general) to reuse standard GitLab CI pipelines.

The details of the Terraform Pipeline's stages:

### checkout

| Job                                        | Description                                                                                                                                     |
| ------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------- |
| checkout_secret_detection_pipeline_scripts | To pull the secret detection script from the [ECS Catalog General](https://git.web.boeing.com/ECS-Catalog/pipelines/general) GitLab repository. |
| checkout_shared_pipeline_scripts           | To pull the shared pipeline scripts from the [ECS Catalog General](https://git.web.boeing.com/ECS-Catalog/pipelines/general) GitLab repository. |

### secret_detection

| Job              | Description                                                                                                                                                                                                                                                        |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| secret_detection | To detect and report secrets like keys, passwords, and API tokens unintentionally committed to GitLab repositories.<br> Reference: [ECS Catalog Secret Detection Pipeline](https://git.web.boeing.com/ECS-Catalog/pipelines/general/-/tree/main/secret-detection). |

### find_changed

| Job                   | Description                                                 |
| --------------------- | ----------------------------------------------------------- |
| find_changed_tf       | To find changes in terraform files to determine next steps. |
| find_changed_markdown | To find changes in md files.                                |

### validate

| Job                     | Description                                                                                                                                                                                                                                                                                   |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| validate_tf             | To validate whether a configuration is syntactically valid and internally consistent, regardless of any provided variables or existing state.                                                                                                                                                 |
| estimate_cost           | To validate infrastructure cost before terraform resources are applied                                                                                                                                                                                                                        |
| lint_cm                 | To validate the version increment version matching of all version-related files in dev branches and CM compliance standards.<br>Reference: [ECS Catalog Validate Version Job Extension](https://git.web.boeing.com/ECS-Catalog/pipelines/general/-/tree/main/.shared#validate_version)        |
| lint_markdown           | To check markdown files and flag style issues.<br>Reference: [ECS Catalog Markdown Pipeline](https://git.web.boeing.com/ECS-Catalog/pipelines/markdown/-/tree/main/default)                                                                                                                   |
| lint_tf                 | To lint terraform template for best practice.                                                                                                                                                                                                                                                 |
| checkov                 | Scan cloud infrastructure configurations for security and compliance misconfigurations                                                                                                                                                                                                        |
| coverity                | To identify defects and security vulnerabilities in Terraform templates.                                                                                                                                                                                                                      |
| catalog_dependency_scan | To detect outdated IaC Terraform templates.                                                                                                                                                                                                                                                   |

### documentation

| Job            | Description                                                                                       |
| -------------- | ------------------------------------------------------------------------------------------------- |
| terraform_docs | To generate documentation from Terraform modules in various output formats. This is a manual job. |

### deploy

| Job   | Description                          |
| ----- | ------------------------------------ |
| apply | To trigger the Terraform deployment. |

### test

| Job             | Description                                                                                                                                                  |
| --------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| terratest       | To perform integration test againsts the deployment that provisoned by the `apply` job. <br> *Note: Terratest uses Go language so Go must be pre-installed.* |
| compliance_test | To verify the compliance status of terraform against the Boeing policy and guidance.                                                                         |

### destroy

| Job     | Description                                                                               |
| ------- | ----------------------------------------------------------------------------------------- |
| destroy | To destroy resources that are created by the terratest job. This is a manual-trigger job. |

### tag

| Job | Description                                                                    |
| --- | ------------------------------------------------------------------------------ |
| tag | To create a tag for the released version in the Terraform's GitLab repository. |

## Usage

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: service_5.0
    file: /service/pipeline.yml

variables:
  TF_DEFAULT_PIPELINE_DIR: environments/ci

default:
  tags:
    - docker
```
