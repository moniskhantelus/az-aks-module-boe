# CHANGELOG

This file is used to list changes made in each version of the `service` pipeline.

## 5.0.0

- Add `catalog-dependency-scan` job that detects outdated IaC Terraform templates.

## 4.2.0

- Added support for `.coverity` job to identify defects and security vulnerabilities in Terraform templates. 

## 4.1.1

- Update `checkov` job to add `checkout_terraform_pipeline_scripts` job as dependency.

## 4.1.0

- Replaced the `terrascan` Terraform scanning job with `checkov` to provide broader checks for compliance, misconfiguration, and security best practices.

## 4.0.0

- Update to use `shared_4.0` to adopt the new `lint_cm` (formerly `validate_version`) to validate compliance requirements such as information marking in addition to validating version updates.

## 3.7.1

- Fix: Exclude `.validate_tf` template job from running on tag pipelines to prevent Terraform state key double-slash issue when `CI_COMMIT_BRANCH` is empty.

## 3.7.0

- Update EIC TF pipeline to support both AWS state locking strategies, using dynamodb and s3 state locking. 

## 3.6.0

- Support `estimate_cost` job to validate infrastructure cost.
- Support `terrascan` job to detect compliance and security issues in infrastructure-as-code (IaC) before deployment.

## 3.5.1

- Print the `LockID` path of state lock in dynamodb.

## 3.5.0

- Update `destroy` job to remove dependency on `terratest` and `compliance_test` so the job can run when test failed in local mode.

## 3.4.0

- Update pipeline reference from `shared_3.4` to `shared_3.5` to support GCP authentication with OAuth2 token.

## 3.3.0

- Update pipeline reference from `shared_3.3` to `shared_3.4` to pickup `lint_tf_usage` fix.

## 3.2.2

- Ignore command if there is no `.sh` files.

## 3.2.1

- Update pipeline reference from `shared_3.2` to `shared_3.3` to patch critical vulnerability CVE-2024-3817.

## 3.2.0

- Update pipeline reference from `shared_3.1` to `shared_3.2` to pickup the dedicated GCP Runner Service Account support.

## 3.1.0

- Update logs for CSP backend setup to show associated CI variable name.
- Update pipeline reference from `shared_3.0` to `shared_3.1` to pickup the compliance exclusion feature.

## 3.0.2

- Allow failure for `bvt` pipeline in compliance job.

## 3.0.1

- Update `bvt` pipeline to automate all deployment jobs.

## 3.0.0

- Update pipeline reference from `shared_2.12` to `shared_3.0` to pickup the ECS Remote Terraform Provider Registry integration.

## 2.16.0

- Update Terraform jobs to all manual to allow destroy on deployment failure.
- Update Terraform jobs to bypass find changed to trigger event on demand.

## 2.15.0

- Update pipeline reference from `shared_2.11` to `shared_2.12` to integrate Managed Identity Authentication support.

## 2.14.0

- Add stage `.publish_validation` as a placeholder for the Usage Validation job.
- Update pipeline reference from `service_2.10` to `service_2.11`.

## 2.13.1

- Exclude `validate_version` for `main` pipeline to allow re-running.

## 2.13.0

- Support terratest and compliance test for `bvt`.

## 2.12.1

- Remove redundant condition in `.terraform_init_csp_backend`.

## 2.12.0

- Establish `TF_VAR_ci_tags` to reserve `TF_VAR_tags` for project team's usage.
- Add validation for `.terraform_init_csp_backend` to avoid redundant backend init.
- Update pipeline reference to `shared_2.10`.
- Move backend encryption docs to `.shared` for centralized management.

## 2.11.1

- Reserve `publish` stage.

## 2.11.0

- Remove publish jobs.

## 2.10.0

- Update pipeline reference to `shared_2.8` for terraform docker image version `1.4`.

## 2.9.0

- Update pipeline reference to `shared_2.7` for the new compliance script changes.

## 2.8.0

- Support state encryption for GCP and AWS.
- Reorganize GitLab functions.
- Update pipeline reference to `shared_2.6`.

## 2.7.0

- Upgrade pipeline reference for GCP authentication.

## 2.6.0

- *[Breaking changes]* Upgrade pipeline reference for Azure certificate authentication.

## 2.5.1

- Update to make `TF_STATE_KEY` editable on CI pipeline.

## 2.5.0

- Support `bvt` pipeline.

## 2.4.0

- Support pipeline schedule.

## 2.3.2

- Establish compliance test

## 2.2.2

- Encrypt local Terraform state file to secure credential content in case remote state is disabled (`CI_ECS_CLOUD_TF_STATE_ENABLED`).

## 2.2.1

- Unset https_proxy after back initialization to allow connection to DynamoDB via VPC endpoint.

## 2.2.0

- Update to use `terraform/v1.4` docker image.

## 2.1.0

- Support GCP remote backend.

## 2.0.2

- Update terraform_docs job.
- Update module namespace for publishing services to TF registry.

## 2.0.1

- Fix the shared pipeline reference to latest.

## 2.0.0

- Support multiple environment deployments.
- Restructure the terraform service template and pipeline.
- Support local backend mode as optional.

## 1.2.2

- Add terraform backend tags to the deployment.

## 1.2.1

- Fix shared pipeline reference.

## 1.2.0

- Establish terraform linting job.

## 1.1.2

- Exclude tags job when using FORCE_DEPLOY

## 1.1.1

- Exclude deployment in tag pipelines.

## 1.1.0

- Add publish jobs to the pipeline.

## 1.0.4

- Remove allow failure for markdown linting.

## 1.0.3

- Improve runner tagging mechanism for multi-clouds support.

## 1.0.2

- Update to refer to tagged version of shared pipeline.

## 1.0.1

- Remove unused `checkout_terraform_pipeline_scripts` job.

## 1.0.0

- Update pipeline to utilize the EC2 instance profile for terraform deployment.
- Exclude deployment on `tags` pipeplines.
- Update tfvars file name.
- Integrate `FORCE_DEPLOY` mode.

## 0.13.1

- Separate CSP detection.
- Rename terraform init.

## 0.13.0

- Integrate terraform state backend for Azure.

## 0.12.0

- Integrate terraform state backend for AWS.

## 0.11.1

- Temporarily allow failure for markdown linting because of a bug in the `find_changed_md` job.

## 0.11.0

- Integrate markdown linting.
- Move `validate_version` job from `version` to `validate` stage to utilize pipeline execution duration.

## 0.10.0

* Update the `terradocs` job to automate pushing `README.md` to Gitlab.

## 0.9.3

- Remove install go extend from terratest stage.
- Update pipeline to use ECS Catalog terraform images.

## 0.9.2

- Setup terraform credential for `validate_tf` job.
- Replace `export_tf_ci_vars` extend by `variables` section in the shared pipeline.

## 0.9.1

- Make the terraform template directory and terraform variables file configurable via CI variable.

## 0.9.0

- Initial Terraform `service` pipeline.
