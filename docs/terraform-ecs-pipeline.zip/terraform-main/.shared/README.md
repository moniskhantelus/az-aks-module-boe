[![release](https://img.shields.io/badge/release-public%20preview-blue.svg?style=flat)](hhttps://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#public-preview)
[![build status](/../../../badges/main/pipeline.svg)](#)
[![version](https://img.shields.io/badge/version-5.0.0-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)

# Terraform Shared Pipelines

This contains a set of reusable terraform pipeline components such as variables, extends, etc. that can be used by other terraform pipeline templates.

- [Terraform Shared Pipelines](#terraform-shared-pipelines)
- [Extends](#extends)
  - [Script Extends](#script-extends)
    - [`.detect_csp`](#detect_csp)
    - [`.terraform_init_local_backend`](#terraform_init_local_backend)
    - [`.setup_sres_credential`](#setup_sres_credential)
    - [`.setup_terraform_credential`](#setup_terraform_credential)
    - [`.setup_terraform_git_credential`](#setup_terraform_git_credential)
    - [`.check_for_changes_script`](#check_for_changes_script)
  - [Job Extends](#job-extends)
    - [`.checkout_terraform_pipeline_scripts`](#checkout_terraform_pipeline_scripts)
    - [`.find_changed_tf`](#find_changed_tf)
    - [`.lint_cm`](#lint_cm)
    - [`.tflint`](#tflint)
    - [`.coverity`](#coverity)
    - [`.terraform_docs`](#terraform_docs)
    - [`.terraform_usage`](#terraform_usage)
    - [`.validate_tf_usage`](#validate_tf_usage)
    - [`.shared_validate_tf`](#shared_validate_tf)
    - [`.estimate_cost`](#estimate_cost)
    - [`.terrascan`](#terrascan)
    - [`.shared_apply`](#shared_apply)
    - [`.shared_terratest`](#shared_terratest)
    - [`.compliance_test`](#compliance_test)
    - [`.checkov`](#checkov)
      - [Variables:](#variables)
      - [Basic Usage](#basic-usage)
      - [Excluding Checks](#excluding-checks)
      - [Adding Custom Policies](#adding-custom-policies)
      - [Adding Additional Checkov Arguments](#adding-additional-checkov-arguments)
      - [Output](#output)
      - [Resolving Checkov Findings](#resolving-checkov-findings)
      - [Useful links](#useful-links)
  - [Usage](#usage)

# Extends

The following extends are ready-to-use in downstream pipelines as utilities. Downstream pipelines are responsible to define a stage for jobs that use those extends.

## Script Extends

### `.detect_csp`

To detect the configured cloud provider based on the terraform `versions.tf` file.

Usage

```yaml
terratest:
  stage: test
  before_script:
    - !reference [.detect_csp, script]
```

### `.terraform_init_local_backend`

To initialize Terraform configuration files in the local workspace.

Usage

```yaml
terratest:
  stage: test
  before_script:
    - !reference [.terraform_init_local_backend, script]
```

### `.setup_sres_credential`

To setup credential to access Boeing Artifactory.

Usage

```yaml
terratest:
  stage: test
  before_script:
    - !reference [.setup_sres_credential, script]
```

### `.setup_terraform_credential`

To setup Terraform credential to authenticate to Cloud Service Providers. Supporting platforms: `Azure`, `AWS`, `GCP`.

Usage

```yaml
terratest:
  stage: test
  before_script:
    - !reference [.setup_terraform_credential, script]
```

### `.setup_terraform_git_credential`

To setup Git credential for Terraform to invoke a private child module.

Usage

```yaml
terratest:
  stage: test
  before_script:
    - !reference [.setup_terraform_git_credential, script]
```

### `.check_for_changes_script`

To exit the CI pipeline if there is no Terraform template changed.

Usage

```yaml
terratest:
  stage: test
  before_script:
    - !reference [.check_for_changes_script, script]
```

## Job Extends

### `.checkout_terraform_pipeline_scripts`

To checkout Terraform pipeline scripts:

Usage

```yaml
checkout_terraform_pipeline_scripts:
  stage: checkout
  extends: .checkout_terraform_pipeline_scripts
```

### `.find_changed_tf`

To find changed Terraform templates.

Usage

```yaml
find_changed_tf:
  stage: find_changed
  extends: .find_changed_tf
```

### `.lint_cm`

To validate the version increment version matching of all version-related files in dev branches and CM compliance standards.

Usage

```yaml
lint_cm:
  stage: version
  extends: .lint_cm
```

### `.tflint`

To lint terraform template with the following key features:

- Scan for potential errors for major Cloud providers.
- Warn about deprecated syntax, unused declarations.
- Ensure best practices, naming conventions.

Usage

```yaml
tflint:
  stage: validate
  extends: .tflint
```

All default tflint plugins are enabled in [tflint Docker Image](https://git.web.boeing.com/ECS-Catalog/docker-images/tflint/-/blob/main/ecs/tflint/v0.51/.tflint.hcl). To enable more plugins, create a new file name `.tflint.hcl` in the root directory of the Terraform repository. The following snippet shows sample content of a `.tflint.hcl` file.

```hcl
plugin "terraform" {
  enabled = true
  version = "0.2.2"
  source  = "github.com/terraform-linters/tflint-ruleset-terraform"
}
```

Sample for bypassing tflint rules in Terraform template:

```terraform
# tflint-ignore: terraform_typed_variables
variable "name" {
  description = "Name of secret to store"
  validation {
    condition     = length(var.name) > 0
    error_message = "Please provide a valid name."
  }
}
```

### `.coverity`

To identify defects and security vulnerabilities in Terraform templates.

Usage

```yaml
coverity:
  stage: validate
  extends: .coverity
```

To exclude specific files from the analysis based on a list of glob patterns, set the `COVERITY_EXCLUDE_FILE_PATH` GitLab variable. Provide each pattern in the list, separated by commas.

```yaml
variables:
  COVERITY_EXCLUDE_FILE_PATH: "**/tests,**/documents"
```

### `.terraform_docs`

To generate documentation from Terraform template in various output formats. This is a manual job.

Usage

```yaml
terraform_docs:
  extends: .terraform_docs
```

### `.terraform_usage`

To append Terraform Usage from `tests/usages/default/main.tf` to `README.md` if any. The `README.md` file needs to have the following markers to identify placement for the content append. This is a manual job.

README

```md
<!-- ECS_BEGIN_USAGE_DOCS -->

<!-- ECS_END_USAGE_DOCS -->
```

Usage

```yaml
terraform_usage:
  extends: .terraform_usage
```

### `.validate_tf_usage`

To validate the Terraform usage in `tests/usages/default/main.tf`. This is a manual job.

Usage

```yaml
usage_lint:
  extends: .validate_tf_usage
```

The following tree describes required directory structure by the `.validate_tf_usage` function:

```text
└── tests/
    └── usages/
        ├── default/
        │   ├── main.tf
        │   └── version.tf
        ├── usecase_1/
        │   ├── main.tf
        │   └── version.tf
        ├── ...
        └── usecase_n/
            ├── main.tf
            └── version.tf
```

### `.shared_validate_tf`

This job extension takes the following variables as function inputs and executes `terraform validate` of the given Terraform template accordingly.

**Important Note**: Terraform template repositories should **NOT** use this extension directly. Recommend to use [Module Validate Extension](../module/README.md#extended-pipeline) and [Service Validate Extension](../service/README.md#extended-pipeline) instead for more type-focused handling.

### `.estimate_cost`

The `estimate_cost` job evaluates the Cloud infrastructure cost before Terraform resources are applied.

An API key is required to be configured as CI Variable `CI_ECS_INFRACOST_API_KEY`. To register and retrieve the API Key, please follow [Infracost guideline](https://www.infracost.io/docs/#2-get-api-key).

### `.terrascan`

`.terrascan` is a static code analyzer that evaluates the IaC against security and compliance best practice.

Sample Terrascan outputs:

```terrascan outputs
"violations": [
  {
    "rule_name": "instanceWithNoVpc",
    "description": "Ensure that your AWS application is not deployed within the default Virtual Private Cloud in order to follow security best practices",
    "rule_id": "AC_AWS_0153",
    "severity": "MEDIUM",
    "category": "Infrastructure Security",
    "resource_name": "this",
    "resource_type": "aws_instance",
    "module_name": "linux_ec2",
    "file": "../../../main.tf",
    "plan_root": "./",
    "line": 101
  }
]
```

To skip specific violations, set the `TERRASCAN_SKIP_RULES` GitLab variable with one or more `rule_id` values, separated by `commas`

```yaml
variables:
  TERRASCAN_SKIP_RULES: "AC_AWS_0153"
```

### `.shared_apply`

This job extension takes the following variables as function inputs and executes `terraform apply` of the given Terraform template accordingly.

**Important Note**: Terraform template repositories should **NOT** use this extension directly. Recommend to use [Module Validate Extension](../module/README.md#extended-pipeline) and [Service Validate Extension](../service/README.md#extended-pipeline) instead for more type-focused handling.

### `.shared_terratest`

This job extension takes the following variables as function inputs and executes `go test` of the given Terraform template accordingly.

**Important Note**: Terraform template repositories should **NOT** use this extension directly. Recommend to use [Module Validate Extension](../module/README.md#extended-pipeline) and [Service Validate Extension](../service/README.md#extended-pipeline) instead for more type-focused handling.

### `.compliance_test`

Evaluate compliance of the deployed resources against the configured policy in the Subscription/Account.

Usage

```yaml
compliance_test:
  extends: .compliance_test
```

To exclude compliance rules, update the `metadata.json` with the `complianceRule` attribute.

In Azure, the exclusion list should be the Compliance Policy ID:

```json
{
  "version": "0.9.0",
  "complianceRule": {
    "excludes": [
      "013e242c-8828-4970-87b3-ab247555486d",
      "f47b5582-33ec-4c5c-87c0-b010a6b2e917"
    ]
  }
}
```

In AWS, the exclusion list should be the Config Rule Name:

```json
{
  "version": "0.9.0",
  "complianceRule": {
    "excludes": [
      "ApprovedAMIsByID"
    ]
  }
}
```

### `.checkov`

Scan cloud infrastructure configurations for security and compliance misconfigurations using Checkov.
Supports rule exclusions and custom policies (Python or YAML).

#### Variables:

| Variable Name                  | Default Value         | Description                                                       |
| ------------------------------ | --------------------- | ----------------------------------------------------------------- |
| `CHECKOV_CUSTOM_POLICIES_PATH` | `""`                  | Path to custom policy folder (Python or YAML), project-specific.  |
| `CHECKOV_EXCLUDED_CHECKS`      | `""`                  | Comma separated list of Checkov check IDs to exclude.             |
| `CHECKOV_COMMAND_ARGS`         | `""`                  | Additional arguments to pass to the Checkov command.              |
| `CHECKOV_OUTPUT_FILE`          | `checkov_report.json` | The name of the Checkov report file.                              |
| `CHECKOV_EXCLUDE_PATHS`        | `tests`               | Comma separated list of paths to exclude from checkov evaluation. |

#### Basic Usage

To include the Checkov job in your pipeline:

```yaml
checkov:
  extends: .checkov
```

#### Excluding Checks

To exclude specific Checkov rules, set the `CHECKOV_EXCLUDED_CHECKS` variable with a comma-separated list of Checkov check IDs:

```yaml
checkov:
  extends: .checkov
  variables:
    CHECKOV_EXCLUDED_CHECKS: "CKV_EXAMPLE_1,CKV_EXAMPLE_2"
```

#### Adding Custom Policies

You can extend Checkov with custom policies, either in Python or YAML.

- Python Custom Policy Example.
  
  Create a Python file (e.g., custom_s3_check.py):

  ```python
    from checkov.terraform.checks.resource.base_resource_check import BaseResourceCheck
    from checkov.common.models.enums import CheckResult, CheckCategories

    class CustomS3Check(BaseResourceCheck):
        def __init__(self):
            name = "Example custom check"
            id = "CKV_CUSTOM_001"
            supported_resources = ["aws_s3_bucket"]
            categories = [CheckCategories.SECRETS]
            super().__init__(name=name, id=id, categories=categories, supported_resources=supported_resources)

        def scan_resource_conf(self, conf):
            return CheckResult.PASSED

    check = CustomS3Check()
  ```

- YAML Custom Policy Example.
  
  Create a YAML file (e.g., custom_s3_policy.yaml):

  ```yaml
    metadata:
      name: "CKV_S3_YAML_1"
      category: "s3"
      id: "CKV_S3_YAML_1"
      version: 1.0.0
      description: "Custom S3 Policy's description."
    definition:
      and:
        - resource_types:
            - aws_s3_bucket
        - cond_type: attribute
          attribute: acl
          operator: not_equals
          value: "public-read"
        - cond_type: attribute
          attribute: acl
          operator: not_equals
          value: "public-read-write"
  ```

- Using Custom Policies
  - Global Custom Policies
    - Place your Python/YAML files in the `checkov/shared-custom-policies` folder inside your scripts directory. These checks will be available for all projects.
  - Project-Specific Custom Policies
    - Create a folder (e.g., custom-policies/) in your project for your custom check files.
    - Set the `CHECKOV_CUSTOM_POLICIES_PATH` variable to point to this folder:

      ```yaml
      checkov:
        extends: .checkov
        variables:
          CHECKOV_CUSTOM_POLICIES_PATH: "custom-policies"
      ```
#### Adding Additional Checkov Arguments

If you need to pass extra arguments to Checkov, use the `CHECKOV_COMMAND_ARGS` variable:  

```yaml
checkov:
  extends: .checkov
  variables:
    CHECKOV_COMMAND_ARGS: "--download-external-modules false"
```

#### Output

- By default, the Checkov JSON report will be saved to `checkov_report.json`.
- You can change the output file name using the `CHECKOV_OUTPUT_FILE` variable.

#### Resolving Checkov Findings

Refer this [guideline](../runbooks/checkov-guideline.md#resolving-checkov-findings) for resolving Checkov findings.

#### Useful links

- [Checkov Official Documentation](https://www.checkov.io/1.Welcome/What%20is%20Checkov.html)
- [Checkov Custom Policies](https://www.checkov.io/3.Custom%20Policies/Custom%20Policies%20Overview.html)

## Usage

In order to include this pipeline, depending on the type of template, add `include` parameter in the begining of your Terraform pipeline file as below:  

```yaml
# remote reference
include:
  - project: ecs-catalog/pipelines/terraform
    ref: shared_5.0
    file: .shared/pipeline.yml

# local reference for development
include:
  local: .shared/pipeline.yml
```
