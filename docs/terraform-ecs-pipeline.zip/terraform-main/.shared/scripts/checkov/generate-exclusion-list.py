"""
Reads YAML exclusion manifests, optionally filters by environment
(AWS, Azure, GCP), deduplicates and prints a CSV of check IDs.
Returns non-zero on fatal parse errors and prints a human-friendly
summary for each deduplicated check ID.
"""

import argparse
import sys
import yaml

# Column widths (content)
COL_WIDTHS = {
    "num": 3,
    "id": 15,
    "name": 70,
    "env": 6,
    "status": 8,
    "severity": 8,
    "owners": 12,
    "reviewed": 10,
    "reason": 50,
}

def load_yaml_file(path):
    try:
        with open(path, 'r') as fh:
            data = yaml.safe_load(fh) or []
            if not isinstance(data, list):
                raise ValueError(f"Expected a list at top-level in {path}")
            return data
    except FileNotFoundError:
        return []
    except Exception as e:
        print(f"ERROR: failed loading {path}: {e}", file=sys.stderr)
        sys.exit(2)

def active_check(entry):
    raw = entry.get("status")
    if raw is None:
        status = "active"
    else:
        try:
            status = str(raw).strip().lower()
        except Exception:
            status = str(raw).lower()
    return status == "active"

def parse_args():
    p = argparse.ArgumentParser()
    p.add_argument("--global", dest="global_file", required=False)
    p.add_argument("--env", dest="env_file", required=False)
    p.add_argument("--active-only", dest="active_only", action="store_true",
                   help="Only include entries with status active")
    p.add_argument("--print-summary", dest="print_summary", action="store_true",
                   help="Print a human-friendly summary for each included check")
    return p.parse_args()

def collect_ids_and_entries(entries, args, id_list, id_map):
    """
    Populate id_list (list) and id_map (dict) with first-seen entries.
    Returns list of ids in the order they were added (not deduped).
    """

    for e in entries:
        cid = e.get("check_id")
        if not cid:
            continue
        cid = str(cid).strip()
        if args.active_only and not active_check(e):
            continue
        # Dedupe preserving order
        if cid not in id_map:
            id_map[cid] = e
            id_list.append(cid)
    return id_list

def truncate_field(s, width):
    """Truncate string s to fit width. If trimmed, append '...' (counts toward width)."""
    if s is None:
        s = ""
    s = str(s)
    if len(s) <= width:
        return s
    if width <= 3:
        return s[:width]
    return s[: width - 3] + "..."

def make_border():
    # border segments have 2 extra dashes to account for padding spaces
    parts = []
    for key in ("num","id","name","env","status","severity","owners","reviewed","reason"):
        w = COL_WIDTHS[key]
        parts.append("-" * (w + 2))
    return "+" + "+".join(parts) + "+"

def format_row(values):
    # values: tuple/list of strings in the order of columns
    # Each cell printed with one leading and trailing space inside pipes
    cols = []
    keys = ("num","id","name","env","status","severity","owners","reviewed","reason")
    for key, val in zip(keys, values):
        w = COL_WIDTHS[key]
        # truncate name and reason and also id etc if needed
        if key in ("name","reason"):
            cell = truncate_field(val, w)
        else:
            # still truncate others to be safe
            cell = truncate_field(val, w)
        cols.append(f" {cell.ljust(w)} ")
    return "|" + "|".join(cols) + "|"

def format_header():
    headers = {
        "num": "#",
        "id": "ID",
        "name": "Name",
        "env": "Env",
        "status": "Status",
        "severity": "Severity",
        "owners": "Owners",
        "reviewed": "Reviewed",
        "reason": "Reason",
    }
    keys = ("num","id","name","env","status","severity","owners","reviewed","reason")
    header_cells = []
    for key in keys:
        w = COL_WIDTHS[key]
        label = headers[key]
        # center label within width
        if len(label) >= w:
            label_fmt = truncate_field(label, w)
            header_cells.append(f" {label_fmt.ljust(w)} ")
        else:
            pad_total = w - len(label)
            left = pad_total // 2
            right = pad_total - left
            header_cells.append(" " + (" " * left) + label + (" " * right) + " ")
    return "|" + "|".join(header_cells) + "|"

def print_summary_table(id_list, id_map):
    border = make_border()
    header = format_header()
    # Print to stderr
    print(border, file=sys.stderr)
    print(header, file=sys.stderr)
    print(border, file=sys.stderr)

    # rows
    for idx, cid in enumerate(id_list, start=1):
        entry = id_map.get(cid, {}) or {}
        check_name = entry.get("check_name") or ""
        reason = entry.get("reason") or ""
        severity = entry.get("severity") or ""
        owners = entry.get("owners") or []
        if isinstance(owners, list):
            owners_str = ",".join(str(x) for x in owners)
        else:
            owners_str = str(owners)
        environment = entry.get("environment") or ""
        status = entry.get("status") or "active"
        reviewed = entry.get("reviewed_date") or entry.get("review_at") or entry.get("review_date") or ""

        values = (
            str(idx),
            cid,
            check_name,
            environment,
            status,
            severity,
            owners_str,
            reviewed,
            reason,
        )
        print(format_row(values), file=sys.stderr)
        print(border, file=sys.stderr)

def main():
    args = parse_args()
    id_list = []
    id_map = {}

    if args.global_file:
        entries = load_yaml_file(args.global_file)
        collect_ids_and_entries(entries, args, id_list, id_map)

    if args.env_file:
        entries = load_yaml_file(args.env_file)
        collect_ids_and_entries(entries, args, id_list, id_map)

    # CSV output to stdout
    csv = ",".join(id_list)
    print(csv)

    # Summary table to stderr if requested
    if args.print_summary:
        if not id_list:
            print("No exclusions found.", file=sys.stderr)
            return
        print_summary_table(id_list, id_map)

if __name__ == "__main__":
    main()