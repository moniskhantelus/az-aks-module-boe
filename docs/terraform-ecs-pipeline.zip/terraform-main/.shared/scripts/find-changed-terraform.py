"""
This script finds all terraform files that have been changed from the last success commit comparing to the current commit. 
"""

import subprocess as sp
import sys
import argparse

def main(argv):
    parse = argparse.ArgumentParser()
    parse.add_argument(
        '--templates_directory', help='The full path where the templates are located'
    )
    parse.add_argument(
        '--changed_templates_file', help='Fully qualified path of the directory that contains the file name of templates which are changed in the current commit'
    )
    parse.add_argument(
        '--current_sha', help="The SHA value of the current commit"
    )
    parse.add_argument(
        '--previous_sha', help="SHA of the previous commit or 'latest' or 'latest-success'"
    )

    # Parse arguments
    args = parse.parse_args(args=argv)
    templates_directory = args.templates_directory
    changed_templates_file = args.changed_templates_file
    previous_sha = args.previous_sha
    current_sha = args.current_sha

    # Find all terraform files were changed
    # Case previous_sha = current_sha
    if (previous_sha == None) | (previous_sha[None:8] == '00000000') | (current_sha == previous_sha[None:8]) :
        pipeline_info = "find {0} -type f -name main.tf -printf '%P\n' | tee {1} ".format(templates_directory,changed_templates_file)
        global changed_templates
        changed_templates = sp.getoutput(pipeline_info)

    # Case previous_sha != current_sha
    else :
        get_diff = 'git diff --name-only --no-renames --diff-filter=AM {0} {1} | grep .tf | tee {2} '.format(previous_sha, current_sha,changed_templates_file)
        changed_templates = sp.getoutput(get_diff)

    # Print INFO terraform file has changed
    if changed_templates == "" :
        print("[INFO] No Terraform file has changed...")
    else :
        print("[INFO] Terraform file has changed")
        print(changed_templates)

if __name__ == "__main__":
    main(sys.argv[1:])
