import re
import argparse
import sys
from utilities._logger import *
from utilities._common import *
from utilities._constant import *
from packaging.version import parse

# Get logger
logger = get_logger(__name__)

def compare_version(usage_version, metadata_version):
    # Usage version will look like >=1.0, <1.1
    # Metadata version will look like 1.0.1
    metadata_version_parsing = parse(metadata_version)
    pattern = r'[0-9]+\.[0-9]+'
    matches = re.findall(pattern, usage_version)
    minor_usage_version = ['.'.join(match.split('.')) for match in matches]

    if parse(minor_usage_version[0]) <= metadata_version_parsing and metadata_version_parsing < parse(minor_usage_version[1]):
      return True
    return False

def convert_suffix_alias_replace_underscore_to_dash(suffix_alias):
    return suffix_alias.replace("_","-")

def update_source_url(file_location, suffix_alias): 
    with open(file_location, 'r') as file:
      lines = file.readlines()
    suffix_alias = convert_suffix_alias_replace_underscore_to_dash(suffix_alias)
    with open(file_location, 'w') as file:
        for line in lines:
            if 'source' in line and PROD_ARTIFACT_KEYWORD in line:
                line = line.replace(PROD_ARTIFACT_KEYWORD, DEV_ARTIFACT_KETWORD)
                temp = line.split('/')
                if suffix_alias != "":
                    temp[2] = '{}-{}'.format(temp[2], suffix_alias)
                line = '/'.join(temp)
                logger.info('[+] Checking at dev module source: {}'.format(line))
            file.write(line)  

def main(argv):
    parse = argparse.ArgumentParser()
    parse.add_argument(
        '--usage-file-location', help='The full path where the usage test cases are located'
    )
    parse.add_argument(
        '--metadata-file-location', help='The full path where the metadata file is located'
    )
    parse.add_argument(
        '--module-suffix-alias', help='The suffix alias that will be appended to module source'
    )

    # Parse arguments
    args = parse.parse_args(args=argv)
    usage_file_location = args.usage_file_location
    metadata_file_location = args.metadata_file_location
    module_suffix_alias = args.module_suffix_alias

    # Compare version between metadata.json and README.md
    # Print script tittle
    logger.info('=' * 60)
    logger.info('| TERRAFORM USAGE VALIDATION')
    logger.info('=' * 60)
    logger.info('> --usage-file-location: {}'.format(usage_file_location))
    logger.info('> --metadata-file-location: {}'.format(metadata_file_location))
    logger.info('> --module-suffix-alias: {}'.format(module_suffix_alias))

    err_count = 0
    for ver in get_data_from_test_usage_file(usage_file_location, "version"):
        for data in ver:
            metadata_version = get_version_from_metadata_file(metadata_file_location)
            if compare_version(ver[data], metadata_version):
                logger.info('[+] Version of module {} is matched.({} in range of {})'.format(data, metadata_version, ver[data]))
            else:
                logger.error('[+] Version of module {} is not matched.({} not in range of {})'.format(data, metadata_version, ver[data]))
                err_count += 1
    update_source_url(usage_file_location, module_suffix_alias)
    if err_count > 0:
        sys.exit(1)

if __name__ == "__main__":
    main(sys.argv[1:])