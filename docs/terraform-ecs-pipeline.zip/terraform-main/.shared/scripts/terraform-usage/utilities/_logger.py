import logging
import sys
import os


def get_logger(log_name):
    """
    Get logger based on file name and logging level (CI_PY_LOGGING_LEVEL)
    Default mode: INFO

    Args:
        log_name (str): name of the log

    Raises:
        Exception: if CI_PY_LOGGING_LEVEL is defined but isn't in the supporting list

    Returns:
        Logger: logger object
    """

    # Logger instance
    logger = logging.getLogger(log_name)

    logging_level = os.environ.get('CI_PY_LOGGING_LEVEL')

    # Info
    if not logging_level:
        logger.setLevel(logging.INFO)
        formatter = logging.Formatter(
            '%(asctime)s - %(levelname)s - %(message)s')
    # Debug
    elif logging_level.upper() == 'DEBUG':
        logger.setLevel(logging.DEBUG)
        formatter = logging.Formatter(
            '%(asctime)s - [%(name)s:%(lineno)d] - %(levelname)s - %(message)s')
    else:
        raise Exception(
            'Unsupported CI_PY_LOGGING_LEVEL: {}'.format(logging_level))

    # Handler for log console
    console_handler = logging.StreamHandler(sys.stdout)
    console_handler.setFormatter(formatter)
    logger.addHandler(console_handler)

    return logger
