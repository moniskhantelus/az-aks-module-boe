import hcl2
import json
import sys
from utilities._logger import *
logger = get_logger(__name__)

def get_data_from_test_usage_file(file_location, data_key):
    try:
        with open(file_location, 'r') as fp:
            obj = hcl2.load(fp)
        # Extract information
        modules = obj.get("module", [])
        list_data = []
        for module in modules:
            for key, value in module.items():
                if data_key in value:
                    list_data.append({key: value[data_key]})
        return list_data
    except Exception as e:
        print(e.with_traceback)
        sys.exit(1)

def get_version_from_metadata_file(metadata_file_location):
    try:
      with open(metadata_file_location, "r") as f:
        data = json.load(f)
      version = data.get("version", "")
      return version
    except Exception as e:
        print(e.with_traceback)
        sys.exit(1)