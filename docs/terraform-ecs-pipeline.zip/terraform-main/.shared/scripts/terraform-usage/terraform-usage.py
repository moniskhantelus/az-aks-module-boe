import sys
from utilities._constant import *
from utilities._logger import *
import argparse
import re

# Get logger
logger = get_logger(__name__)

def get_usage_terraform_files_content(usage_terraform_dir, extension_pattern):
    merged_content = ""

    for root, _, files in os.walk(usage_terraform_dir):
        for file_name in files:
            if file_name.endswith(extension_pattern) and file_name == USAGE_TERRAFORM_TEMPLATE_FILENAME:
                file_path = os.path.join(root, file_name)
                with open(file_path, 'r') as file:
                    file_content = file.read()
                    merged_content += '\n{}'.format(file_content)

    return merged_content.strip()

def auto_update_readme(readme_location, usage_terraform_dir):
    with open(readme_location, 'r') as file:
      lines = file.read()
    
    begin_idx = lines.find(BEGINNING_USAGE_HOOK)
    end_idx = lines.find(ENDING_USAGE_HOOK)

    merged_content =  get_usage_terraform_files_content(usage_terraform_dir, USAGE_TERRAFORM_EXTENSION)

    if begin_idx == -1 or end_idx == -1:
       logger.error('[+] Usage Hook Not Found.')
       sys.exit(1)
    elif begin_idx != -1 and end_idx != -1 and begin_idx < end_idx:
       logger.info('[+] Detected Usage Hook.')
       logger.info('[+] Processing automation update...')
       # Remove all contents between beginning hook and ending hook
       
       new_content = ("{}\n\n```terraform\n{}\n```\n\n{}".format(lines[:begin_idx + len(BEGINNING_USAGE_HOOK)], merged_content, lines[end_idx:]))
       with open(readme_location, 'w') as file:
          file.write(new_content)
          logger.info('[+] Update success.')
    else:
       logger.info("[+] Doesn't support")

def main(argv):
    parse = argparse.ArgumentParser()
    parse.add_argument(
        '--usage-files-dir', help='The full path where the usage test cases are located'
    )
    parse.add_argument(
        '--readme-file-location', help='The full path where the readme file is located'
    )

    # Parse arguments
    args = parse.parse_args(args=argv)
    usage_files_dir = args.usage_files_dir
    readme_file_location = args.readme_file_location

    logger.info('> --usage-files-dir: {}'.format(usage_files_dir))
    logger.info('> --readme-file-location: {}'.format(readme_file_location))

    # Compare version between metadata.json and README.md
    # Print script tittle
    logger.info('=' * 60)
    logger.info('| UPDATE USAGE IN README')
    logger.info('=' * 60)

    err_count = 0
    auto_update_readme(readme_file_location, usage_files_dir)
    if err_count > 0:
        sys.exit(1)

if __name__ == "__main__":
    main(sys.argv[1:])
