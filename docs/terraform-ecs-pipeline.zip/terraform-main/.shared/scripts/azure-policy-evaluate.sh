#!/usr/bin/env bash

###########################
# Purpose of this script: 
# Identify whether testing resource is found unhealthy in built-in Azure Security Center Policy
###########################

if [[ -z "$1" ]]; then
  echo "Usage: $(basename "$0") <RESOURCE_GROUP> <RESOURCE_IDS> <POLICY_EVALUATION_DELAY> <POLICY_DEFINITION_RESOURCE_ID>"
  echo "       RESOURCE_IDS                   - The IDs of the deployed resources"
  echo "       POLICY_EVALUATION_DELAY        - The delay value of Azure Policy Evaluation"
  echo "       POLICY_DEFINITION_RESOURCE_ID  - The Target Policy Set (Policy initiatives) or Single Policy Definition ID to verify"
  exit 1
fi

# Parse script input
while [ $# -gt 0 ]; do
  case "$1" in
  --resource_ids)
    export resource_ids="${2}"
    shift
    ;;
  --policy_evaluation_delay)
    export policy_evaluation_delay="${2}"
    shift
    ;;
  --policy_definition_resource_id)
    export policy_definition_resource_id="${2}"
    shift
    ;;
  *)
    echo "ERROR: Invalid argument: ${1}"
    exit 1
    ;;
  esac
  shift
done

# The Azure cloud environment
default_cloud_environment="AzureUSGovernment"
cloud_environment=$(test -z "${CI_ECS_AZURE_CLOUD_ENVIRONMENT}" && echo "${default_cloud_environment}" || echo "${CI_ECS_AZURE_CLOUD_ENVIRONMENT}")

# Abort execution on first error.
# Set command (not CI) pipeline's exit code to the value of the last (rightmost) command to exit with a non-zero status.
# Set command to immediately exit if unset variables detected.
set -eu -o pipefail

# Check if RESOURCE_IDS is empty or not
if [[ -z $resource_ids ]]; then
    echo "Could not find any resource ID to evaluate."
    exit 1
fi

# Convert the list of IDs to a Bash array
IFS=',' read -ra resourceIds <<< "$resource_ids"

echo "Found ${#resourceIds[@]} resources to evaluate:"
for resource_id in "${resourceIds[@]}"
do
  echo "[+] ${resource_id}"
done

###########################
# When an on-demand evaluation scan is triggered, as in the case of running the az policy state trigger-scan command, Azure Policy will first determine what policies are applicable to the scope being scanned. 
# It then performs a GET request on the list of resources in that scope, and then will determine the compliance state for each resource based on the GET response payload that got evaluated.
# This type of evaluation scan is executed asynchronously based on a GET request to the Azure Resource Manager cache or to the Resource Provider.
###########################

get_resource_group() {
  if [[ -z $1 ]]; then
    echo "Could not find any resource ID to evaluate."
    exit 1
  fi
  resource_id=$1
  deploy_resource_group=$(echo "$resource_id" | grep -oE 'resourceGroups/([^/]+)/' | awk -F'/' '{print $2}')
}

resource_group_ids=()
for resource_id in ${resourceIds[@]}; do
  get_resource_group $resource_id
  element_exists=false
  for resource_group_id in ${resource_group_ids[@]}; do
    if [[ "$resource_group_id" == "$deploy_resource_group" ]]; then
      element_exists=true
      break
    fi
  done
  if [[ "$element_exists" == false ]]; then
    resource_group_ids+=("$deploy_resource_group")
  fi
done

# Trigger Policy Scan
for resource_group_id in ${resource_group_ids[@]}; do
  echo "Start explicitly triggering a compliance scan against ${resource_group_id} resource group..."
  start=`date +%s`
  az policy state trigger-scan --resource-group "${resource_group_id}"
  end=`date +%s`
  runtime=$((end-start))
  echo "> The compliance scan has been triggered successfully (took ${runtime} seconds to complete)."
done

excludedPolicyList=$(cat $CI_PROJECT_DIR/metadata.json | jq '.complianceRule?.excludes // []')

echo "List policy name being excluded:"
if [ $(echo "$excludedPolicyList" | jq length) -gt 0 ]; then
  echo $excludedPolicyList | jq -r '.[]' | sed 's/^/[+] /'
else
  echo "> No policy name is excluded."
fi

# New or updated resources within scope of an existing assignment become available in about 15 minutes
# Reference: https://docs.microsoft.com/en-us/azure/governance/policy/troubleshoot/general#scenario-evaluation-details-arent-up-to-date
# Ticket Reference Number #2105040040000118
echo "Waiting for ${policy_evaluation_delay} seconds before evaluating the scan results..."
sleep $policy_evaluation_delay

return_code=0
for resource_id in ${resourceIds[@]}; do
  echo "=============== ${resource_id} ==============="
  get_resource_group $resource_id

  policyState=$(az policy state list --resource ${resource_id} -g ${deploy_resource_group})
  policyState=${policyState,,}
  policy_definition_resource_id=${policy_definition_resource_id,,}
  nonCompliantControls=$(jq -r '.[] | select ((.compliancestate == "noncompliant") and (.policysetdefinitionid == '\"$policy_definition_resource_id\"' or .policydefinitionid == '\"$policy_definition_resource_id\"')) | .policydefinitionname' <<< "$policyState")
  if [[ -z "$nonCompliantControls" ]]; then
      echo "✅ RESOURCE IS COMPLIANT."
  else
    echo "Violated Policies:"
    for policyName in $nonCompliantControls; do
      policy=$(az policy definition show -n $policyName --query displayName --output tsv)
      if [[ $(echo $excludedPolicyList | jq -r ".[]" | fgrep -w $policyName) ]]; then
        echo "[-] Skip policy: ${policy} (${policyName})"
      else
        echo "[+] ${policy} (${policyName})"
        return_code=1 
      fi
    done
    if [[ $return_code == "1" ]]; then
      echo "⚠️ RESOURCE IS NOT COMPLIANT."
    else
      echo "✅ RESOURCE IS COMPLIANT."
    fi
  fi
done
exit $return_code
