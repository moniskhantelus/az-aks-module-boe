set -e

# Constants
RED='\033[0;31m'
YELLOW='\033[1;33m'
GREEN='\033[0;32m'
CYAN='\033[1;36m'
NC='\033[0m'

# Styling functions

function log_error() {
  msg=$1
  printf "${RED}[ERROR] ${1}${NC}\n"
}

function log_warning() {
  msg=$1
  printf "${YELLOW}[WARNING] ${1}${NC}\n"
}

function log_highlight() {
  msg=$1
  printf "${CYAN}${1}${NC}\n"
}

function log_info() {
  msg=$1
  printf "${GREEN}[INFO] ${1}${NC}\n"
}

# Print script header
log_highlight "====================================================="
log_highlight "| AWS COMPLIANCE TEST"
log_highlight "====================================================="

# Parse script input
while [ $# -gt 0 ]; do
  case "$1" in
  --tfstate)
    export tfstate_file="${2}"
    shift
    ;;
  --retries)
    export retries="${2}"
    shift
    ;;
  --retry-interval)
    export retry_interval="${2}"
    shift
    ;;
  --output-format)
    export output_format="${2}"
    shift
    ;;
  *)
    log_error "Invalid argument: ${1}"
    exit 1
    ;;
  esac
  shift
done

# Assign default value
[ -z "${retries}" ] && export retries=3
[ -z "${output_format}" ] && export output_format=json
[ -z "${retry_interval}" ] && export retry_interval=100

# Print information to console
echo "> --tfstate ${tfstate_file}"
echo "> --retries ${retries}"
echo "> --retry-interval ${retry_interval}"
echo "> --output-format ${output_format}"

# Verify required args
required_args=
[ -z "${tfstate_file}" ] && required_args+="--tfstate "
[ ! -z "${required_args}" ] && log_error "Missing required arguments: ${required_args}" && exit 1

# Trigger periodic rules
function trigger_periodic_rules() {
  local resource_type=$1
  local region=$2

  LIST_RULE=$(aws configservice describe-config-rules \
        --query "ConfigRules[?Scope.ComplianceResourceTypes[0] == '${resource_type}' && not_null(MaximumExecutionFrequency) ] | [].[ConfigRuleName]" \
        --region ${region} \
        --output text)

  if [[ $LIST_RULE != "" ]]; then
    # Trigger periodic rules
    aws configservice start-config-rules-evaluation \
        --config-rule-names ${LIST_RULE} \
        --region ${region}
  fi
  
}

compliance_status=0
# Get violated rule
function get_violated_rule_details() {
  local resource_type=$1
  local resource_id=$2
  local region=$3
  local excluded_rules=$4

  VIOLATED_RULES=$(aws configservice get-compliance-details-by-resource \
    --resource-type ${resource_type} \
    --resource-id ${resource_id} \
    --compliance-types "NON_COMPLIANT" "NOT_APPLICABLE" \
    --region ${region} \
    --query 'EvaluationResults[*].EvaluationResultIdentifier.EvaluationResultQualifier.ConfigRuleName' \
    --output json)

  log_info "List Violated Rules:"
  while IFS= read -r RULE; do
    if echo "$excluded_rules" | jq -e ".[] | select(. == \"$RULE\")" >/dev/null; then
      echo "[-] Skip: $RULE"
      VIOLATED_RULES=$(echo "$VIOLATED_RULES" | jq --arg RULE "$RULE" 'map(select(. != $RULE))')
    else
      echo "[+] $RULE"
    fi
  done <<< "$(echo "$VIOLATED_RULES" | jq -r '.[]')"

  VIOLATED_RULES=$(echo $VIOLATED_RULES | jq -r '.[]')

  if [[ $VIOLATED_RULES != "" ]]; then
    log_error "Resource is non-compliant"
    echo "> Get violated rule details"
    aws configservice describe-config-rules \
      --config-rule-names $VIOLATED_RULES \
      --region ${region} \
      --output ${output_format} \
      --color on
    compliance_status=1
  else
    log_info "Resource is compliant"
    compliance_status=0
  fi 
}

# Get resources from terraform deployment output
echo ""
echo "[+] Get compliance resources"
echo "> Parse deployment output from ${tfstate_file}"
COMPLIANCE_RESOURCES=$(terraform output -json -state ${tfstate_file} compliance_resources | jq -r '.' || true)
echo "> compliance_resources: $(echo $COMPLIANCE_RESOURCES | jq .)"
[[ "${AWS_DEFAULT_REGION}" == "" ]] && AWS_DEFAULT_REGION=$(terraform output -json -state ${tfstate_file} region | jq -r '.' || true)
echo "> region: ${AWS_DEFAULT_REGION}"

EXCLUDED_RULES=$(cat $CI_PROJECT_DIR/metadata.json | jq '.complianceRule?.excludes // []')

log_info "List rule being excluded:"
if [[ $(echo "$EXCLUDED_RULES" | jq length) -gt 0 ]]; then
  echo $EXCLUDED_RULES | jq -r '.[]' | sed 's/^/[+] /'
else
  echo "> No rule is excluded."
fi

# Validate outputs
required_outputs=""
[[ -z "${COMPLIANCE_RESOURCES}" ]] && required_outputs+='compliance_resources '
[[ -z "${AWS_DEFAULT_REGION}" ]] && required_outputs+='region '
[[ ! -z "${required_outputs}" ]] && log_warning "Missing required outputs: ${required_outputs}. Skipping compliance test..." && exit 0

# Loop the compliance resource list from the terraform deployment output
for RESOURCE in $(echo "${COMPLIANCE_RESOURCES}" | jq -r '.[] | @base64'); do
  _jq() {
    echo ${RESOURCE} | base64 --decode | jq -r ${1}
  }

  # Parse resource properties
  resource_type=$(_jq '.type')
  resource_id=$(_jq '.id')

  # Print evaluation header
  echo ""
  log_highlight "-----------------------------------------------------"
  log_highlight "| Evaluate ${resource_type} ${resource_id}"
  log_highlight "-----------------------------------------------------"
  echo "> Trigger all periodic config rule related to resource type: ${resource_type}"
  trigger_periodic_rules "$resource_type" "${AWS_DEFAULT_REGION}"

  for ((n=1;n<=$retries;n++));
  do
    # Wait for resource to be accessible
    echo "> Sleep for ${retry_interval}s to wait for the resource to be accessible."
    sleep $retry_interval

    # Describe compliance
    echo "> Describe compliance by resource"
    compliance_data=$(aws configservice describe-compliance-by-resource \
      --resource-type ${resource_type} \
      --resource-id ${resource_id} \
      --region "${AWS_DEFAULT_REGION}" \
      --output ${output_format} \
      --color on)
    echo $compliance_data | jq .
    compliance_status=$(echo $compliance_data | jq -r .ComplianceByResources[0].Compliance.ComplianceType)

    # Validate compliance status/type of the resource
    if [[ "${compliance_status}" == "COMPLIANT" ]]; then
      log_info "Resource is compliant"
      exit 0
    elif [[ "${compliance_status}" == "NON_COMPLIANT" ]]; then
      get_violated_rule_details "$resource_type" "$resource_id" "${AWS_DEFAULT_REGION}" "${EXCLUDED_RULES}"
      exit $compliance_status
    elif [[ "${compliance_status}" == "INSUFFICIENT_DATA" ]]; then
      # Throw exception if reaching the maximum try
      if [[ "${n}" == "${retries}" ]]; then
        log_error "Unable to retrieve compliance status from AWS."
      # Retry
      else
        log_warning "Unable to retrieve compliance status from AWS. Retrying $((n+1))/${retries}..."
        continue
      fi
    else
      # Throw exception if unknown status found
      log_error "Unknown status"
    fi
    exit 1
  done
done
