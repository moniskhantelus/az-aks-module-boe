# CHANGELOG

This file is used to list changes made in each version of the `.shared` pipeline.

## 5.0.1

- Fix `.tflint` for TFLint v0.47+ compatibility (defect 1461657): add job-level `entrypoint: [""]` so CI runs the script in a shell instead of passing it as `tflint` arguments.

## 5.0.0

- Update to use `ecs-catalog/pipelines/general` pipeline with ref `shared_7` to add jobs that detect outdated pipeline templates.

## 4.5.1

- Updated terraform-docs job to not include `/.terraform/` directories.
- Updated `checkout_terraform_pipeline_scripts` branch to `shared_4.5`.

## 4.5.0

- Update python jobs to use python `3.14`.

## 4.4.4

- Upgrade TFLint image from `tflint/v0.55:1` to `tflint/v0:1` (tflint 0.64.0).

## 4.4.3

- Fix `validate_tf` uploading an empty `.terraform/modules/` artifact for module pipelines, which made `estimate_cost` fail with "modules.json missing".

## 4.4.2

- Skip `estimate_cost` when no Terraform files changed.

## 4.4.1

- Fix `estimate_cost` (infracost) reporting `$0` / "No cloud resources were detected" for templates that consume private modules: it now reuses the modules `validate_tf` downloads (published as a `.terraform/modules/` artifact) instead of fetching them itself, and fails loudly if that artifact is missing.
- Removed the now-unused `INFRACOST_TERRAFORM_CLOUD_HOST`/`INFRACOST_TERRAFORM_CLOUD_TOKEN` variables.

## 4.4.0

- Added support for `.coverity` job extension to identify defects and security vulnerabilities in Terraform templates.  
- Added runbook for Coverity onboarding to assist users in setting up and onboarding to Coverity.

## 4.3.0

- Support global Checkov exclusions per environment (AWS, Azure, GCP) and globally.
- Add runbook for resolving Checkov findings.

## 4.2.3

- Fix Azure compliance test reading a doubled Terraform state path. `.shared_compliance_test` `cd`s into `${TF_TEMPLATE_DIR}` and then read the state with a `${TF_TEMPLATE_DIR}`-prefixed path, resolving to `${TF_TEMPLATE_DIR}/${TF_TEMPLATE_DIR}/terraform.tfstate`. The state file was never found, so `compliance_resources` came back empty and the Azure policy scan was always skipped. Read the bare relative `terraform.tfstate` path instead (the job is already inside `${TF_TEMPLATE_DIR}`).

## 4.2.2

- Replace `git config --global credential.helper` with `git remote add origin "https://${CI_ECS_GITLAB_ACCOUNT}:${CI_ECS_GITLAB_TOKEN}@git.web.boeing.com/${CI_PROJECT_PATH}.git"` to fix 403 "not allowed to push code" error caused by credential helper not injecting credentials properly during git push.

## 4.2.1

- Support checkov global exclude checks list.
- Support checkov excluding paths.

## 4.2.0

- Support `.checkov` job extension to scans cloud infrastructure configurations.

## 4.1.4

- Update `.terraform_docs` to avoid the warning and unnecessary empty commits.

## 4.1.3

- Update the pipeline to support both legacy `--password` and preferred `--certificate` for a service principal certificate. The pipeline should try with `--certificate` first and fall back to `--password`.

## 4.1.2

- Update the pipeline to support both legacy `--username` and preferred `--client-id` for `az login --identity`. The pipeline should try with `--client-id` first and fall back to `--username`.

## 4.1.1

- Resolved Terratest ambiguous import error by explicitly specifying latest version in the terratest job.

## 4.1.0

- Support using GitLab as a terraform registry.

## 4.0.0

- Update to use `ecs-catalog/pipelines/general` pipeline with ref `shared_6` and `secret_detection_4` to adopt the new `lint_cm` (formerly `validate_version`) to validate compliance requirements such as information marking in addition to validating version updates.
- Update python jobs to use python `3.12`.

## 3.6.3

- Update `hcl2` to fix validate usage fails with vague error.

## 3.6.2

- Add `TF_VAR_deployed_by` specifies the individual or team responsible for the deployment and maintenance of the associated cloud resource.
- Add `TF_VAR_deployment_time` indicates the time when the associated resource was deployed or updated.

## 3.6.1

- Update `.terrascan` to avoid scanning on `pipeline-scripts` folder.

## 3.6.0

- Support `.estimate_cost` job extension to validate infrastructure cost.
- Support `.terrascan` job extension to detect compliance and security issues in infrastructure-as-code (IaC) before deployment.

## 3.5.7

- In `.shared` scripts, remove the `validate_tf_usage` job from `main` branches.

## 3.5.6

- Update Terraform-docs image to `terraform-docs/v0.19` to resolve critical vulnerability.

## 3.5.5

- Upgrade TFLint image to `tflint/v0.55` to resolve critical vulnerabilities.

## 3.5.4

- Upgrade Terraform image to `terraform/v1.10` to resolve critical vulnerabilities.

## 3.5.3

- Set region for AWS `setup_terraform_credential` to support cross region deployment.

## 3.5.2

- Temporarily allow failure for `terratest` due to Golang library download issues.

## 3.5.1

- Support extended options for the default `terraform plan` command.

## 3.5.0

- Support GCP authentication with OAuth2 token to leverage Boeing Shared Runner (K8s) to deploy the first GitLab Runner in Tenant Project.

## 3.4.1

- Add safe.directory config for `.terraform_usage` extension.

## 3.4.0

- Update the Terraform usage logic code to handle exceptions related to branch names containing underscore characters.

## 3.3.2

- Update docker images to Catalog latest versions.

## 3.3.1

- Upgrade tflint version 0.45 to 0.51 to fix go-getter vulnerability.

## 3.3.0

- Upgrade Terraform image to `terraform/v1.8` to patch critical vulnerability CVE-2024-3817.

## 3.2.1

- Add safe.directory config for `.terraform_docs` extension.

## 3.2.0

- Update pipeline to support GCP VM service account.

## 3.1.1

- Update Azure `DEFAULT_POLICY_EVALUATION_DELAY` to `300`s.
- Relocate CI Variables section to the root README.md

## 3.1.0

- Support compliance rule exclusion on `Azure` and `AWS`.
- Change Terraform compliance output of Azure from `resource_ids` to `compliance_resources` for consistency with AWS.
- Re-enable Azure GitLab Managed Identity support.
- Relocate pipeline extends from `README.md` to `runbooks/pipeline-extends.md`.

## 3.0.4

- Disable `validate_tf_usage` job in `BVT_MODE` `FORCE_DEPLOY` mode.
- Adjust exception log into terraform usage script.

## 3.0.3

- Update policy evaluation logging.

## 3.0.2

- Add no_proxy for GCP environment.

## 3.0.1

- Update `.terraform_docs` and `.terraform_usage` to get latest HEAD commit before push back.

## 3.0.0

- Upgrade Terraform Docker image version from `1.5` to `2.0` to pickup the ECS Remote Terraform Provider Registry integration.

## 2.12.3

- Update to version `1.5` of terraform image to pick up latest AWS CLI and resolve GCLOUD CLI path issue.

## 2.12.2

- Remove MSI support because of issues running on shared runners.

## 2.12.1

- Update the Azure compliance test to allow scanning a list or array of resource IDs

## 2.12.0

- Establish Managed Identity authentication support.

## 2.11.0

- Establish Terraform Service README Usage validation.

## 2.10.2

- Upload `terraform.tfstate.gpg` to GitLab artifact by default.

## 2.10.1

- Add default container registry.

## 2.10.0

- Re-group CI variables by Terraform feature.
- Change variable name `TF_STATE_ENCRYPTION_PASSPHRASE` to `CI_ECS_LOCAL_TF_STATE_ENCRYPTION_PASSPHRASE`.
- Update Runner tag for `.checkout_terraform_pipeline_scripts` to run on Boeing K8s Runner instead of dedicated Runner.
- Update `.find_changed_tf` to detect changes in `.sh` and `.go` extensions.
- Replace deprecated `CI_ECS_DOCKER_REGISTRY` by `ENTERPRISE_DOCKER_REGISTRY` to reduce number of required CI variables.
- Replace deprecated `python:0.9.0` docker image by `python/v3.9:0`.
- Establish `TF_VAR_ci_tags` to reserve `TF_VAR_tags` for project team's usage.

## 2.9.1

- Update `azure-policy-evaluate.sh` script to use resource group information from resourceId since resource group is not available in pipeline.

## 2.9.0

- Relocate publish jobs to `publish` pipeline.

## 2.8.0

- Upgrade terraform docker image from `1.2` to `1.4`.

## 2.7.2

- Display violated rule details

## 2.7.1

- Update condition to trigger periodic rules.

## 2.7.0

- Update `aws-compliance-test.sh` to trigger periodic rules.

## 2.6.0

- Reorganize GitLab functions.
- Recover Az CLI login.

## 2.5.1

- Fix issue with Azure certificate.

## 2.5.0

- Setup GCP authentication.
- Lock Terraform docker image to minor version.

## 2.4.1

- Update to keep Azure certificate for CLI usage.

## 2.4.0

- Update Azure authentication to use certificate and remove client secret support.

## 2.3.0

- Support pipeline schedule.

## 2.2.1

- Update to trim the branch name to the allowable limit before attempting to publish.
- Verify publish status.
- Update to use latest `terraform-docs` docker image.

## 2.2.0

- Support evaluating multiple resources for compliance test.

## 2.1.4

- Establish encryption functions for Terraform state file.
- Update `checkout_terraform_pipeline_scripts` to use `checkout_repository`.
- Update pipeline references.

## 2.1.3

- Update to `.tflint` job to use updated `tflint` image.

## 2.1.2

- Update to retain tfstate files even when job fails to support destroy job using `when: always`.

## 2.1.1

- Convert all non alphanumeric characters in branch name to dash for the module publish.

## 2.1.0

- Update to use `terraform/v1.4` docker image.

## 2.0.1

- Check `examples` directory existence for `.terraform_docs` extension.

## 2.0.0

- Utilize Terraform extensions to work with multiple deployment type (examples/*, environments/*)

## 1.2.1

- Change format of `TF_VAR_tags` to `json` for service backend tags handling.

## 1.2.0

- Integrate tflint.

## 1.1.2

- Change CI reference from `jobUrl` to `pipelineUrl` to avoid tag change between `apply` and `terratest` jobs.

## 1.1.1

- Temporarily accept AWS access key as optional.

## 1.1.0

- Establish a policy evaluation script for Azure.

## 1.0.7

- Customize publish extend to work in branches.

## 1.0.6

- Keep the go.mod file if it is uploaded with the terratest code.

## 1.0.5

- Update terraform init directory for csp backend.

## 1.0.4

- Update to latest `terraform` image that is based on catalog terraform image.

## 1.0.3

- Update to use catalog python image to avoid Boeing linux repot unavailability.

## 1.0.2

- Put back unused find-changed-terraform.py script since non updated pipeline references are still using it.

## 1.0.1

- Remove unused `checkout_terraform_pipeline_scripts` job.

## 1.0.0

- Update pipeline to utilize the EC2 instance profile for terraform deployment.
- Update production terraform registry endpoint.
- Integrate unified find-changed.
- Utilize `validate-version` job from `general/.shared` pipeline.
- Establish CI tags.
- Integrate `FORCE_DEPLOY` mode.

## 0.14.2

- Relocate CSP detection, terraform CSP init.

## 0.14.1

- Remove redundant terraform init for terraform docs job.

## 0.14.0

- Update setup_terraform_credential extend for auto-detect and configure authentication for multi-Cloud Service Providers.

## 0.13.0

- Integrate markdown linting.
- Utilize `.get_pipeline_info` extend from `general/.shared` pipeline.

## 0.12.0

- Establish `publish` stage to publish module to SRES Terraform Registry.

## 0.11.1

- Update to latest `terradocs` image that is based on catalog terraform image.

## 0.11.0

- Update the `terradocs` job to automate pushing `README.md` to Gitlab.

## 0.10.5

- Correcting terraform docker image version.

## 0.10.4

- Update to use latest terraform docker image.

## 0.10.3

- Update terraform_docs job to be manual.

## 0.10.2

- Updated terraform image to version `1.2.9`
- Updated to use catalog terraform-doc image.
- Removed install_go extend since go is already installed in new terraform image.

## 0.10.1

- Replace `export_tf_ci_vars` extend by `variables` section in the shared pipeline.

## 0.10.0

- Support Google Cloud Platform (GCP).

## 0.9.1

- Auto-detect cloud provider based on the configured terraform template.

## 0.9.0

- Initialize Terraform `shared` pipeline.
