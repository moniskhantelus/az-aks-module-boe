# CHANGELOG

This file is used to list changes made in each version of the `module` pipeline.

## 5.0.0

- Add `catalog-dependency-scan` job that detects outdated IaC Terraform templates.

## 4.2.1

- Upgrade publish pipeline reference from `publish_0.9` to `publish_1.0`.
- Reorder pipeline includes to prioritize shared pipeline overrides over publish pipeline.

## 4.2.0

- Added support for `.coverity` job to identify defects and security vulnerabilities in Terraform templates.  

## 4.1.1

- Update `checkov` job to add `checkout_terraform_pipeline_scripts` job as dependency.

## 4.1.0

- Replaced the `terrascan` Terraform scanning job with `checkov` to provide broader checks for compliance, misconfiguration, and security best practices.

## 4.0.0

- Update to use `shared_4.0` to adopt the new `lint_cm` (formerly `validate_version`) to validate compliance requirements such as information marking in addition to validating version updates.

## 3.5.0

- Support `estimate_cost` job to validate infrastructure cost.
- Support `terrascan` job to detect compliance and security issues in infrastructure-as-code (IaC) before deployment.

## 3.4.0

- Update `destroy` job replace `needs` to `dependencies` to avoid early job execution, ensure the pipeline flow.
- Update `destroy` job to remove dependency on `terratest` and `compliance_test` so the job can run when test failed.

## 3.3.1

- Update pipeline reference from `shared_3.4` to `shared_3.5` to pickup `terratest` allow fail.

## 3.3.0

- Update pipeline reference from `shared_3.3` to `shared_3.4` to pickup `lint_tf_usage` fix.

## 3.2.1

- Update pipeline reference from `shared_3.2` to `shared_3.3` to patch critical vulnerability CVE-2024-3817.

## 3.2.0

- Update pipeline reference from `shared_3.1` to `shared_3.2` to pickup the dedicated GCP Runner Service Account support.

## 3.1.0

- Update pipeline reference from `shared_3.0` to `shared_3.1` to pickup the compliance exclusion feature.
- Enforce compliance test.

## 3.0.0

- Update pipeline reference from `shared_2.12` to `shared_3.0` to pickup the ECS Remote Terraform Provider Registry integration.

## 2.12.0

- Update pipeline reference from `shared_2.11` to `shared_2.12` to integrate Managed Identity Authentication support.

## 2.11.0

- Add stage `.publish_validation` as a placeholder for the Usage Validation job.
- Update pipeline reference from `service_2.10` to `service_2.11`.

## 2.10.2

- Exclude `validate_version` for `main` pipeline to allow re-running.

## 2.10.1

- Remove `terraform.tfstate.gpg` from GitLab artifact since it is defined in `.shared` pipeline.

## 2.10.0

- Update pipeline reference to `shared_2.10`.

## 2.9.1

- Add default value for `TF_PUBLISH_MODULE_NAMESPACE`.

## 2.9.0

- Upgrade the pipeline reference `publish_0.9` for publishing jobs.

## 2.8.0

- Update pipeline reference to `shared_2.8` for terraform docker image version `1.4`.

## 2.7.0

- Update pipeline reference to `shared_2.7` for the new compliance script changes.

## 2.6.0

- Update GitLab function references.
- Update pipeline reference to `shared_2.6`.

## 2.5.0

- Upgrade pipeline reference for GCP authentication.

## 2.4.0

- *[Breaking changes]* Upgrade pipeline reference for Azure certificate authentication.

## 2.3.0

- Support pipeline schedule.

## 2.2.0

- Support evaluating multiple resources for compliance test.

## 2.1.1

- Encrypt local Terraform state file to secure credential content.

## 2.1.0

- Update to use `terraform/v1.4` docker image.

## 2.0.2

- Update terraform_docs job.

## 2.0.1

- Fix the shared pipeline reference to latest.

## 2.0.0

- Support multiple example deployments.
- Restructure the terraform module template and pipeline.

## 1.2.1

- Fix shared pipeline reference.

## 1.2.0

- Establish terraform linting job.

## 1.1.3

- Add sleep for AWS compliance test to wait for the deployment to be ready.

## 1.1.2

- Exclude `apply` job from tag pipeline.

## 1.1.1

- Update `compliance-test` to run in parallel with `terratest`.

## 1.1.0

- Integrate Azure Policy Compliance test.

## 1.0.7

- Update publish condition.

## 1.0.6

- Remove allow failure for markdown linting.

## 1.0.5

- Improve runner tagging mechanism for multi-clouds support.

## 1.0.4

- Update to refer to tagged version of shared pipeline.

## 1.0.3

- Add `when: always` to terratest job to retain `tfstate` for destroy stage on terratest failure.

## 1.0.2

- Add dependency on compliance test for destroy.

## 1.0.1

- Remove unused `checkout_terraform_pipeline_scripts` job.
- Remove required region output for compliance test.

## 1.0.0

- Integrate AWS compliance test.
- Update pipeline to utilize the EC2 instance profile for terraform deployment.
- Exclude deployment on `tags` pipelines.
- Integrate `FORCE_DEPLOY` mode.

## 0.15.2

- Separate CSP detection.
- Rename terraform init.

## 0.15.1

- Temporarily allow failure for markdown linting because of a bug in the `find_changed_md` job.

## 0.15.0

- Integrate markdown linting.
- Move `validate_version` job from `version` to `validate` stage to utilize pipeline execution duration.

## 0.14.0

- Establish publish jobs for the module pipeline.

## 0.13.0

* Update the `terradocs` job to automate pushing `README.md` to Gitlab.

## 0.12.3

- Remove install go extend from terratest stage.
- Update pipeline to use ECS Catalog terraform images.

## 0.12.2

- Setup terraform credential for `validate_tf` job.
- Replace `export_tf_ci_vars` extend by `variables` section in the shared pipeline.

## 0.12.1

- Make the terraform template directory configurable via CI variable.

## 0.12.0

- Refactor `default` pipeline into `module` pipeline

## 0.11.4

- Trigger the pipeline to populate multi-version tags.

## 0.11.3

- Trigger the pipeline to populate multi-version tags.

## 0.11.2

- Fix incorrect SRES endpoint for `terradocs` job.
- Optimize `pipeline.yml` anchors.

## 0.11.1

- Exclude `validate_version` and `terraform_docs` jobs from `tags` pipelines.

## 0.11.0

- Support latest `validate-version` script.

## 0.10.0

- Replace `semver` with `validate_version` for `version` stage.
- Add `find_changed_tf` to control terraform jobs execution.

## 0.9.0

- Initial release of the `default` pipeline.
