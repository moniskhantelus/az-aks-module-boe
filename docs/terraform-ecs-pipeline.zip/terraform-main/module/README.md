[![release](https://img.shields.io/badge/release-public%20preview-blue.svg?style=flat)](hhttps://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#public-preview)
[![build status](/../../../badges/main/pipeline.svg)](#)
[![version](https://img.shields.io/badge/version-5.0.0-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)

# Terraform Module Pipeline

The `module/pipeline.yml` pipeline contains stages and jobs for the Terraform module pipeline. This pipeline inherits from `.shared/pipeline.yml`.

- [Terraform Module Pipeline](#terraform-module-pipeline)
  - [Pipeline Components](#pipeline-components)
    - [Variables](#variables)
    - [Default Pipeline](#default-pipeline)
    - [Extended Pipeline](#extended-pipeline)
  - [Stages](#stages)
    - [checkout](#checkout)
    - [secret\_detection](#secret_detection)
    - [find\_changed](#find_changed)
    - [validate](#validate)
    - [documentation](#documentation)
    - [deploy](#deploy)
    - [test](#test)
    - [destroy](#destroy)
    - [publish](#publish)
    - [tag](#tag)
  - [Usage](#usage)
    - [Default Pipeline Usage](#default-pipeline-usage)
    - [Extended Pipeline Usage](#extended-pipeline-usage)

## Pipeline Components

### Variables

For general Terraform pipeline variable setup, refer to [Pipeline Variables](../README.md#variables) section.

### Default Pipeline

ECS Terraform Module pipeline supports a default single-deployment pipeline with the following configuration:

| **Name**                    | **Requied** | **Default Value**                     | **Description**                                                                                                                           |
| --------------------------- | ----------- | ------------------------------------- | ----------------------------------------------------------------------------------------------------------------------------------------- |
| TF_DEFAULT_PIPELINE_DIR     | *false*     | `${CI_PROJECT_DIR}/examples/complete` | Directory path to the default example template for default deployment.<br>The default pipeline will be omitted if this variable is unset. |
| TF_PUBLISH_MODULE_NAMESPACE | *false*     | `ecs`                                 | Default Terraform Registry namespace for module pipeline.                                                                                 |

### Extended Pipeline

ECS Terraform Module pipeline also offers optional job extensions that are utilized and ready to be integrated for additional deployments in the Terraform pipeline:

- `.validate_tf`
- `.apply`
- `.terratest`
- `.compliance_test`
- `.destroy`

The following table describes job-level variables that are used to control the extended deployment. Any `Required` variable is only required when using the extended pipeline.

| **Name**         | **Required** | **Default Value**                                                      | **Description**                                                                                        |
| ---------------- | ------------ | ---------------------------------------------------------------------- | ------------------------------------------------------------------------------------------------------ |
| TF_TEMPLATE_DIR  | ***true***   | *N/A*                                                                  | The directory that contains example terraform template.                                                |
| TF_VAR_FILE      | *false*      | `${TF_TEMPLATE_DIR}/terraform.tfvars`                                  | The deployment input value.                                                                            |
| TF_TERRATEST_DIR | *false*      | `tests/$(realpath --relative-to=${CI_PROJECT_DIR} ${TF_TEMPLATE_DIR})` | Relative path to the terratest directory of the corresponding example.<br>*Eg: tests/examples/complete |

## Stages

The full pipeline has the following stages:

```text
checkout > secret_detection > prereq > find_changed > validate > documentation > deploy > test > destroy > publish > tag
```

- Terraform pipeline will follow guidance from [terraform guidance](https://git.web.boeing.com/ECS-Catalog/guidance/terraform) to align with the security and operational profile of an ECS environment and the build/deployment pipelines to support them.
- Terraform pipeline extends from [general pipeline](https://git.web.boeing.com/ECS-Catalog/pipelines/general) to reuse standard GitLab CI pipelines.

The details of the Terraform Pipeline's stages:

### checkout

| Job                                        | Description                                                                                                                                            |
| ------------------------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------ |
| checkout_secret_detection_pipeline_scripts | To pull the secret detection script from the [ECS Catalog General](https://git.web.boeing.com/ECS-Catalog/pipelines/general) GitLab repository.        |
| checkout_shared_pipeline_scripts           | To pull the shared pipeline scripts from the [ECS Catalog General](https://git.web.boeing.com/ECS-Catalog/pipelines/general) GitLab repository.        |
| checkout_terraform_pipeline_scripts        | To pull the terraform pipeline scripts from the [ECS Catalog Terraform](https://git.web.boeing.com/ECS-Catalog/pipelines/terraform) GitLab repository. |

### secret_detection

| Job              | Description                                                                                                                                                                                                                                                        |
| ---------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ |
| secret_detection | To detect and report secrets like keys, passwords, and API tokens unintentionally committed to GitLab repositories.<br> Reference: [ECS Catalog Secret Detection Pipeline](https://git.web.boeing.com/ECS-Catalog/pipelines/general/-/tree/main/secret-detection). |

### find_changed

| Job                   | Description                                                 |
| --------------------- | ----------------------------------------------------------- |
| find_changed_tf       | To find changes in terraform files to determine next steps. |
| find_changed_markdown | To find changes in md files.                                |

### validate

| Job                     | Description                                                                                                                                                                                                                                                                                   |
| ----------------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| validate_tf             | To validate whether a configuration is syntactically valid and internally consistent, regardless of any provided variables or existing state.                                                                                                                                                 |
| estimate_cost           | To validate infrastructure cost before terraform resources are applied                                                                                                                                                                                                                        |
| lint_cm                 | To validate the version increment version matching of all version-related files in dev branches and CM compliance standards.<br>Reference: [ECS Catalog Validate Version Job Extension](https://git.web.boeing.com/ECS-Catalog/pipelines/general/-/tree/main/.shared#validate_version)        |
| lint_markdown           | To check markdown files and flag style issues.<br>Reference: [ECS Catalog Markdown Pipeline](https://git.web.boeing.com/ECS-Catalog/pipelines/markdown/-/tree/main/default)                                                                                                                   |
| lint_tf                 | To lint terraform template for best practice.                                                                                                                                                                                                                                                 |
| checkov                 | Scan cloud infrastructure configurations for security and compliance misconfigurations                                                                                                                                                                                                        |
| coverity                | To identify defects and security vulnerabilities in Terraform templates.                                                                                                                                                                                                                      |
| catalog_dependency_scan | To detect outdated IaC Terraform templates.                                                                                                                                                                                                                                                   |

### documentation

| Job            | Description                                                                                       |
| -------------- | ------------------------------------------------------------------------------------------------- |
| terraform_docs | To generate documentation from Terraform modules in various output formats. This is a manual job. |

### deploy

| Job   | Description                          |
| ----- | ------------------------------------ |
| apply | To trigger the Terraform deployment. |

### test

| Job             | Description                                                                                                                                                                                                           |
| --------------- | --------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| terratest       | To perform integration test againsts the deployment that provisoned by the `apply` job. <br> *Note: Terratest uses Go language so Go must be pre-installed.*                                                          |
| compliance_test | To verify the compliance status of resources created by the Terraform IaC against Boeing policy and guidance. Resources are evaluated using `NIST 800` guidelines. *Note: This job currently supports Azure and AWS.* |

### destroy

| Job     | Description                                                 |
| ------- | ----------------------------------------------------------- |
| destroy | To destroy resources that are created by the terratest job. |

### publish

| Job          | Description                                                                                                                                                                                                                |
| ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| publish_dev  | To publish module on dev branch to SRES Terraform Registry.<br>Reference: [ECS Catalog Terraform Publish Dev Job Extension](https://git.web.boeing.com/ECS-Catalog/pipelines/terraform/-/tree/main/publish#publish_dev)    |
| publish_prod | To publish module on main branch to SRES Terraform Registry.<br>Reference: [ECS Catalog Terraform Publish Prod Job Extension](https://git.web.boeing.com/ECS-Catalog/pipelines/terraform/-/tree/main/publish#publish_prod) |

### tag

| Job | Description                                                                    |
| --- | ------------------------------------------------------------------------------ |
| tag | To create a tag for the released version in the Terraform's GitLab repository. |

## Usage

### Default Pipeline Usage

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: module_5.0
    file: /module/pipeline.yml

default:
  tags:
    - docker
```

### Extended Pipeline Usage

The following snippet demonstrates a sample additional deployment using job extensions.

```yml
validate_tf_2:
  extends: .validate_tf
  variables:
    TF_TEMPLATE_DIR: examples/complete_2

estimate_cost_2:
  extends: .estimate_cost
  variables:
    TF_TEMPLATE_DIR: examples/complete_2

checkov2:
  extends: .shared_checkov
  variables:
    TF_TEMPLATE_DIR: examples/complete_2

coverity2:
  extends: .coverity
  variables:
    TF_TEMPLATE_DIR: examples/complete_2

apply_2:
  extends: .apply
  variables:
    TF_TEMPLATE_DIR: examples/complete_2

terratest_2:
  extends: .terratest
  variables:
    TF_TEMPLATE_DIR: examples/complete_2
  dependencies:
    - find_changed_tf
    - apply_2

compliance_test_2:
  extends: .compliance_test
  variables:
    TF_TEMPLATE_DIR: examples/complete_2

destroy_2:
  extends: .destroy
  variables:
    TF_TEMPLATE_DIR: examples/complete_2
  dependencies:
    - find_changed_tf
    - apply_2
```

*Note: Job `dependencies` and `needs` are required for the pipeline functionality.*
