[![release](https://img.shields.io/badge/release-general%20availability-green.svg?style=flat)](hhttps://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#public-preview)
[![build status](/../../../badges/main/pipeline.svg)](#)
[![version](https://img.shields.io/badge/version-1.0.0-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)

# Terraform Publish Pipeline

The `publish/pipeline.yml` pipeline contains stages and jobs for the Terraform publish pipeline.

- [Terraform Publish Pipeline](#terraform-publish-pipeline)
  - [Prerequsites](#prerequsites)
    - [Terraform Registry](#terraform-registry)
  - [Pipeline Components](#pipeline-components)
    - [Variables](#variables)
      - [Pipeline-Level Variables](#pipeline-level-variables)
      - [CI Variables](#ci-variables)
    - [Script Extends](#script-extends)
      - [`.publish`](#publish)
      - [`.publish_dev`](#publish_dev)
      - [`.publish_prod`](#publish_prod)
  - [Usage](#usage)

## Prerequsites

### Terraform Registry

This pipeline requires at least one existing Terraform Registry in SRES. SRES repository requirement:

- Package Type: `Terraform`
- Repository Layout: `terraform-module-default`

It is recommended to have 2 Registries to support development and official releases. Eg:

- `<project>-terraform-modules-release-local`: Official Registry. Published in `main` branch only.
- `<project>-terraform-modules-snapshot-local`: Development Registry. Published in dev branches by developer.

## Pipeline Components

### Variables

#### Pipeline-Level Variables

The following table describes variables that are configurable in the Terraform pipeline via `.gitlab-ci.yml` file:

| **Name**                     | **Required** | **Default Value**                                                                                    | **Description**                                                                 |
| ---------------------------- | ------------ | ---------------------------------------------------------------------------------------------------- | ------------------------------------------------------------------------------- |
| TF_PUBLISH_URL               | *False*      | `https://sres.web.boeing.com/artifactory`                                                            | The Terraform Registry endpoint.                                                |
| TF_PUBLISH_MODULE_NAMESPACE  | *False*      | `ecs`                                                                                                | The Terraform Registry namespace that the module is published to.               |
| TF_PUBLISH_DEFAULT_EXCLUSION | *False*      | `.git;pipeline-scripts;shared-pipeline-scripts;.terraform;.jfrog;examples;test;markdown-lint.config` | The list of files/directories that are excluded from the module publish.        |
| JFROG_CLI_LOG_LEVEL          | *False*      | `INFO`                                                                                               | The logging level of JFrog CLI that publishes the Terraform module to Registry. |

#### CI Variables

| **Name**                             | **Required** | **Description**                                                                                                                                                                                                                                          |
| ------------------------------------ | ------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| CI_ECS_SRES_HOST                     | **True**     | The Artifactory host URL. <br>This is required for `publish` jobs.                                                                                                                                                                                       |
| CI_ECS_SRES_TOKEN                    | **True**     | The associated credential to authenticate to the given `CI_ECS_SRES_HOST`.                                                                                                                                                                               |
| CI_ECS_TERRAFORM_REGISTRY_REPOSITORY | **True**     | Specifies the destination repository that the module is published to in the Terraform Registry.<br>This variable should have 2 environments for the best practice:<br>- `dev` environment for development publish.<br>- Default environment for release. |

### Script Extends

#### `.publish`

To publish module to Terraform Registry.

**NOTE:** Because of the limitation of allowed characters in the Artifactory Terraform Registry, all non alphanumeric characters in branch names will be converted to a `-` during the publish process.

Usage

```yaml
publish_dev:
  stage: publish
  script:
    - !reference [.publish, script]
```

#### `.publish_dev`

To publish a module on dev branch to Terraform Registry. The module will be published using the following pattern:

```bash
${TF_PUBLISH_URL}/${CI_ECS_TERRAFORM_REGISTRY_REPOSITORY}/${TF_PUBLISH_MODULE_NAMESPACE}/${CI_PROJECT_NAME}-${CI_COMMIT_BRANCH}/${CI_ECS_CLOUD_SERVICE_PROVIDER}/version.zip
```

** Note**: Because of the requirement of Terraform Registry, the module name will be trimmed to 240 characters at maximum before attempting to publish.

Usage

```yaml
publish_dev:
  stage: publish
  extends: .publish_dev
  when: manual
  except:
    refs:
      - tags
      - main
  tags:
    - ""
```

#### `.publish_prod`

To publish a module on `main` branch to Terraform Registry. The module will be published using the following pattern:

```bash
${TF_PUBLISH_URL}/${CI_ECS_TERRAFORM_REGISTRY_REPOSITORY}/${TF_PUBLISH_MODULE_NAMESPACE}/${CI_PROJECT_NAME}/${CI_ECS_CLOUD_SERVICE_PROVIDER}/version.zip
```

Usage

```yaml
publish_prod:
  stage: publish
  extends: .publish_prod
  when: manual
  only:
    refs:
      - main
  except:
    refs:
      - tags
  tags:
    - ""
```

## Usage

```yml
include:
  - project: ecs-catalog/pipelines/terraform
    ref: publish_1.0
    file: /publish/pipeline.yml
```
