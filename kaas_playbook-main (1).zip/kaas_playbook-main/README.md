[![information](https://img.shields.io/badge/information-boeing%20proprietary-blue.svg?style=flat)](https://besweb.web.boeing.com/Information%20Protection/InfoTypes)
[![export](https://img.shields.io/badge/export-earn-00c900.svg?style=flat)](http://globaltradecontrols.web.boeing.com/policyguidance/emip.html#earn)
[![release](https://img.shields.io/badge/release-private%20preview-red.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#private-preview)
[![esats](https://img.shields.io/badge/esats-3678542-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md)
[![version](https://img.shields.io/badge/version-26.06-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)
[![guidance](https://img.shields.io/badge/guidance-standards-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/guidance/terraform/-/blob/main/README.md)


> ⚠️ **DRAFT** — This document is a draft version and subject to change. Not yet approved for production use.

# MRC Strata(aka KaaS): The Secure Container Runtime

| Pillar | Phase |
|--------|-------|
| **Run** | **Steady State** |

---

## Application Team Benefit

A **push-to-deploy** experience. Teams focus exclusively on application logic while the platform handles the hardening, scaling, and high-availability architecture required for Aerospace and Defense.


## Table of Contents

| # | Section | Description |
|---|---------|-------------|
| 1 | [🤝 Team Practices](team-practices/) | Team collaboration, daily demos, peer programming, knowledge sharing, issue tracking |
| 2 | [🏛️ Repo Standards](repo-standards/) | Repository naming, branching, commit messages, and code review |
| 3 | [📐 Repo Model](repo-model/) | RAC model, lifecycle diagrams, app onboarding tracker |
| 4 | [👤 Personas](personas/) | Developer, end-user, platform engineer, and security persona definitions |
| 5 | [💰 FinOps](finops/) | Shared billing model and cloud financial operations |
| 6 | [🚀 Deployment](deployment/) | Environment subscriptions and deployment guidelines |
| 7 | [☁️ Azure Naming Standards](azure_naming_standards/) | Azure resource naming conventions and standards |
| 8 | [🏷️ Tagging](tagging/) | Mandatory Azure resource tagging — 5 tags covering compliance, operations, identity, contacts, and workload infra |


---

## Overview

This repository is the single source of truth for standards, practices, and guidelines across all Strata aka KaaS platform teams. Every team member from platform engineers to application developers, is expected to follow these Boeing standards to ensure consistency, security, and operational excellence.




---

## Architecture Overview

```
┌─────────────────────────────────────────────────────┐
│            MRC Strata Platform ( aka KaaS )         │
├─────────────────────────────────────────────────────┤
│          ┌─────────────┐  ┌──────────────┐          │
│          │   AWS-EKS   │  │   Azure-AKS  │          │
│          │  K8s Cluster│  │  K8s Cluster │          │
│          └─────┬───────┘  └─────┬────────┘          │
│                │                │                   │
│                └───────┬────────┘                   │
│                        │                            │
│              ┌─────────▼─────────┐                  │
│              │  Identical Ops    │                  │
│              │  Interface        │                  │
│              └───────────────────┘                  │
└─────────────────────────────────────────────────────┘

```
All providers deliver **identical operational interfaces** regardless of the underlying CSP.
--

### 🤝 Team Practices

- [Team Practices](team-practices/team-practices.md) — Daily demos, peer programming, knowledge sharing, issue tracking (Jira + GitLab), MS Teams channels


### 🏛️ Repo Standards

- [Branching Strategy](repo-standards/branching-strategy.md)
- [Commit Message Policy](repo-standards/commit-message-policy.md)
- [Code Review Checklist](repo-standards/code-review-checklist.md)

### 📐 Repo Model

- [KaaS Platform RAC Guide](repo-model/kaas_platform_rac_guide.md) — GitLab group structure, subgroup ownership, platform lifecycle
- [Platform Lifecycle Diagrams (Mermaid)](repo-model/kaas_platform_lifecycle.md) — Editable Mermaid diagrams for all workflows
- [App Onboarding Tracker](repo-model/app_onboarding_tracker.md) — Registry and checklist for tracking onboarded applications

### 👤 Personas

- [Developer Persona](personas/developer-persona.md)
- [End-User Personas](personas/end-user-personas.md)
- [Platform Engineer Persona](personas/platform-engineer-persona.md)
- [Security Persona](personas/security-persona.md)

### 💰 FinOps

- [FinOps Shared Billing Model](finops/finops_sharedbilling_model.md)

### 🚀 Deployment

- [Environment Subscriptions](deployment/env-subscriptions.md)

### ☁️ Azure Naming Standards

- [Azure Naming Standards](azure_naming_standards/azure_naming_standards.md)


### 🏷️ Tagging

- [Azure Tagging Standards](tagging/azure_tagging_standards.md) — Five mandatory tags: `ECS_CSF_TAG` (compliance), `ECS_HPOO_TAG` (ops routing), `KAAS_TAG` (identity & SLA), `KAAS_EXT_TAG` (contacts & billing), `KAAS_INFRA_TAG` (workload & network). Includes Terraform examples and field-level documentation.



## How to Use This Repository

1. **New team members** — Read through each section as part of onboarding
2. **Starting a new project** — Reference repo standards and pipeline templates
3. **Deploying** — Follow deployment and GitOps guidelines
4. **Reviewing code** — Use the code review checklist
5. **Proposing changes** — Submit a merge request to update standards

---

## Contributing

Standards are living documents. To propose a change:

1. Create a branch following `dev_<YYMM>`
2. Update the relevant markdown file
3. Submit a merge request with the `standards-update` label
4. Require approval from at least 2 platform team leads

---

## Related Documentation

- [MRC Strata Overview](../README.md)
- [KaaS Persona Guide](personas/)
- [CDP-ADR](https://git.web.boeing.com/ECS-Catalog/governance/cdp-architecture/decision-records)