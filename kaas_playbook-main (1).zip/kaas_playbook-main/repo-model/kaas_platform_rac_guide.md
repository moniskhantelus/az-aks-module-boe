# KaaS Platform — Repo as Code (RAC) Model

[![information](https://img.shields.io/badge/information-boeing%20proprietary-blue.svg?style=flat)](https://besweb.web.boeing.com/Information%20Protection/InfoTypes)
[![export](https://img.shields.io/badge/export-earn-00c900.svg?style=flat)](http://globaltradecontrols.web.boeing.com/policyguidance/emip.html#earn)
[![release](https://img.shields.io/badge/release-private%20preview-red.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#private-preview)
[![esats](https://img.shields.io/badge/esats-3678542-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md)
[![version](https://img.shields.io/badge/version-26.08-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)
[![guidance](https://img.shields.io/badge/guidance-draft-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/guidance/terraform/-/blob/main/README.md)

> KaaS (Kubernetes as a Service) GitLab group structure.
> Covers subgroup ownership, pipeline design, IaC catalog modules, app onboarding,
> and the complete platform lifecycle using a Repo-as-Code approach.

---

## Table of Contents

1. [Platform Lifecycle](#platform-lifecycle)
2. [High-Level Architecture](#high-level-architecture)
3. [GitLab Group Structure](#gitlab-group-structure)
4. [governance/](#governance)
5. [platform/ (Parent Subgroup)](#platform-parent-subgroup)
   - [platform/platform-infra/](#platformplatform-infra)
   - [platform/platform-common/](#platformplatform-common)
6. [container/](#container)
7. [Catalog — IaC Terraform Modules](#catalog--iac-terraform-modules)
8. [Pipelines Subgroup](#pipelines-subgroup)
9. [Apps Subgroup — Business Unit Structure](#apps-subgroup--business-unit-structure)
10. [Platform Lifecycle Workflow (Mermaid)](#platform-lifecycle-workflow-mermaid)
11. [App Onboarding Workflow](#app-onboarding-workflow)
12. [Namespace and Resource Mapping](#namespace-and-resource-mapping)
13. [Ownership Matrix](#ownership-matrix)

---

## Platform Lifecycle

The KaaS platform follows a phased provisioning model with clear handoff points:

1. **Cluster Provisioning** — Infrastructure Team provisions AKS/EKS clusters (core + per-org) via Terraform.
2. **Platform Services** — Platform Operations Team deploys observability, security, GitOps, ingress, and policy services independently.
3. **App Onboarding** — Platform + FinOps Team provisions app group, repos, namespace, and cloud resources per application.
4. **App Delivery** — App Team builds containers and deploys via Helm into their assigned namespace. Continuous delivery repeats from here.

```
INFRASTRUCTURE TEAM          PLATFORM OPS TEAM          APP TEAM
─────────────────────        ─────────────────────      ─────────────────────────────

Phase 1: Cluster Provisioning
  platform/platform-infra/
  • Provision core cluster
  • Provision org clusters (cs, hr, fs)
  • Platform ACR, networking, identity
         │
         ├──────────────────▶ Phase 2: Platform Services
         │                    platform/platform-common/
         │                    • Observability (Prometheus, Grafana)
         │                    • Security (Defender, scanning)
         │                    • GitOps (ArgoCD bootstrap)
         │                    • Ingress + TLS
         │                    • Policy enforcement
         │                    • Secret management
         │                             │
         │                             ▼
         │                    Cluster fully operational
         │
         ▼
Phase 3: App Onboarding
  apps/<bu>/<esatsid>/
  • Create -app and -iac repos
  • Namespace + ACR + KV + Log
  • RBAC + FinOps UUID
         │
         └────────────────────────────────────────▶ Phase 4: App Delivery
                                                    • Build image → push to ACR
                                                    • Helm deploy → namespace
                                                    • Rolling updates, rollback
                                                    • (Repeats per release)
```


---
## High-Level Architecture

```
+-----------------------------------------------------------------------------------+
|                           KaaS (Parent Group)                                     |
+-----------------------------------------------------------------------------------+
|                                                                                   |
|  +-- governance/         Rules, policies, compliance, risk, accountability        |
|  |                                                                                |
|  +-- apps/               Application teams by Business Unit (BU)                  |
|  |   +-- cs/             Corporate Systems                                       |
|  |   +-- fs/             Financial Services                                      |
|  |   +-- hr/             Human Resources                                         |
|  |   +-- ps/             Product Support                                         |
|  |                                                                                |
|  +-- platform/           Platform Engineering parent subgroup                     |
|  |   |                                                                            |
|  |   +-- platform-infra/     Cluster provisioning IaC (per org cluster)           |
|  |   |   +-- core/           Core/CDP platform cluster (GitOps, ingress, monitor) |
|  |   |   +-- cs/             CS org cluster IaC                                   |
|  |   |   +-- hr/             HR org cluster IaC                                   |
|  |   |   +-- fs/             FS org cluster IaC                                   |
|  |   |                                                                            |
|  |   +-- platform-common/    Operational services (applied post-cluster)           |
|  |       +-- observability/  Log Analytics, Prometheus, Grafana, Alerts            |
|  |       +-- security/       Defender, image scanning, admission webhook           |
|  |       +-- gitops/         ArgoCD, app-of-apps bootstrap, sync policies          |
|  |       +-- ingress/        Ingress controller, cert-manager, TLS                 |
|  |       +-- secret-mgmt/    CSI Secret Store, Workload Identity bindings          |
|  |       +-- policy/         Kyverno / OPA, namespace quotas, pod security         |
|  |                                                                                |
|  |   +-- infra-lab/          Infrastructure experiments (platform team only)       |
|  |       +-- experiments/    Short-lived spikes on cluster configurations          |
|  |       +-- sandbox-clusters/ Ephemeral AKS/EKS clusters (no SLA, tear down any) |
|  |       +-- module-testing/ Test catalog modules before publishing                |
|  |                                                                                |
|  +-- container/          Platform container images                                |
|  |   +-- base-images/    Hardened OS images (UBI, Debian-slim)                    |
|  |   +-- runtime-images/ Language runtimes (Node, Python, Java, .NET)             |
|  |   +-- sidecar-images/ Platform sidecars (proxies, exporters, agents)           |
|  |   +-- support-images/ Supporting tooling images (init containers, utilities)   |
|  |                                                                                |
|  +-- catalog/            Reusable IaC modules (when ECS Catalog lacks coverage)   |
|  |   +-- iac/terraform/azure/                                                     |
|  |       +-- network/         VNet, Subnets, NSG, Private DNS, Peering            |
|  |       +-- aks/             AKS cluster module                                  |
|  |       +-- acr/             Container Registry module                           |
|  |       +-- keyvault/        Key Vault module                                    |
|  |       +-- storage-account/ Storage Account module                              |
|  |       +-- observability/   Log Analytics, Monitor, Diagnostic Settings         |
|  |       +-- identity/        Managed Identity, Workload Identity                 |
|  |       +-- private-endpoint/Private Endpoint module                             |
|  |       +-- dns/             Private DNS Zone module                             |
|  |                                                                                |
|  +-- pipelines/          CI/CD pipeline templates and workflows                   |
|  |   +-- platform-docker-images/    Base + runtime image build pipelines          |
|  |   +-- platform-support-images/   Supporting/utility image build pipelines      |
|  |   +-- platform-sidecar-images/   Sidecar image build pipelines                 |
|  |   +-- iac-platform-deploy/       IaC deployment pipeline (Terraform apply)     |
|  |   +-- iac-module-pipeline/       IaC module CI (lint, validate, publish)       |
|  |   +-- app-ci-pipeline/           App build + push to ACR template              |
|  |   +-- app-cd-pipeline/           App Helm deploy to cluster template           |
|  |   +-- compliance-gates/          Security scan, policy check, approval gates   |
|  |                                                                                |
|  +-- guidance/           Platform documentation                                   |
|  |   +-- kaas_playbook/  Operational playbooks                                    |
|  |   +-- kaas_product_docs/ PRD documentation                                    |
|  |   +-- adr/           Architecture Decision Records                            |
|  |   +-- architecture/  HLD, LLD, diagrams, workflow designs                      |
|  |                                                                                |
|  +-- support/           Support docs accessible to all teams                      |
|  |   +-- runbooks/      Incident response and operational runbooks                 |
|  |   +-- faqs/          Frequently asked questions by topic                        |
|  |   +-- troubleshooting/ Common issues and resolution guides                     |
|  |   +-- onboarding/    New team member onboarding guides                          |
|  |                                                                                |
|  +-- spike/             Technical spikes and feasibility studies                   |
|  +-- trash/             Archived/decommissioned groups                            |
|                                                                                   |
+-----------------------------------------------------------------------------------+
```

---
## GitLab Group Structure

```
kaas/                                              <- PARENT GROUP
|
|-- governance/                                    <- Policies, compliance, risk, accountability
|   |-- policies/                                  <- OPA/Kyverno policy definitions
|   |-- rbac-templates/                            <- Cluster and namespace RBAC templates
|   |-- compliance/                                <- Audit, regulatory controls
|   +-- risk/                                      <- Risk register, boundaries
|
|-- apps/                                          <- Application teams by Business Unit
|   |-- cs/                                        <- Business Unit: Corporate Systems
|   |   +-- esatsidname/                           <- App group (ESATS ID + short name)
|   |       |-- esatsidname-iac/                   <- Helm + Terraform deployment into cluster
|   |       +-- esatsidname-app/                   <- Container image (Dockerfile + source)
|   |
|   |-- fs/                                        <- Business Unit: Financial Services
|   |   +-- esatsidname/
|   |       |-- esatsidname-iac/
|   |       +-- esatsidname-app/
|   |
|   |-- hr/                                        <- Business Unit: Human Resources
|   |   +-- esatsidname/
|   |       |-- esatsidname-iac/
|   |       +-- esatsidname-app/
|   |
|   +-- ps/                                        <- Business Unit: Product Support
|       +-- esatsidname/
|           |-- esatsidname-iac/
|           +-- esatsidname-app/
|
|-- platform/                                      <- Platform Engineering parent subgroup
|   |
|   |-- platform-infra/                            <- Cluster provisioning IaC (per org cluster)
|   |   |   Each org gets its own cluster IaC repo. The core/CDP cluster hosts
|   |   |   shared platform services (ArgoCD, ingress, monitoring control plane).
|   |   |   Org clusters host application workloads for that business unit.
|   |   |
|   |   |-- core/                                  <- Core/CDP platform cluster
|   |   |   |-- terraform/                         <- AKS cluster IaC (private, managed)
|   |   |   +-- .gitlab-ci.yml                     <- IaC pipeline (plan/apply)
|   |   |
|   |   |-- cs/                                    <- CS org cluster IaC
|   |   |   |-- terraform/
|   |   |   +-- .gitlab-ci.yml
|   |   |
|   |   |-- hr/                                    <- HR org cluster IaC
|   |   |   |-- terraform/
|   |   |   +-- .gitlab-ci.yml
|   |   |
|   |   |-- fs/                                    <- FS org cluster IaC
|   |   |   |-- terraform/
|   |   |   +-- .gitlab-ci.yml
|   |
|   |-- infra-lab/                                 <- Infrastructure experiments (platform team only)
|   |   |   Ephemeral clusters, module testing, configuration spikes.
|   |   |   No SLA. Can be created and destroyed at any time.
|   |   |
|   |   |-- experiments/                           <- Short-lived cluster config spikes
|   |   |-- sandbox-clusters/                      <- Ephemeral AKS/EKS for testing
|   |   +-- module-testing/                        <- Validate catalog modules before publish
|   |
|   +-- platform-common/                           <- Operational services (post-cluster)
|       |   Applied independently after any cluster is ready.
|       |   Each service has its own pipeline and can be upgraded
|       |   without touching cluster IaC.
|       |
|       |-- observability/                         <- Log Analytics, Prometheus, Grafana, Alerts
|       |-- security/                              <- Defender, image scanning, admission webhook
|       |-- gitops/                                <- ArgoCD, app-of-apps bootstrap, sync policies
|       |-- ingress/                               <- Ingress controller, cert-manager, TLS
|       |-- secret-mgmt/                           <- CSI Secret Store, Workload Identity bindings
|       +-- policy/                                <- Kyverno / OPA, quotas, pod security standards
|
|-- container/                                     <- Platform container images
|   |-- base-images/                               <- Hardened base OS (UBI, Debian-slim)
|   |-- runtime-images/                            <- Language runtimes (Node, Python, Java)
|   |-- sidecar-images/                            <- Proxies, exporters, agents
|   +-- support-images/                            <- Init containers, utilities, tooling
|
|-- catalog/                                       <- Reusable IaC modules
|   +-- iac/
|       +-- terraform/
|           +-- azure/
|               |-- network/                       <- VNet, Subnets, NSG, DNS, Peering
|               |-- aks/                           <- AKS cluster module
|               |-- acr/                           <- Container Registry module
|               |-- keyvault/                      <- Key Vault module
|               |-- storage-account/               <- Storage Account module
|               |-- observability/                 <- Log Analytics, Monitor, Diagnostics
|               |-- identity/                      <- Managed Identity, Workload Identity
|               |-- private-endpoint/              <- Private Endpoint module
|               +-- dns/                           <- Private DNS Zone module
|
|-- pipelines/                                     <- CI/CD pipeline templates
|   |-- platform-docker-images/                    <- Base + runtime image build pipeline
|   |-- platform-support-images/                   <- Utility/support image build pipeline
|   |-- platform-sidecar-images/                   <- Sidecar image build pipeline
|   |-- iac-platform-deploy/                       <- Terraform plan/apply for infra
|   |-- iac-module-pipeline/                       <- Module CI: lint, validate, publish
|   |-- app-ci-pipeline/                           <- App build + push to ACR template
|   |-- app-cd-pipeline/                           <- App Helm deploy template
|   +-- compliance-gates/                          <- Security scan, policy, approval gates
|
|-- guidance/                                      <- Platform documentation
|   |-- kaas_playbook/                             <- Operational playbooks
|   |-- kaas_product_docs/                         <- PRD documents
|   |-- adr/                                       <- Architecture Decision Records
|   +-- architecture/                              <- HLD, LLD, diagrams, workflow designs
|       |-- hld/                                   <- High-Level Designs
|       |-- lld/                                   <- Low-Level Designs
|       |-- diagrams/                              <- Visio, draw.io, Mermaid source files
|       +-- workflows/                             <- Process workflows, sequence diagrams
|
|-- spike/                                         <- Technical spikes, experiments
|-- support/                                       <- Support docs, runbooks, FAQs (all teams)
|   |-- runbooks/                                  <- Incident response and operational runbooks
|   |-- faqs/                                      <- Frequently asked questions by topic
|   |-- troubleshooting/                           <- Common issues and resolution guides
|   +-- onboarding/                                <- New team member onboarding guides
+-- trash/                                         <- Archived/decommissioned groups
```

---

## governance/

> Definition: The system of rules, policies, and processes used to direct and control the KaaS Platform.
> Core Focus: Structure, Compliance, risk management, boundaries, and legal or structural accountability.

| Repo | Purpose |
|------|---------|
| policies/ | OPA/Kyverno policy definitions and guardrails |
| rbac-templates/ | Cluster and namespace RBAC templates |
| compliance/ | Audit evidence, regulatory controls |
| risk/ | Risk register, accountability boundaries |

---

## platform/ (Parent Subgroup)

> Platform Engineering parent group containing two purposefully separated children:
> platform-infra for cluster provisioning and platform-common for operational services.

### platform/platform-infra/

> Cluster provisioning IaC organised by org. Each org cluster has its own repo.
> The core/CDP cluster hosts shared platform tooling (ArgoCD, centralized monitoring, ingress).
> Org clusters (cs, hr, fs) host application workloads for their business unit.
> Operational services (observability, GitOps, ingress) are NOT part of this subgroup.

| Repo | Purpose | Cluster Type |
|------|---------|-------------|
| core/ | Core/CDP platform cluster — hosts ArgoCD, centralized Prometheus, ingress controllers, policy engines | Shared platform services |
| cs/ | Corporate Systems org cluster — CS application workloads | Org workload cluster |
| hr/ | Human Resources org cluster — HR application workloads | Org workload cluster |
| fs/ | Financial Services org cluster — FS application workloads | Org workload cluster |

Each repo contains:
```
platform-infra/<org>/
|-- terraform/                     <- Terraform modules (consumes catalog/ modules)
|   |-- main.tf
|   |-- variables.tf
|   |-- dev.tfvars
|   |-- nonprod.tfvars
|   +-- prod.tfvars
+-- .gitlab-ci.yml                 <- Pipeline: plan/apply via pipelines/iac-platform-deploy
```

**Cluster topology:**
```
+-----------------------------------------------------------------------+
|                         platform-infra/                                |
+-----------------------------------------------------------------------+
|                                                                       |
|  +-- core/                 +-- cs/         +-- hr/       +-- fs/      |
|  |   CDP Platform Cluster  |   CS Cluster  |  HR Cluster |  FS Cluster|
|  |                         |               |             |            |
|  |   - ArgoCD             |   - CS apps   |  - HR apps  |  - FS apps |
|  |   - Prometheus/Grafana  |   - CS ns     |  - HR ns    |  - FS ns   |
|  |   - Ingress (NGINX)    |               |             |            |
|  |   - cert-manager       |               |             |            |
|  |   - OPA/Kyverno        |               |             |            |
|  |   - Centralized logging|               |             |            |
|  +-------------------------+---------------+-------------+------------+
|                                                                       |
+-----------------------------------------------------------------------+

platform/infra-lab/ (sibling — NOT inside platform-infra)
+-----------------------------------------------------------------------+
|  +-- experiments/          sandbox-clusters/       module-testing/     |
|  |   Config spikes         Ephemeral AKS/EKS      Catalog module      |
|  |   (short-lived)         (no SLA, tear down)    validation          |
+-----------------------------------------------------------------------+
```

---

### platform/platform-common/

> Operational services applied post-cluster via independent pipelines.
> These services are deployed to the core cluster and configured to manage all org clusters.
> Each repo can be upgraded, replaced, or rolled back without touching any cluster IaC.

| Repo | Purpose | Deployed To |
|------|---------|-------------|
| observability/ | Log Analytics, Azure Monitor, Prometheus, Grafana dashboards, alerting rules | Core cluster (manages all) |
| security/ | Defender for Containers, runtime + image scanning, admission webhook | All clusters |
| gitops/ | ArgoCD installation, app-of-apps bootstrap, sync policies | Core cluster |
| ingress/ | Ingress controller (NGINX/AGIC), cert-manager, TLS termination | Core + org clusters |
| secret-mgmt/ | CSI Secret Store driver, Workload Identity bindings, secret rotation | All clusters |
| policy/ | Kyverno or OPA Gatekeeper, namespace quotas, LimitRange, pod security standards | All clusters |

**Separation principle:**

| Concern | platform-infra/ | platform-common/ |
|---------|-----------------|-------------------|
| What | Bare cluster (AKS/EKS) | Services running ON the cluster |
| When | Once per cluster (provisioning) | Continuously (independent upgrades) |
| Change risk | High — cluster re-provision | Low — scoped to one service |
| Owner | Infrastructure Team | Platform Operations Team |
| Can upgrade independently? | No — formal change process | Yes — per-service pipeline |

---

## container/

> A container image is a lightweight, standalone, and executable package that includes everything needed to run an application.
> This subgroup holds platform-level and supporting images. App teams build FROM these via the platform ACR.

| Repo | Purpose |
|------|---------|
| base-images/ | Hardened base OS images (UBI, Debian-slim, Alpine) |
| runtime-images/ | Language runtimes (Node.js, Python, Java, .NET) |
| sidecar-images/ | Platform sidecars (Envoy proxy, OTel collector, Fluent Bit) |
| support-images/ | Supporting/utility images (init containers, debug tools, migration runners) |

---

## Catalog — IaC Terraform Modules

> The catalog subgroup provides reusable, versioned Terraform modules when the ECS Service Catalog
> does not offer suitable modules or when platform-specific customisation is required.
> Modules are consumed by platform-infra and app-iac repos.

```
catalog/iac/terraform/azure/
|-- network/              VNet, Subnets, NSG, Private DNS Zones, VNet Peering
|-- aks/                  AKS cluster with node pools, RBAC, add-ons
|-- acr/                  Azure Container Registry (Premium, private endpoint)
|-- keyvault/             Key Vault with access policies and private endpoint
|-- storage-account/      Storage Account (Blob, File, Queue) with CSI config
|-- observability/        Log Analytics Workspace, Diagnostic Settings, Monitor
|-- identity/             Managed Identity, Workload Identity federated creds
|-- private-endpoint/     Generic private endpoint module for any PaaS service
+-- dns/                  Private DNS Zone creation and VNet linking
```

| Module | Covers | Why Not ECS Catalog |
|--------|--------|---------------------|
| network/ | VNet, Subnets, NSG, Peering, Private DNS | Platform-specific CIDR, peering topology, private cluster requirements |
| aks/ | AKS with private API, node pools, CSI | Needs custom node pool configs, private cluster, Workload Identity |
| acr/ | ACR Premium with geo-replication | Needs private endpoint + specific RBAC for platform MI |
| keyvault/ | Key Vault with RBAC data plane | Platform-specific access policies, CSI integration |
| storage-account/ | Blob, File, Queue with CSI bindings | CSI driver bindings, lifecycle policies specific to KaaS |
| observability/ | Log Analytics, Diagnostic Settings | Platform-wide diagnostic routing, custom retention |
| identity/ | MI + Workload Identity + federated creds | Tight coupling with AKS OIDC issuer |
| private-endpoint/ | Generic PE for any Azure PaaS | Reusable across ACR, KV, Storage, SQL |
| dns/ | Private DNS zone + VNet link | Consistent zone naming and auto-linking |

---

## Pipelines Subgroup

> CI/CD workflows for provisioning and managing infrastructure along with standardized pipeline
> definitions and compliance workflows. Each pipeline template is versioned and consumed via include.

| Pipeline Repo | What It Builds/Deploys | Triggered By |
|---------------|----------------------|--------------|
| platform-docker-images/ | Base + runtime container images (UBI, Node, Python, Java) | Scheduled + on Dockerfile change |
| platform-support-images/ | Utility/supporting images (init containers, migration tools) | On change to support-images/ |
| platform-sidecar-images/ | Sidecar images (Envoy, OTel collector, Fluent Bit) | On change to sidecar-images/ |
| iac-platform-deploy/ | Terraform plan/apply for platform-infra (AKS, networking) | MR merge to env branch |
| iac-module-pipeline/ | Module CI: lint, validate, test, version, publish to registry | MR to catalog/ repos |
| app-ci-pipeline/ | App container build + push to app ACR (template) | App team code push |
| app-cd-pipeline/ | App Helm deploy to cluster namespace (template) | Image tag update in -iac repo |
| compliance-gates/ | Security scanning, policy check, manual approval gates | Every pipeline as include |

### Pipeline Flow

```
Developer push --> app-ci-pipeline --> [Build + Scan + Push to ACR]
                                             |
                                             v
                    app-cd-pipeline --> [Helm upgrade --> Namespace on Cluster]
                                             |
                                    compliance-gates (SAST, Image Scan, Approval)

Platform Engineer push --> iac-platform-deploy --> [Terraform plan --> apply]
                                                        |
                                               compliance-gates (Policy, Approval)
```

---
## Apps Subgroup — Business Unit Structure

> Applications are categorised by Business Unit (BU). Each BU is a subgroup.
> Each app within a BU has exactly two repos: a package repo (-app) and a deployment repo (-iac).

| Business Unit | Subgroup | Example Orgs |
|---------------|----------|--------------|
| Corporate Systems | apps/cs/ | IT, Corporate Apps |
| Financial Services | apps/fs/ | Finance, Treasury, Billing |
| Human Resources | apps/hr/ | HR Systems, Benefits, Payroll |
| Product Support | apps/ps/ | Support Tools, Field Services |

### App Repo Structure (per app)

```
apps/<bu>/<esatsidname>/
|
|-- esatsidname-app/               <- PACKAGE REPO (App Team owns)
|   |-- src/                       <- Application source code
|   |-- Dockerfile                 <- FROM platform base image (container/ ACR)
|   +-- .gitlab-ci.yml             <- CI: build image, push to app ACR
|
+-- esatsidname-iac/               <- CORE / IAC REPO (App Team owns)
    |-- helm/                      <- Helm chart for the application
    |   |-- Chart.yaml
    |   |-- values.yaml            <- Defaults
    |   |-- values-dev.yaml
    |   |-- values-nonprod.yaml
    |   +-- values-prod.yaml
    |-- terraform/                 <- App-scoped IaC (namespace, ACR, KV, RBAC)
    +-- .gitlab-ci.yml             <- CD: Helm deploy to org cluster namespace
```

| Repo | Naming Convention | Purpose |
|------|-------------------|---------|
| esatsidname-app | ESATS ID + short name + -app | Container image build (Dockerfile, source, CI pipeline to push to ACR) |
| esatsidname-iac | ESATS ID + short name + -iac | Helm chart + Terraform for app resources; CD pipeline deploys to cluster namespace |

---

## App Onboarding Workflow

```
+------------------+   +------------------+   +-----------------------+   +----------------------+
|  App Team        |   |  App Manager      |   |  Platform + FinOps    |   |  Outcome             |
+------------------+   +------------------+   +-----------------------+   +----------------------+
| Submit request:  |-->| Validate:        |-->| Provision:            |-->| App Group ready:     |
| - ESATS ID       |   | - ESATS check    |   | - App group under BU  |   | - esatsid-app repo   |
| - Charge line    |   | - Budget approval |   | - esatsid-app repo    |   | - esatsid-iac repo   |
| - Business Unit  |   | - Policy review   |   | - esatsid-iac repo    |   | - Namespace (tagged) |
| - App name       |   |                  |   | - Namespace created   |   | - ACR (ESATS-tagged) |
| - Team members   |   |                  |   | - ACR + KV + Log      |   | - Key Vault          |
|                  |   |                  |   | - RBAC + FinOps UUID  |   | - Log Workspace      |
+------------------+   +------------------+   +-----------------------+   +----------------------+
```

---

## Namespace and Resource Mapping

```
Shared AKS Cluster - Namespace per App:

|-- namespace: 123456appa              <- apps/cs/123456appa/123456appa-iac
|   |-- label: finops-uuid=LK09123
|   |-- label: esats-id=123456
|   |-- label: managed-org=cs
|   |-- ACR: acr-cs-appa-prod.azurecr.io
|   +-- Key Vault: kv-cs-appa-prod
|
|-- namespace: 2346666appb             <- apps/fs/2346666appb/2346666appb-iac
|   |-- label: finops-uuid=LK09456
|   |-- label: esats-id=2346666
|   |-- label: managed-org=fs
|   |-- ACR: acr-fs-appb-prod.azurecr.io
|   +-- Key Vault: kv-fs-appb-prod
|
+-- namespace: 5091752appr             <- apps/hr/5091752appr/5091752appr-iac
    |-- label: finops-uuid=LK09789
    |-- label: esats-id=5091752
    |-- label: managed-org=hr
    |-- ACR: acr-hr-appr-prod.azurecr.io
    +-- Key Vault: kv-hr-appr-prod
```

---

## Ownership Matrix

| Subgroup | Owner | What They Do | Change Process |
|----------|-------|-------------|----------------|
| governance/ | Platform Engineering - Governance | Define policies, RBAC, compliance | MR + review |
| apps/\<bu\>/ | App Teams per BU | Build containers, deploy via Helm | Self-service within guardrails |
| platform/platform-infra/ | Infrastructure Team | Provision AKS/EKS clusters (core + org) | Formal change process |
| platform/platform-common/ | Platform Operations Team | Deploy and maintain operational services on clusters | Independent pipeline per service |
| container/ | Platform Engineering | Publish base, runtime, sidecar, support images | Versioned releases |
| catalog/ | Platform Engineering | Author + publish reusable Terraform modules | Versioned via iac-module-pipeline |
| pipelines/ | Platform Engineering | Maintain CI/CD templates and compliance gates | Controlled via MR |
| guidance/ | Platform Engineering | Playbooks, ADRs, product docs | Living documentation |
| spike/ | Any team | Prototype and validate new ideas | Open, no formal process |
| support/ | Platform Engineering | Maintain runbooks, FAQs, troubleshooting, onboarding guides | Living documentation, accessible to all teams |
| trash/ | Platform Engineering | Soft-archive decommissioned groups | Approval required for deletion |

---