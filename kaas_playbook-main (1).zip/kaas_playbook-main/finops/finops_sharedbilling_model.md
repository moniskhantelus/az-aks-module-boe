# Strata — Shared Billing Model via FinOps UUID

## Shared Cluster, Individual Application Billing

---

## Overview

The FinOps UUID is a unique identifier assigned to each application/service for cost attribution in the shared billing model. It enables precise tracking of cloud resource consumption across namespaces, making it straightforward to allocate costs to the correct cost center, ESATS ID, and application charge line.



---

## Business Use Case

Organizations running shared infrastructure (e.g., AKS , EKS ) need a reliable way to attribute cloud costs back to individual application teams. Without a standardized identifier, billing becomes fragmented, disputed, and difficult to audit. The **FinOps UUID** solves this by creating a single, immutable tag that flows from onboarding through to the monthly invoice.

Multiple application teams share the same Kubernetes cluster (AKS, EKS) to benefit from economies of scale. However, each team needs to pay only for what they consume — not for what other teams use. Without per-namespace billing, costs are either split equally (unfair) or disputed endlessly (unproductive).

The **FinOps UUID** tags solves this by linking each application's namespace to a billing identity. Every resource consumed within that namespace of CPU, memory, storage, and external services — is tracked and invoiced to the correct team.

**Business value:**
- Accurate cost attribution per application/service
- Eliminates billing disputes between teams
- Enables showback/chargeback reporting
- Supports financial governance and forecasting
- Provides audit trail from request to resource to invoice

---

## How It Works: Namespace = Billing Boundary

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                SHARED CLUSTER                                          │
├────────────────────────────────────────────────────────────────────────────────────────┤
│                                                                                        │
│   ┌───────────────────────┐  ┌────────────────────────┐  ┌───────────────────────┐     │
│   │  Namespace: Alpha     │  │  Namespace: Beta       │  │  Namespace: Gamma     │     │
│   │  finops-UUID: LK09123 │  │  finops-UUID: LK09456  │  │  finops-UUID: LK09789 │     │
│   │                       │  │                        │  │                       │     │
│   │  App Team Alpha       │  │  App Team Beta         │  │  App Team Gamma       │     │
│   │                       │  │                        │  │                       │     │
│   │                       │  │                        │  │                       │     │
│   │  CPU: 4 cores         │  │  CPU: 8 cores          │  │  CPU: 2 cores         │     │
│   │  Mem: 8 GB            │  │  Mem: 16 GB            │  │  Mem: 4 GB            │     │
│   │  PV: 50 GB            │  │  PV: 200 GB            │  │  PV: 20 GB            │     │
│   └───────────────────────┘  └────────────────────────┘  └───────────────────────┘     │
│                                                                                        │
│   + Shared Overhead (kube-system, LBs, Defender, idle capacity)                        │
│     → Distributed proportionally based on namespace usage                              │
│                                                                                        │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

Each namespace has **one FinOps UUID** tag. That UUID ties the namespace to:
- An ESATS ID (application identity)
- A charge line (billing destination)
- An application manager (budget owner)

---


## Workflow

### Step 1: Application Team Raises Onboarding Request

The application team submits a request through the **Onboarding Intake Form**  (CDP Strata Intake Form) `<TBD>` to onboard their application and provision a namespace.

---

### Step 2: App Manager Approval

The application manager reviews and approves the onboarding request. This ensures:
- The ESATS ID and charge line are correct
- The resource request is legitimate and within policy

---

### Step 3: FinOps Team Creates the UUID

Upon approval, the FinOps team creates a **FinOps UUID** for the shared billing model. This UUID becomes the permanent cost attribution identifier for that application's resources.

| UUID Properties | Detail |
|----------------|--------|
| Format | Unique identifier (e.g., `LK09123...`) |
| Scope | One UUID per application per environment |
| Lifecycle | Created once, persists for the life of the application |
| Ownership | Managed by FinOps team |

---

### Step 4: UUID Mapped to Namespace & Resources

The FinOps UUID is tagged onto all provisioned resources and mapped to the application's namespace. Strata Automation utilizes the UUID during resource provisioning to ensure every resource is tagged correctly at creation time.

**Tagging applied to resources:**

```json
{
  "partial_tags": {
    "env-ServiceEnv": "...",
    "env-DeploymentTime": "2025-10-18",
    "env-Environment": "PROD",
    "env-DataCtr": "3053938",
    "env-ServiceMgmt": "ECS-CATALOG",
    "env-Template": "ECS-SERVICE",
    "finops-uuid": "LK09123..."
  }
}
```

**Where the UUID appears:**
- Namespace metadata
- All pod and resource annotations within the namespace
- External services tagged to the application (ACR, Key Vault, snapshots)
- GSEP configuration reports
- Cloud Health cost and usage reports

---

## Billing Calculation :- Per-Application Billing Breakdown

Each application's monthly bill is composed of three categories:

```
┌───────────────────────────────────────────────────────────────────────┐
│              YOUR APPLICATION'S MONTHLY BILL                          │
│              (identified by FinOps UUID per namespace)                │
└──────────────────────────────┬────────────────────────────────────────┘
                               │
        ┌──────────────────────┼──────────────────────┐
        │                      │                      │
        ▼                      ▼                      ▼
┌───────────────────┐  ┌───────────────────┐  ┌───────────────────────┐
│ DIRECT NAMESPACE  │  │ DEDICATED         │  │ SHARED PLATFORM       │
│ CONSUMPTION       │  │ EXTERNAL SERVICES │  │ OVERHEAD              │
│                   │  │                   │  │                       │
│ What your pods    │  │ Services tagged   │  │ Your proportional     │
│ actually used     │  │ to your app       │  │ share of cluster      │
│                   │  │                   │  │ infrastructure        │
├───────────────────┤  ├───────────────────┤  ├───────────────────────┤
│ • CPU consumed    │  │ • ACR (Container  │  │ • Idle node capacity  │
│ • Memory consumed │  │   Registry)       │  │ • kube-system pods    │
│ • Persistent      │  │ • Key Vault       │  │ • Load Balancers      │
│   Volumes (PV)    │  │ • Dedicated       │  │ • Defender            │
│                   │  │   Snapshots       │  │ • Monitoring agents   │
│                   │  │                   │  │ • Networking overhead │
└───────────────────┘  └───────────────────┘  └───────────────────────┘
        │                      │                      │
        ▼                      ▼                      ▼
  Metered per             Tagged to your        Calculated as your
  namespace usage         UUID directly         namespace's % of
                                                total cluster usage
```

### How Each Category Is Billed

| Category | What It Includes | How It Is Calculated | FinOps UUID Role |
|----------|-----------------|---------------------|-----------------|
| **Direct Namespace Consumption** | CPU, Memory, PV consumed by pods in your namespace | Metered based on actual resource usage within the namespace | UUID identifies the namespace owner — costs attributed directly |
| **Dedicated External Services** | ACR, Key Vault, dedicated snapshots tagged to the application | Billed based on service-level tags matching the UUID | UUID tag on external services links cost to the correct charge line |
| **Shared Platform Overhead** | Idle nodes, kube-system, load balancers, Defender, monitoring | Proportionally distributed based on your namespace's share of total allocated resources | UUID determines each application's proportion for fair distribution |



## Billing Reports

| Report | What It Shows | Frequency |
|--------|--------------|-----------|
| **Cloud Health** | Cost and usage filtered by FinOps UUID — breakdown by resource type | Monthly | <TBD>

---

## FinOps End-to-End  Work Flow Diagram

```
┌─────────────────────────────────────────────────────────────────────────────┐
│                    FinOps UUID — Shared Billing Workflow                    │
└─────────────────────────────────────────────────────────────────────────────┘

┌──────────────┐       ┌──────────────┐     ┌──────────────┐     ┌───────────────┐
│   STEP 1     │       │   STEP 2     │     │   STEP 3     │     │   STEP 4      │
│              │       │              │     │              │     │               │
│  End User    │───▶   │  App Manager │───▶ │  FinOps Team │───▶ │  UUID Tagged  │
│  Raises      │       │  Approves    │     │  Creates     │     │  on Resources │
│  Request     │       │  Request     │     │  UUID        │     │  & Namespace  │
│              │       │              │     │              │     │               │
│ • Intake     │       │ • Validates  │     │ • Generates  │     │               │
│   Form       │       │   ESTA ID    │     │   unique ID  │     │ • Namespace   │
│ • ESTA ID    │       │ • Confirms   │     │ • Links to   │     │   mapping     │
│ • Charge Line│       │   charge line│     │   ESTA/charge│     │ • GSEP report │
│              │       │              │     │   line       │     │ • Cloud       │ 
│              │       │              │     │              │     │   Health      │
└──────────────┘       └──────────────┘     └──────────────┘     └───────────────┘
                                                                       │
                                                                       ▼
                                                          ┌────────────────────────┐
                                                          │      BILLING           │
                                                          │                        │
                                                          │ • Cloud Health reports │
                                                          │   cost by UUID         │
                                                          │ • Strata invoice       │
                                                          │   per charge line      │
                                                          │ • Monthly attribution  │
                                                          │   to cost center       │
                                                          └────────────────────────┘
```

---

## Detailed Process Flow

```
┌─────────────┐        ┌─────────────┐        ┌─────────────┐
│  End User   │        │ App Manager │        │ FinOps Team │
└──────┬──────┘        └──────┬──────┘        └──────┬──────┘
       │                      │                      │
       │  Submit  Intake      │                      │
       │  Form with:          │                      │
       │  • ESATS ID          │                      │
       │  • Charge Line       │                      │
       │  • App Name          │                      │
       │                      │                      │
       │────────────────────▶ │                      │
       │                      │                      │
       │                      │  Review & Approve    │
       │                      │────────────────────▶ │
       │                      │                      │
       │                      │                      │  Create FinOps UUID
       │                      │                      │  Map to ESATS + Charge Line
       │                      │                      │──────────┐
       │                      │                      │          │
       │                      │                      │◀─────────┘
       │                      │                      │
       │                      │     UUID Issued      │
       │◀──────────────────── │◀──────────────────── │
       │                      │                      │
       ▼                      ▼                      ▼
┌──────────────────────────────────────────────────────────┐
│                   Strata                                 │
│                                                          │
│  • Provisions resources with UUID tag                    │
│  • Maps UUID to namespace                                │
│  • Tags: finops-uuid, env-esats, env-Template            │
└──────────────────────────────────────────────────────────┘
                            │
                            ▼
┌──────────────────────────────────────────────────────────┐
│              Billing & Reporting                         │
│                                                          │
│  • Cloud Health: Cost & Usage by UUID                    │
│  • GSEP: Server-to-UUID mapping                          │
│  • Strata: Monthly invoice per charge line               │
└──────────────────────────────────────────────────────────┘
```

---

## Summary

| Step | Actor | Action | Output |
|------|-------|--------|--------|
| 1 | App Team/Manager | Submits Onboarding Intake Form (ESATS ID, charge line, app details) | Onboarding request created |
| 2 | App Manager | Reviews and approves request | Approval granted |
| 3 | FinOps Team | Creates FinOps UUID linked to ESTA/charge line | UUID issued |
| 4 | Strata Automation | Tags UUID on all provisioned resources and namespace | Resources traceable |
| 5 | Billing | Cloud Health/Strata reports cost by UUID per month | Accurate invoicing |

---

## Key Benefits

| Benefit | Detail |
|---------|--------|
| **Per-application billing** | Each namespace is individually metered and invoiced via its UUID |
| **No billing disputes** | UUID provides clear ownership — traceable from request to invoice |
| **Fair overhead distribution** | Shared costs are split proportionally, not equally or arbitrarily |
| **Self-service cost visibility** | Teams can view their own spend at any time via Cloud Health <TBD> |
| **Namespace = billing boundary** | Simple model — one namespace, one UUID, one invoice line |
| **Scalable** | Works across any number of applications, teams, and clusters |

---


### Business Perspective

| Question | Answer |
|----------|--------|
| "What am I paying for?" | Your namespace usage (CPU + Memory + PV) + any dedicated services (ACR, KV) + a proportional share of platform overhead |
| "How is my share of overhead calculated?" | Based on your namespace's proportion of total allocated resources across the cluster |
| "Can I reduce my bill?" | Yes — optimize pod resource requests, right-size PVs, and consolidate underused services |
| "How do I see my costs?" | Cloud Health report filtered by your FinOps UUID shows by categories <TBD>|
| "Who manages the overhead?" | Platform team manages shared infrastructure; costs are distributed fairly, not arbitrarily <TBD> |

---