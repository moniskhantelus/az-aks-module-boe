# KaaS Platform — Team Collaboration & Knowledge Sharing Standards

> Standards for daily interactions, knowledge sharing, peer programming, and continuous demo practices.
> These practices ensure the team stays aligned, learns together, and delivers visible progress daily.

---

## Table of Contents

1. [Daily Rhythm](#daily-rhythm)
2. [Knowledge Sharing](#knowledge-sharing)
3. [Peer Programming](#peer-programming)
4. [Daily Demo (Show & Tell)](#daily-demo)
5. [Communication Standards](#communication-standards)

---
## Support Links 

1. [JIRA](https://jira-ent.web.boeing.com/)
2. [Gitlab](https://git.web.boeing.com/kaas)
3. [KaaS MS Team](https://gov.teams.microsoft.us/l/team/19%3Agcch%3AogS9L2uDQuvpkIR2-ierRrsgeueUFiF7wzPVFF-1JXY1%40thread.tacv2/conversations?groupId=fcf26fae-a645-429f-93d1-0cb3aa9f5859&tenantId=bcf48bba-4d6f-4dee-a0d2-7df59cc36629)


## Daily Rhythm

Every working day follows this structure:

| Time | Activity | Duration | Who |
|------|----------|----------|-----|
| Start of day | **Daily Standup** | 15 min | Entire team |
| After standup | **Daily Demo / Show & Tell** | 10–15 min | Whoever has something to show |
| During day | **Peer Programming** (scheduled or ad-hoc) | 1–2 hours | Pairs or small groups |
| End of day | **Status update** in team channel | 2 min (async) | Everyone |

---

## Knowledge Sharing

### Principles

- **Share early, share often** — don't wait until something is "finished" to show it
- **Default to open** — all work happens in shared repos, shared channels, shared docs
- **Teach by doing** — peer programming is the primary knowledge transfer method
- **Document decisions** — if you discussed it and decided something, write it down (ADR, channel post, or MR comment)

### Daily Knowledge Sharing Practices

| Practice | How | When |
|----------|-----|------|
| **Standup learnings** | Share one thing you learned yesterday in standup | Daily standup |
| **Post-standup demo** | Show what you built/fixed/discovered — no slides, just screen share | Immediately after standup |
| **Channel drops** | Post useful links, commands, patterns, or "TIL" (Today I Learned) in the team channel | Anytime during the day |
| **MR walkthroughs** | When submitting an MR, post a 2-minute Loom/screen recording explaining the change | With every significant MR |
| **Pair rotation** | Rotate pairing partners weekly so knowledge spreads across the team | Weekly |

### What to Share

| Category | Examples |
|----------|---------|
| **Terraform patterns** | New module usage, state management tricks, provider quirks |
| **Kubernetes findings** | Debugging techniques, kubectl shortcuts, Helm chart patterns |
| **Pipeline improvements** | Faster builds, better gate checks, new templates |
| **Architecture decisions** | Why we chose X over Y — even informal decisions |
| **Troubleshooting** | How you resolved an issue — write it up for next person |
| **Tool tips** | VS Code extensions, CLI aliases, Git workflows |

---

## Peer Programming

### When to Pair

| Situation | Pair? | Why |
|-----------|-------|-----|
| New team member onboarding | **Always** | Fastest way to learn codebase and patterns |
| Complex Terraform module | **Yes** | Two sets of eyes catch state management issues |
| Debugging a tricky issue | **Yes** | Fresh perspective breaks tunnel vision |
| Routine task you've done 10x | **No** | Solo is fine — document it instead |
| Security-sensitive change | **Yes** | Four eyes principle for infra changes |
| Cross-team dependency | **Yes** | Align understanding in real-time |

### How to Pair

| Step | Action |
|------|--------|
| 1 | Agree on scope — what are we solving in this session? |
| 2 | One person drives (types), one navigates (reviews/guides) |
| 3 | Switch roles every 25–30 minutes |
| 4 | Talk through decisions out loud — no silent coding |
| 5 | At the end, commit together (co-authored commit) |
| 6 | Share a 1-sentence summary in the team channel |

### Co-Authored Commits

```
git commit -m "[STR-X]: feat(aks): add private endpoint for ACR

Co-authored-by: John Doe <john.doe@boeing.com>
Co-authored-by: Jane Smith <jane.smith@boeing.com>"
```

### Scheduling

- **Minimum:** 2 pairing sessions per week per person
- **Preferred:** Daily 1-hour slot blocked on calendar (optional attendance)
- **Ad-hoc:** Anyone can request a pair session in the team channel anytime

---

## Daily Demo

### Why Demo Daily Instead of Waiting for Sprint Demo

| Waiting for Sprint Demo | Daily Demo |
|------------------------|------------|
| ❌ Feedback comes 2 weeks late | ✅ Feedback within hours |
| ❌ Work drifts from expectations silently | ✅ Course-correct immediately |
| ❌ Big reveal risks big surprises | ✅ Small increments, no surprises |
| ❌ Only presenter learns to present | ✅ Everyone practices showing work |
| ❌ Stakeholders see polished "done" only | ✅ Team sees real progress daily |

### Format

| Aspect | Standard |
|--------|----------|
| **When** | Immediately after daily standup (or last 10 min of standup) |
| **Duration** | 10–15 minutes max |
| **Who presents** | Whoever has something to show — rotate naturally |
| **What to show** | Working software, terminal output, passing tests, merged MR, diagram, pipeline run |
| **What NOT to show** | Slides, plans without execution, "I'm going to do X" |
| **Audience** | Entire team (optional for stakeholders — invite when relevant) |
| **Recording** | Record if possible — post in team channel for anyone who missed it |

### What Counts as a Demo

| ✅ Good Demo | ❌ Not a Demo |
|-------------|--------------|
| "I deployed the ACR module — here's it running" | "I plan to work on ACR next" |
| "This pipeline now passes in 3 minutes instead of 8" | "I'm looking into pipeline speed" |
| "Here's the namespace created with labels" | "I read the docs about namespaces" |
| "This Mermaid diagram shows our new workflow" | "I'll create a diagram soon" |
| "Found a bug in subnet routing — here's the fix and PR" | "There might be a networking issue" |

### No-Demo Days

If nobody has anything to demo, that's fine — skip it. But if the team goes 3+ days without a demo, that's a signal something is blocked or work isn't being broken into small enough pieces.

---

## Communication Standards

### Team Channel

> **Primary channel:** [KaaS MS Teams Channel](https://gov.teams.microsoft.us/l/team/19%3Agcch%3AogS9L2uDQuvpkIR2-ierRrsgeueUFiF7wzPVFF-1JXY1%40thread.tacv2/conversations?groupId=fcf26fae-a645-429f-93d1-0cb3aa9f5859&tenantId=bcf48bba-4d6f-4dee-a0d2-7df59cc36629). All knowledge sharing, status updates,
> findings, and demos happen here. Use this as the single source of team communication.

| Standard | Detail |
|----------|--------|
| Use the [KaaS MS Teams channel](https://gov.teams.microsoft.us/l/team/19%3Agcch%3AogS9L2uDQuvpkIR2-ierRrsgeueUFiF7wzPVFF-1JXY1%40thread.tacv2/conversations?groupId=fcf26fae-a645-429f-93d1-0cb3aa9f5859&tenantId=bcf48bba-4d6f-4dee-a0d2-7df59cc36629) for all team communication | Don't fragment across email, DMs, or other channels |
| Post issues and findings in the [Issues Channel](https://gov.teams.microsoft.us/l/channel/19%3Agcch%3Acd4b4d7ff15b4c5ca0db16cd0edaa35b%40thread.tacv2/Issues?groupId=fcf26fae-a645-429f-93d1-0cb3aa9f5859&tenantId=bcf48bba-4d6f-4dee-a0d2-7df59cc36629) | Dedicated channel for issue discussion and troubleshooting |
| Post daily status at end of day | What you did, what's next, any blockers |
| Share knowledge drops in the channel | TIL, useful links, commands, patterns — post it for everyone |
| Use threads for discussions | Keep main channel scannable |
| Tag people when you need them | Don't hope they'll see it |
| Share links to MRs when ready for review | Don't wait for someone to find it |
| Record screen shares and post recordings | For demos, walkthroughs, or pairing highlights |
| Celebrate wins | Merged a big MR? Pipeline green? Share it. |

### MS Teams Best Practices

| Practice | How |
|----------|-----|
| **Daily demo recordings** | Record your post-standup demo via Teams and post in the channel |
| **Knowledge drops** | Post a short message with code snippets, screenshots, or links when you learn something |
| **Threaded discussions** | Reply in threads — don't flood the main feed with back-and-forth |
| **Pin important messages** | Pin runbook links, onboarding guides, and architecture diagrams |
| **Use tabs** | Add wiki, planner, or OneNote tabs for persistent reference material |
| **Screen share in calls** | For pairing sessions, use Teams call + screen share — record if useful for others |

### Record Findings & Issues

> Every finding, issue, workaround, or decision should be recorded for future reference.
> "If it's not written down, it didn't happen."

**Track issues in both Jira and GitLab Issues:**

| Tool | Use For | When |
|------|---------|------|
| **Jira** | Feature requests, epics, sprint work items, cross-team dependencies | Planning and tracking delivery against sprints |
| **GitLab Issues** | Technical findings, bugs, code-level tasks, MR-linked work | Day-to-day engineering work tied to repos |

> **Rule:** Every Jira ticket that involves code should have a corresponding GitLab Issue (or MR) linked to it.
> Reference format: `KAAS-123` (Jira) ↔ `#42` (GitLab Issue)

| What to Record | Where | Template |
|----------------|-------|----------|
| Bug or issue encountered | **GitLab Issue** (label: `finding`) + link to Jira if sprint-tracked | See [Issue Template](#issue-template) below |
| Feature / user story | **Jira** (epic/story) | Standard Jira story template |
| Workaround discovered | **GitLab Issue** + post summary in MS Teams channel | Short description + steps + link |
| Decision made in a call | ADR (`guidance/adr/`) or MR comment | Context → Decision → Consequences |
| Troubleshooting steps | `support/troubleshooting/` repo + **GitLab Issue** | Problem → Root Cause → Fix |
| Environment-specific quirks | `support/faqs/` repo | Question → Answer → Links |
| Findings from a spike | `spike/` repo + **Jira** spike ticket | What we tried → What worked → What didn't |
| Cross-team blocker | **Jira** (blocker type) + tag in MS Teams | Dependency, owner, expected resolution |

### Issue Template (For Recording Findings)

Use this when creating a **GitLab Issue** to record a finding:

```markdown
## Summary
One-line description of what was found.

## Jira Reference
STR-X:-XXX (link to related Jira ticket, if applicable)

## Context
- What were you working on?
- What environment? (dev/stage/prod)
- What resource or component?

## Finding / Issue
Describe the problem, unexpected behaviour, or discovery.

## Root Cause (if known)
What caused it? Why did it happen?

## Resolution / Workaround
How was it resolved? What workaround was applied?
Include exact commands, config changes, or links.

## Impact
- Who else might hit this?
- Does it affect other environments?
- Is it a one-time fix or recurring?

## Action Items
- [ ] Permanent fix needed? (link to follow-up MR)
- [ ] Document in runbook? (link to support/troubleshooting)
- [ ] Share with team in MS Teams? (posted: yes/no)
- [ ] Update Jira ticket status?

## Labels
`finding`, `<component>`, `<environment>`
```

### Jira ↔ GitLab Linking

| Jira Field | GitLab Reference |
|-----------|-----------------|
| Jira ticket description | Include GitLab Issue link: `https://git.web.boeing.com/.../issues/42` |
| GitLab Issue description | Include Jira reference: `KAAS-123` |
| GitLab MR title | Include Jira key: `[STR-X]: feat(aks): add node pool autoscaling [KAAS-123]` |
| Commit message | Reference both: `[STR-X]: fix(dns): resolve timeout #42 [KAAS-456]` |

### When to Record

| Trigger | Action |
|---------|--------|
| Spent > 30 minutes debugging something | Create a GitLab issue with the finding |
| Found a workaround for a platform limitation | Record in issue + add to `support/troubleshooting/` |
| Made a decision during a call or pairing session | Write an ADR or comment on the relevant MR |
| Discovered something that "just works differently here" | Add to `support/faqs/` |
| Pipeline failed in an unexpected way | Record in issue + fix + add to runbook if recurring |
| Azure behaviour differs from documentation | Record in issue with label `azure-quirk` |

### Linking Findings to Work

- Always reference the GitLab issue number in your commit message: `fix(aks): resolve DNS timeout #42`
- Link related findings to MRs so reviewers have context
- When closing an issue, add a summary comment with the final resolution

### Daily Status Template (End of Day)

```
✅ Done today:
- Completed ACR private endpoint wiring (MR !234)
- Paired with @naveen on Key Vault CSI integration

🔜 Tomorrow:
- Start node pool auto-scaling config
- Review @naveen's  RBAC MR

🚧 Blockers:
- Waiting on Network Team for DNS zone link (ticket STR-456)
```

### Async vs Sync

| Use Async (Channel/MR) | Use Sync (Call/Pair) |
|------------------------|---------------------|
| Status updates | Complex debugging |
| Code review comments | Architecture decisions with trade-offs |
| Link sharing, TIL | Onboarding new team members |
| Simple questions with clear answers | Disagreements that need resolution |

---

## Summary

| Principle | Practice |
|-----------|----------|
| Share knowledge daily | Post-standup demo, channel drops, MR walkthroughs |
| Learn by doing together | Peer programming 2+ times per week |
| Show progress, not plans | Daily demo of working software |
| Don't wait for sprint demo | Small demos daily > big reveal bi-weekly |
| Write it down | Decisions in ADRs, patterns in docs, fixes in runbooks |
| Rotate to spread knowledge | Pair with different people each week |