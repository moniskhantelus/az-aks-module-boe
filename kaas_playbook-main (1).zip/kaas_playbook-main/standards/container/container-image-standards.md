# KaaS Platform — Container Image Standards

## Description

This document establishes the standards for building, naming, versioning, storing, scanning, and signing all container images within the KaaS (Kubernetes as a Service) platform. It covers platform-managed images (base, runtime, sidecar, support) and application images built by app teams. The standards ensure consistency, security, traceability, and compliance across all environments.

## Objective

- Provide a single, authoritative reference for container image practices across all KaaS teams.
- Ensure every image in production is scannable, traceable, signed, and reproducible.
- Enforce a secure image supply chain — from approved base sources through to signed production artefacts.
- Standardise versioning using CalVer (`YY.MM`) for predictable release cadence and age-based policies.
- Enable multi-registry support (ACR, GitLab Registry, JFrog) with clear guidance on when to use each.


---

## Important: Container Source Policy

> **Before building a custom image**, check if a pre-approved container already exists.

| Step | Action | Source |
|------|--------|--------|
| 1 | Check Boeing pre-defined containers first | [https://git.web.boeing.com/container](https://git.web.boeing.com/container) |
| 2 | If not available, pull base images from SRES JFrog | [https://sres.web.boeing.com/](https://sres.web.boeing.com/) |
| 3 | Pull additional software/tools from SRES OSSTools | [https://sres.web.boeing.com/ui/native/osstools](https://sres.web.boeing.com/ui/native/osstools) |
| 4 | If required tools/software are not in SRES, request a waiver | Get waiver approved before use |

**Rules:**
- Always prefer Boeing-published containers from `git.web.boeing.com/container` — these are pre-approved and maintained.
- Base images (UBI, Ubuntu) must be fetched from **SRES JFrog** (`sres.web.boeing.com`), not from Docker Hub or public registries.
- Any software or tool dependency must come from **SRES OSSTools** (`sres.web.boeing.com/ui/native/osstools`).
- If a required package is not available in SRES, submit a **waiver request** and get approval before including it in any image.
- **Never pull directly from public registries** (Docker Hub, ghcr.io, quay.io) in pipelines or Dockerfiles.

---

## Table of Contents

1. [Registry Options](#registry-options)
2. [Image Naming Convention](#image-naming-convention)
3. [Versioning Standard (CalVer)](#versioning-standard)
4. [Image Categories](#image-categories)
5. [Dockerfile Standards](#dockerfile-standards)
6. [Tagging Rules](#tagging-rules)
7. [Security & Compliance](#security--compliance)
   - [Age Policy Enforcement](#age-policy-enforcement)
   - [SBOM (Software Bill of Materials)](#sbom-software-bill-of-materials)
   - [Cosign (Image Signing & Verification)](#cosign-image-signing--verification)
8. [Examples](#examples)
9. [Quick Reference](#quick-reference)

---

## Registry Options

Images can be stored in any of the following registries depending on context:

| Registry | Use Case | Access |
|----------|----------|--------|
| **Azure Container Registry (ACR)** | Production deployments, platform images pulled by AKS | AKS kubelet MI: AcrPull, Pipeline SP: AcrPush |
| **GitLab Container Registry** | CI/CD intermediate builds, dev/test images, MR-scoped images | GitLab project-level tokens |
| **JFrog Artifactory** | Enterprise artifact management, cross-team shared images, promoted releases | Service account or API key |

### Registry Selection

| Scenario | Use |
|----------|-----|
| Image deployed to AKS cluster | **ACR** (private endpoint, AKS-native pull) |
| Image built during MR pipeline (not yet promoted) | **GitLab Registry** (ephemeral, per-MR) |
| Image shared across multiple platforms / teams outside KaaS | **JFrog** (enterprise standard) |
| Platform base/runtime/sidecar images | **ACR** (primary) + **JFrog** (mirror for enterprise consumption) |

---

## Image Naming Convention

### Platform Images (owned by Platform Engineering)

```
<registry>/<platform>/<category>/<image-name>:<version>
```

| Segment | Description | Examples |
|---------|-------------|---------|
| `<registry>` | Registry host | `kaascdp00001prodvaacr.azurecr.us`, `registry.gitlab.com/kaas`, `artifactory.boeing.com/kaas` |
| `<platform>` | Platform prefix | `kaas` |
| `<category>` | Image category | `base`, `runtime`, `sidecar`, `support` |
| `<image-name>` | Descriptive image name | `ubi8-minimal`, `node20`, `python311`, `envoy`, `fluent-bit` |
| `<version>` | CalVer tag | `25.08`, `25.08.1` |

**Examples:**
```
kaascdp00001prodvaacr.azurecr.us/kaas/base/ubi8-minimal:25.08
kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08
kaascdp00001prodvaacr.azurecr.us/kaas/runtime/python311:25.08
kaascdp00001prodvaacr.azurecr.us/kaas/sidecar/envoy:25.08
kaascdp00001prodvaacr.azurecr.us/kaas/sidecar/fluent-bit:25.08
kaascdp00001prodvaacr.azurecr.us/kaas/support/kubectl:25.08
```

### Application Images (owned by App Teams)

```
<registry>/kaas/<esatsid>/<app>/<component>:<version>
```

**Examples:**
```
kaascdp00001prodvaacr.azurecr.us/kaas/12345/appa/api:25.08
kaascdp00001prodvaacr.azurecr.us/kaas/12345/appa/web:25.08.1
kaascdp00001prodvaacr.azurecr.us/kaas/67890/appb/worker:25.06
```

---

## Versioning Standard

### CalVer Format: `YY.MM` (Ubuntu-style)

All images use **Calendar Versioning** based on the release year and month:

```
<YY>.<MM>            — Major release (monthly cadence)
<YY>.<MM>.<patch>    — Patch/hotfix within that release month
```

| Version | Meaning | When |
|---------|---------|------|
| `25.08` | August 2025 release | Scheduled monthly release |
| `25.08.1` | First patch to August 2025 release | Hotfix or security patch |
| `25.08.2` | Second patch to August 2025 release | Additional fix |
| `25.09` | September 2025 release | Next monthly release |

### Why CalVer (Not SemVer)

| CalVer (`YY.MM`) | SemVer (`1.2.3`) |
|------------------|------------------|
| ✅ Immediately tells you how old an image is | ❌ Version number is meaningless without changelog |
| ✅ Simple — everyone understands "25.08 = August 2025" | ❌ Debatable what's major vs minor vs patch |
| ✅ Matches OS release cadence (Ubuntu, RHEL) | ❌ Doesn't convey time |
| ✅ Easy to enforce "no images older than 6 months" policy | ❌ Hard to enforce age-based policies |

### Version Lifecycle

```
25.06 ──→ 25.07 ──→ 25.08 ──→ 25.09 ──→ ...
  │                    │
  25.06.1              25.08.1  (hotfix)
  25.06.2              25.08.2  (security patch)
```

---

## Image Categories

| Category | Folder | Purpose | Examples | Update Cadence |
|----------|--------|---------|----------|----------------|
| **Base** | `container/base-images/` | Hardened minimal OS images | `ubi8-minimal`, `debian-slim`, `alpine` | Monthly |
| **Runtime** | `container/runtime-images/` | Language runtime on top of base | `node20`, `node22`, `python311`, `python312`, `java21`, `dotnet8` | Monthly |
| **Sidecar** | `container/sidecar-images/` | Platform sidecars injected into pods | `envoy`, `fluent-bit`, `otel-collector`, `cert-renewer` | Monthly |
| **Support** | `container/support-images/` | Utility/tooling for init containers and jobs | `kubectl`, `terraform`, `helm`, `migration-runner` | As needed |
| **App** | `apps/<bu>/<esatsid>-app/` | Application images built by app teams | `api`, `web`, `worker`, `processor` | Per commit/release |

---

## Dockerfile Standards

### Required Practices

| # | Rule | Why |
|---|------|-----|
| 1 | **Always use platform base image** — `FROM kaascdp00001prodvaacr.azurecr.us/kaas/base/ubi8-minimal:25.08` | Ensures hardened, patched, approved base |
| 2 | **Pin the base image version** — never use `:latest` | Reproducible builds |
| 3 | **Multi-stage builds** — separate build stage from runtime stage | Smaller images, no build tools in prod |
| 4 | **Run as non-root** — `USER 1001` | Security baseline |
| 5 | **No secrets in image** — use build args or runtime mount | Secrets come from Key Vault via CSI |
| 6 | **Add LABEL metadata** — see below | Traceability and scanning |
| 7 | **Minimal packages** — only install what's needed at runtime | Reduce attack surface |
| 8 | **Use .dockerignore** — exclude `.git`, `node_modules`, test files | Faster builds, smaller context |

### Required LABELs

```dockerfile
LABEL maintainer="strata-platform@boeing.com"
LABEL org.opencontainers.image.source="https://git.web.boeing.com/kaas/container/runtime-images/node20"
LABEL org.opencontainers.image.version="25.08"
LABEL org.opencontainers.image.created="2025-08-01T00:00:00Z"
LABEL org.opencontainers.image.description="Node.js 20 runtime on UBI8 minimal"
LABEL kaas.category="runtime"
LABEL kaas.base-image="kaas/base/ubi8-minimal:25.08"
```

### Example Dockerfile (Runtime Image)

```dockerfile
# Build stage
FROM kaascdp00001prodvaacr.azurecr.us/kaas/base/ubi8-minimal:25.08 AS base

# Install Node.js 20
RUN dnf module enable nodejs:20 -y && \
    dnf install -y nodejs npm && \
    dnf clean all && \
    rm -rf /var/cache/dnf

# Runtime stage
FROM base AS runtime

LABEL maintainer="strata-platform@boeing.com"
LABEL org.opencontainers.image.version="25.08"
LABEL kaas.category="runtime"
LABEL kaas.base-image="kaas/base/ubi8-minimal:25.08"

USER 1001
WORKDIR /app

ENTRYPOINT ["node"]
```

### Example Dockerfile (Application)

```dockerfile
# Build
FROM kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08 AS build

WORKDIR /app
COPY package*.json ./
RUN npm ci --production=false
COPY . .
RUN npm run build

# Runtime
FROM kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08

LABEL org.opencontainers.image.version="25.08"
LABEL kaas.esats-id="12345"
LABEL kaas.app="appa"
LABEL kaas.component="api"

USER 1001
WORKDIR /app

COPY --from=build /app/dist ./dist
COPY --from=build /app/node_modules ./node_modules

EXPOSE 8080
ENTRYPOINT ["node", "dist/main.js"]
```

---

## Tagging Rules

### What Tags to Apply

| Tag | Format | Purpose | Example |
|-----|--------|---------|---------|
| **Release** | `YY.MM` | Production release (monthly CalVer) | `25.08` |
| **Patch** | `YY.MM.patch` | Hotfix to a release | `25.08.1` |
| **Commit SHA** | `<short-sha>` | CI build artifact (7 chars) | `a1b2c3d` |
| **Branch** | `dev`, `stage` | Non-prod environment tags (overwritten each push) | `dev` |

### What Tags NOT to Use

| ❌ Don't | Why |
|----------|-----|
| `:latest` | Non-deterministic — breaks reproducibility, causes silent upgrades |
| `:stable` | Ambiguous — what does "stable" mean? Use CalVer instead |
| `:v1`, `:v2` | Doesn't convey time — impossible to enforce age policies |
| Mutable tags in prod | Production must use immutable tags (`25.08`, `25.08.1`, or SHA) |

### Tag Promotion Flow

```
Developer push → CI builds → tags with commit SHA
                                    ↓
                    Merge to dev → tags with `dev` (mutable, overwritten)
                                    ↓
                    Merge to stage → tags with `stage` (mutable, overwritten)
                                    ↓
                    Release approved → tags with `YY.MM` (immutable, never overwritten)
                                    ↓
                    Hotfix → tags with `YY.MM.patch` (immutable)
```

---

## Security & Compliance

| Requirement | Standard |
|-------------|----------|
| **Image scanning** | Every image scanned on push to ACR (Defender + Trivy) |
| **No critical CVEs** | Images with critical CVEs are blocked from deployment via admission webhook |
| **Base image age policy** | No image older than 6 months in production (enforced by CalVer) |
| **Signed images** | Platform images are signed using Notary/Cosign (trust chain) |
| **No secrets baked in** | Scanning for secrets in layers (GitLeaks, Trivy secret scan) |
| **Minimal attack surface** | No shell in production images where possible (distroless for sidecars) |
| **SBOM** | Software Bill of Materials generated for every release image |

### Age Policy Enforcement

```
Current month: 25.08

Allowed in prod:  25.08, 25.07, 25.06, 25.05, 25.04, 25.03  (last 6 months)
Blocked in prod:  25.02 and older → must upgrade
```

---

### SBOM (Software Bill of Materials)

> Every release image must have an SBOM generated and attached. This provides a complete
> inventory of all packages, libraries, and dependencies inside the image for audit and vulnerability tracking.

| Aspect | Standard |
|--------|----------|
| **Format** | SPDX or CycloneDX (JSON) |
| **Generated by** | `syft` (Anchore) in the CI pipeline |
| **Attached to** | Image manifest in the registry (OCI artifact) |
| **When** | Every image tagged with `YY.MM` or `YY.MM.patch` (release tags only) |
| **Storage** | Stored alongside the image in ACR/JFrog as an OCI referrer artifact |
| **Queryable** | `cosign verify-attestation` or `oras discover` to retrieve SBOM |

**Pipeline step:**
```yaml
generate-sbom:
  stage: post-build
  script:
    - syft ${IMAGE}:${VERSION} -o spdx-json > sbom.spdx.json
    - cosign attest --predicate sbom.spdx.json --type spdxjson ${IMAGE}:${VERSION}
  only:
    - tags
```

**Verify SBOM exists:**
```bash
cosign verify-attestation \
  --type spdxjson \
  kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08
```

---

### Cosign (Image Signing & Verification)

> All release images are signed using [Cosign](https://github.com/sigstore/cosign) to establish
> a trust chain. AKS admission policies reject unsigned images in production.

| Aspect | Standard |
|--------|----------|
| **Tool** | Cosign (Sigstore project) |
| **Key management** | Signing key stored in Azure Key Vault (Infra KV) |
| **What gets signed** | Every image tagged with `YY.MM` or `YY.MM.patch` |
| **When** | After image push + SBOM generation in CI pipeline |
| **Verification** | Admission webhook (Kyverno/OPA) verifies signature before pod admission |
| **Keyless option** | Cosign keyless with OIDC (GitLab CI identity) for pipeline-signed images |

**Pipeline step (sign after build):**
```yaml
sign-image:
  stage: post-build
  script:
    # Sign with key from Azure Key Vault
    - cosign sign --key azurekms://kaas-iao-prod-core-va-kv/cosign-signing-key ${IMAGE}:${VERSION}
  only:
    - tags
```

**Pipeline step (keyless with GitLab OIDC):**
```yaml
sign-image-keyless:
  stage: post-build
  id_tokens:
    SIGSTORE_ID_TOKEN:
      aud: sigstore
  script:
    - cosign sign --identity-token=$SIGSTORE_ID_TOKEN ${IMAGE}:${VERSION}
  only:
    - tags
```

**Verify signature:**
```bash
# Key-based verification
cosign verify --key azurekms://kaas-iao-prod-core-va-kv/cosign-signing-key \
  kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08

# Keyless verification (check issuer + subject)
cosign verify --certificate-identity=https://git.web.boeing.com/kaas/container/runtime-images \
  --certificate-oidc-issuer=https://git.web.boeing.com \
  kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08
```

**Kyverno policy (enforce signed images in prod):**
```yaml
apiVersion: kyverno.io/v1
kind: ClusterPolicy
metadata:
  name: verify-image-signature
spec:
  validationFailureAction: Enforce
  rules:
    - name: check-cosign-signature
      match:
        any:
          - resources:
              kinds:
                - Pod
      verifyImages:
        - imageReferences:
            - "kaascdp00001prodvaacr.azurecr.us/kaas/*"
          attestors:
            - entries:
                - keys:
                    kms: azurekms://kaas-iao-prod-core-va-kv/cosign-signing-key
```

---

### SBOM + Cosign — Complete Flow

```
Build Image → Push to ACR → Generate SBOM (syft) → Attach SBOM (cosign attest)
                                                          ↓
                                                   Sign Image (cosign sign)
                                                          ↓
                                                   Deploy to Cluster
                                                          ↓
                                            Kyverno verifies signature → Allow/Deny
                                                          ↓
                                              SBOM queryable for audit
```

---

## Examples

### Full Image Reference by Registry

| Registry | Platform Image Example | App Image Example |
|----------|----------------------|-------------------|
| **ACR** | `kaascdp00001prodvaacr.azurecr.us/kaas/runtime/node20:25.08` | `kaascdp00001prodvaacr.azurecr.us/kaas/12345/appa/api:25.08` |
| **GitLab** | `registry.gitlab.com/kaas/container/runtime-images/node20:a1b2c3d` | `registry.gitlab.com/kaas/apps/cs/12345appa/app:dev` |
| **JFrog** | `artifactory.boeing.com/kaas-docker/kaas/runtime/node20:25.08` | `artifactory.boeing.com/kaas-docker/kaas/12345/appa/api:25.08` |

### Image Version Timeline

```
Platform base image:    kaas/base/ubi8-minimal
────────────────────────────────────────────────────────
  25.06 → 25.07 → 25.08 → 25.08.1 (CVE fix) → 25.09

App image:              kaas/12345/appa/api
────────────────────────────────────────────────────────
  25.06 → 25.06.1 → 25.07 → 25.08 → 25.08.1 (hotfix)
```

---

## Quick Reference

| Item | Standard |
|------|----------|
| Version format | `YY.MM` (CalVer, Ubuntu-style) |
| Patch format | `YY.MM.patch` (e.g., `25.08.1`) |
| Never use | `:latest`, `:stable`, `:v1` |
| Base image | Always FROM platform base (`kaas/base/*`) |
| Run as | Non-root (`USER 1001`) |
| Build pattern | Multi-stage (build + runtime) |
| Labels | OCI standard + `kaas.*` custom labels |
| Scanning | On every push, block critical CVEs |
| Max age in prod | 6 months (enforced by CalVer) |
| Registries | ACR (prod), GitLab (CI/dev), JFrog (enterprise share) |
