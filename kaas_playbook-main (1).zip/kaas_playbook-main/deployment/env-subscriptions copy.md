

# 🚀 Environment & Subscription Matrix

## Overview

All KaaS platform resources are deployed across four environments mapped to three subscriptions.
- **Sandbox** subscription for platform experimentation
- **NonProd** subscription hosting both Dev and Stage clusters
- **Prod** subscription for live workloads
- **DR** (Disaster Recovery) for business continuity in a secondary region

This separation ensures blast-radius containment, independent access controls, and compliance boundary enforcement.

---

## Environment Summary

| Environment | Subscription | Purpose | Branch | Deployment |
|-------------|--------------|---------|--------|------------|
| **Sandbox** | Sandbox | Platform experimentation and prototyping | `sandbox` | Automatic on merge |
| **Dev** | NonProd | Development and integration testing | `dev` | Automatic on merge |
| **Stage** | NonProd | Pre-production validation, performance testing, stakeholder review | `stage` | Manual approval required |
| **Prod** | Prod | Live workloads serving end users | `main` | Manual approval required |
| **DR** | DR / Prod-Secondary | Disaster recovery replica of Prod | `main` | Automatic sync from Prod |

---

## Environment Purpose & Persona Mapping

| Environment | Subscription | Primary Users | Use Case |
|-------------|--------------|---------------|----------|
| **Sandbox** | Sandbox | Platform / K8s Admins | Cluster experimentation, module development, infrastructure prototyping |
| **Dev** | NonProd | App Teams (Developers) & K8s Admins | Application development, integration testing, feature validation |
| **Stage** | NonProd | App Teams (QA) & K8s Admins (Prod replication) | Performance testing, UAT, stakeholder review, prod-replication validation |
| **Prod** | Prod | End Users (via apps) | Production workloads serving mission-critical applications |
| **DR** | DR / Prod-Secondary | Platform / K8s Admins (failover) | Business continuity, regional failover, disaster recovery |

---

## Environment Definitions

### Sandbox

> **Audience:** Platform Engineer (K8s Admins) only

The Sandbox subscription is an **experimentation environment** exclusively for K8s platform administrators. Application teams do **not** have access to this environment.

**Purpose:**
- Test new Terraform modules and cluster configurations
- Experiment with AKS features, upgrades, and add-ons
- Prototype infrastructure patterns before promoting to NonProd
- Break things safely without impacting application teams

**Branch:** `sandbox`

---

### Dev (NonProd Subscription — Dev Cluster)

> **Audience:** Application Teams + Platform Engineer (K8s Admins)

The Dev cluster runs within the NonProd subscription and is dedicated to active development work.

**Purpose:**
- Deploy and test application workloads during development
- Integration testing against platform services
- Feature branch validation
- Early feedback loops for developers

**Branch:** `dev`

---

### Stage (NonProd Subscription — Stage Cluster)

> **Audience:** Application Teams (QA) + Platform Engineer (K8s Admins)

The Stage cluster also runs within the NonProd subscription but is a separate cluster dedicated to pre-production validation.

**Purpose:**
- Performance and load testing
- Stakeholder review and UAT
- Validate production-bound infrastructure changes
- Replicate prod configuration for troubleshooting
- Test upgrade procedures before applying to Prod
- Verify security policies and network rules match Prod

**Branch:** `stage`

---

### Prod (Production)

> **Audience:** End Users (via deployed applications)

The Prod subscription hosts **live, mission-critical workloads**. Only changes validated through the Sandbox → Dev → Stage pipeline reach this environment.

**Purpose:**
- Serve production application traffic
- Enforce strictest security and compliance controls

**Branch:** `main`

---

### DR (Disaster Recovery)

> **Audience:** Platform Engineer (K8s Admins) for failover operations

The DR environment is a **passive replica** of Prod deployed in a secondary Azure region. It activates only during regional outages or planned failover events.

**Purpose:**
- Business continuity during regional Azure outages
- RPO/RTO compliance for mission-critical workloads
- Automated infrastructure sync from Prod
- Periodic failover drills

**Branch:** `main` (same as Prod — see DR Branch Strategy below)

#### DR Branch Strategy

The recommended approach for DR is to use the **same `main` branch** as Prod for the following reasons:

| Option | Approach | Recommendation |
|--------|----------|----------------|
| **`main` (shared with Prod)** | DR deploys identical code/infra as Prod | ✅ **Recommended** — ensures parity, reduces drift |
| `dr` (dedicated branch) | Separate branch for DR-specific config | ⚠️ Only if DR has region-specific overrides that can't be handled by tfvars |
| `release/*` tag-based | DR pins to the last stable release tag | ⚠️ Acceptable for blue/green but adds complexity |

**Rationale:** DR must be an exact replica of Prod to guarantee a seamless failover. Using the same `main` branch eliminates configuration drift. Region-specific differences (e.g., secondary region endpoints) should be managed via environment-specific tfvars files (`dr.tfvars`), not a separate branch.

---

## Subscription-to-Cluster Mapping

| Subscription | Clusters | Purpose |
|--------------|----------|---------|
| **Sandbox** | 1 cluster (sandbox) | Platform admin experimentation |
| **NonProd** | 2 clusters (dev + stage) | Application development and pre-production validation |
| **Prod** | 1 cluster (prod) | Live workloads |
| **DR / Prod-Secondary** | 1 cluster (dr) | Disaster recovery failover |

---

## Resource Groups per Environment

### Sandbox

| Resource Group | Purpose |
|----------------|---------|
| `kaas-cdp-sandbox-va-rg` | Core AKS cluster and platform resources |
| `MC_kaas-cdp-sandbox-va-rg_*` | AKS-managed node resource group |
| `kaas-cdp-sandbox-va-networking-rg` | VNet, subnets, NSGs |

### Dev (NonProd Subscription)

| Resource Group | Purpose |
|----------------|---------|
| `kaas-cdp-dev-va-rg` | Dev AKS cluster and platform resources |
| `MC_kaas-cdp-dev-va-rg_*` | AKS-managed node resource group |
| `kaas-cdp-dev-va-networking-rg` | VNet, subnets, NSGs |

### Stage (NonProd Subscription)

| Resource Group | Purpose |
|----------------|---------|
| `kaas-cdp-stage-va-rg` | Stage AKS cluster and platform resources |
| `MC_kaas-cdp-stage-va-rg_*` | AKS-managed node resource group |
| `kaas-cdp-stage-va-networking-rg` | VNet, subnets, NSGs |

### Prod

| Resource Group | Purpose |
|----------------|---------|
| `kaas-cdp-prod-va-rg` | Core AKS cluster and platform resources |
| `MC_kaas-cdp-prod-va-rg_*` | AKS-managed node resource group |
| `kaas-cdp-prod-va-networking-rg` | VNet, subnets, NSGs |

### DR

| Resource Group | Purpose |
|----------------|---------|
| `kaas-cdp-dr-az-rg` | DR AKS cluster and platform resources |
| `MC_kaas-cdp-dr-az-rg_*` | AKS-managed node resource group |
| `kaas-cdp-dr-az-networking-rg` | VNet, subnets, NSGs |

---

## Key Resources per Environment

| Resource | Sandbox | Dev | Stage | Prod | DR |
|----------|---------|-----|-------|------|----|
| AKS Cluster | `kaas-sandbox-va-aks` | `kaas-dev-va-aks` | `kaas-stage-va-aks` | `kaas-prod-va-aks` | `kaas-dr-az-aks` |
| ACR | `kaassandboxvaacr` | `kaasdevvaacr` | `kaasstagevaacr` | `kaasprodvaacr` | `kaasdrazacr` |
| Key Vault | `kaas-sandbox-va-kv` | `kaas-dev-va-kv` | `kaas-stage-va-kv` | `kaas-prod-va-kv` | `kaas-dr-az-kv` |
| Log Analytics | `kaas-sandbox-va-law` | `kaas-dev-va-law` | `kaas-stage-va-law` | `kaas-prod-va-law` | `kaas-dr-az-law` |
| Managed Identity | `kaas-cdp-sandbox-va-k8s-mi` | `kaas-cdp-dev-va-k8s-mi` | `kaas-cdp-stage-va-k8s-mi` | `kaas-cdp-prod-va-k8s-mi` | `kaas-cdp-dr-az-k8s-mi` |
| Private DNS Zone | `privatelink.usgovvirginia.cx.aks.containerservice.azure.us` | Same | Same | Same | `privatelink.usgovarizona.cx.aks.containerservice.azure.us` |

---

## Network Topology

```

```

---

## Environment Configurations (Terraform)

Each environment uses a dedicated tfvars file:

| Environment | Tfvars File | Backend Config |
|-------------|-------------|----------------|
| Sandbox | `sandbox.tfvars` | `<TBD>` |
| Dev | `dev.tfvars` | `<TBD>` |
| Stage | `stage.tfvars` | `<TBD>` |
| Prod | `prod.tfvars` | `<TBD>` |
| DR | `dr.tfvars` | `<TBD>` |

### Example: dev.tfvars

```hcl
cluster_name        = "kaas-dev-va-aks"
resource_group_name = "kaas-cdp-dev-va-rg"
location            = "USGov Virginia"
sku_tier            = "Free"
kubernetes_version  = "1.29"

default_node_pool = {
  node_count          = 2
  vm_size             = "Standard_D4s_v5"
  enable_auto_scaling = true
  min_count           = 2
  max_count           = 5
  max_pods            = 30
  os_type             = "Linux"
}
```

### Example: dr.tfvars

```hcl
cluster_name        = "kaas-dr-az-aks"
resource_group_name = "kaas-cdp-dr-az-rg"
location            = "USGov Arizona"
sku_tier            = "Standard"
kubernetes_version  = "1.29"

default_node_pool = {
  node_count          = 2
  vm_size             = "Standard_D4s_v5"
  enable_auto_scaling = true
  min_count           = 2
  max_count           = 5
  max_pods            = 30
  os_type             = "Linux"
}
```

---

## Access Control per Environment

| Role | Sandbox | Dev | Stage | Prod | DR |
|------|---------|-----|-------|------|----|
| Platform Engineer (K8s Admin) | Full access | Full access | Full access | Full access | Full access |
| Developer | ❌ No access | Full access | Read + Deploy | ❌ No access | ❌ No access |
| Security | Audit / Read | Audit / Read | Audit / Read | Audit / Read | Audit / Read |
| End User | ❌ | ❌ | ❌ | App URLs only | App URLs only (failover) |

---

## Promotion Flow

```
┌──────────────┐          ┌──────────────────────────────────────┐          ┌──────────────┐          ┌──────────────┐
│  Sandbox     │ ──MR──▶  │  NonProd Subscription                │ ──MR &─▶ │  Prod        │ ──sync─▶ │  DR          │
│              │          │  ┌─────────┐       ┌─────────┐      │ Approval │              │          │              │
│  K8s Admin   │          │  │   Dev   │──MR─▶ │  Stage  │      │          │  Live        │          │  Failover    │
│  experiment  │          │  │ Cluster │       │ Cluster │      │          │  Workloads   │          │  Replica     │
│              │          │  └─────────┘       └─────────┘      │          │              │          │  (secondary  │
│              │          │                                      │          │              │          │   region)    │
└──────────────┘          └──────────────────────────────────────┘          └──────────────┘          └──────────────┘
     sandbox                      dev                stage                       main                      main
```

---

### Promotion Rules

| From → To | Trigger | Gate |
|-----------|---------|------|
| Sandbox → Dev | Merge Request to `dev` | CI pipeline pass |
| Dev → Stage | Merge Request to `stage` | CI pipeline pass |
| Stage → Prod | Merge Request to `main` | CI pass + Manual approval |
| Prod → DR | Automatic sync | Infrastructure-as-code sync from `main` |

---

## Environment Isolation Rules

| Rule | Description |
|------|-------------|
| No cross-subscription access | Resources in one subscription cannot access another |
| Separate identities | Each environment has its own managed identity |
| Separate secrets | Key Vault is per-environment; secrets are never shared |
| Network isolation | VNets are peered to hub only, not to each other |
| Separate ACR | Images promoted between registries, not shared directly |
| Independent state | Terraform state files are per-environment |
| NonProd cluster isolation | Dev and Stage clusters are logically separate within the same subscription |
| DR region isolation | DR runs in a secondary Azure region (Arizona) for geographic redundancy |

---

## Quick Reference: "Where do I work?"

| I am a... | I deploy to... | My environment is... |
|-----------|---------------|---------------------|
| Platform Engineer (K8s Admin) experimenting with infra | Sandbox subscription | **Sandbox** |
| Platform Engineer (K8s Admin) validating for dev | NonProd subscription | **Dev** |
| App Developer building features | NonProd subscription | **Dev** |
| App Team running integration/performance tests | NonProd subscription | **Stage** |
| Platform Engineer (K8s Admin) validating before Prod | NonProd subscription | **Stage** |
| Platform Engineer (K8s Admin) deploying to production | Prod subscription | **Prod** |
| Platform Engineer (K8s Admin) managing failover | DR subscription | **DR** |

---

## Related Documentation
