# IaC Module Testing Process — Sandbox to Production

> Standard process for developing, testing, approving, and promoting Terraform modules
> from the **Sandbox** (primary testing/playground) through **dev → uat → prod**.

---

## Table of Contents

1. [Objective](#objective)
2. [Scope](#scope)
3. [Environment Promotion Model](#environment-promotion-model)
4. [Process Overview](#process-overview)
5. [Phase 1 — Develop & Test in Sandbox (Primary / Playground)](#phase-1--develop--test-in-sandbox-primary--playground)
6. [Phase 2 — Record Test Results](#phase-2--record-test-results)
7. [Phase 3 — Approval Gate](#phase-3--approval-gate)
8. [Phase 4 — Promote to Dev (Pipeline Testing)](#phase-4--promote-to-nonprod)
9. [Phase 5 — Multi Use Case Testing via Pipeline](#phase-5--multi-use-case-testing)
10. [Phase 6 — Record Results & Publish](#phase-6--record-results--publish)
11. [Process Diagram](#process-diagram)
12. [Test Result Template](#test-result-template)
13. [Recording Test Results for Future Reference](#recording-test-results-for-future-reference)

---

## Objective

Provide a single, repeatable process for building and validating Terraform IaC modules so that
every module is proven in the **Sandbox** before it is promoted through **dev → uat → prod** via
the pipeline. The process ensures each module is tested, security-scanned, peer-reviewed, and its
results recorded for audit and future reference before it is published for consumption.

## Scope

This process applies to all KaaS Terraform IaC modules and the following subscriptions:

| Environment | Subscription | Purpose |
|-------------|-------------|---------|
| **Sandbox** | **Subscription X** | Primary testing environment & playground (hands-on, platform engineers) |
| **Dev** | **Subscription Y** | First promoted environment — automated pipeline testing |
| **UAT / Prod** | **Subscription Z** | Pre-production acceptance and production release — pipeline only |

**Applies to:**

- All reusable Terraform modules developed by the KaaS platform team.
- Development, testing, approval, promotion, and publishing of those modules.

**Module structure & location:**

- The IaC Terraform **module structure standard** is documented at
  [https://git.web.boeing.com/kaas/catalog/iac/terraform/azure](https://git.web.boeing.com/kaas/catalog/iac/terraform/azure).
- All new modules must be created under the **`azure` subgroup** in GitLab, following that
  standard structure.

**Out of scope:** application workload deployment, cluster provisioning, and non-Terraform IaC.

---

## Environment Promotion Model

> The **Sandbox** is the **primary testing environment and playground**. Every module is first
> developed, experimented with, and validated in the Sandbox. Once it is proven and approved,
> it is **promoted through dev → uat → prod** via the pipeline.

```
+====================================================================================+
|                        MODULE ENVIRONMENT PROMOTION                                 |
+====================================================================================+
|                                                                                    |
|   SANDBOX            -->     DEV        -->     UAT        -->     PROD             |
|   (Primary /                (Pipeline           (Pipeline          (Pipeline        |
|    Playground)               testing)            validation)        release)        |
|                                                                                    |
|   Experiment &              Automated CI        Pre-prod            Production      |
|   validate modules          plan/apply/test     acceptance          consumption     |
|   manually. Break           in real env.         testing with        of published   |
|   things freely.            No manual apply.     prod-like config.   module.         |
|                                                                                    |
|   Platform Engineers        Pipeline only        Pipeline only       Pipeline only  |
|   (hands-on)                                                                        |
|                                                                                    |
+====================================================================================+
```

| Environment | Role | Access | What Happens |
|-------------|------|--------|--------------|
| **Sandbox** | **Primary testing & playground** | Platform Engineers (hands-on) | Develop, experiment, break/fix, manual `plan`/`apply`/`destroy`, Terratest |
| **Dev** | First promoted environment | Pipeline only | Automated CI validation in a real environment after approval |
| **UAT** | Pre-production acceptance | Pipeline only | Prod-like configuration, acceptance and multi use-case testing |
| **Prod** | Production release | Pipeline only | Published module consumed by production workloads |

> **Rule:** Only the Sandbox allows manual hands-on work. Once a module leaves the Sandbox,
> all changes in dev, uat, and prod flow **through the pipeline only** — no direct `kubectl`
> or `terraform apply` by hand.

> ⚠️ **IMPORTANT — Branch Naming Triggers the Pipeline**
>
> The CI/CD jobs are wired to specific branch names. Your branch **must** be named exactly one of:
> `sandbox`, `dev`, `uat`, or `main` — **with or without an underscore** (e.g., `sandbox` / `sand_box`,
> `dev` / `dev_*`, `uat` / `uat_*`, `main` / `prod_*` are all recognized).
>
> If you use **any other pattern** (e.g., `feature/dev-x`, `test-dev`, `development`, `staging`,
> `production`, `sbx`), the **pipeline/workflow will NOT trigger** and the environment jobs will be
> skipped. Match the environment branch name exactly (with or without underscore) so the correct
> environment job runs.

| Environment | Valid Branch Names | Will NOT Trigger (examples) |
|-------------|--------------------|------------------------------|
| Sandbox | `sandbox`, `sandbox_*` | `sbx`, `feature/sandbox`, `test-sandbox` |
| Dev | `dev`, `dev_*` | `development`, `feature/dev`, `dev-branch` |
| UAT | `uat`, `uat_*` | `staging`, `feature/uat`, `uat-test` |
| main | `main` | `main_*`, `release`, `feature/main` |

> 📌 **NOTE — `main` Must Be a Single Branch**
>
> There must be **only one `main` branch** per repository — it is the single source of truth for
> published/released module code. Do **not** create multiple main branches (e.g., `main-dev`,
> `main-prod`, `main2`, or per-environment `main` variants). The environment branches
> (`sandbox`, `dev`, `uat`, `prod`) are used for promotion/testing; `main` alone holds the
> approved, tagged, releasable state.

---

## Process Overview

```
+====================================================================================+
|              MODULE TESTING PROCESS — SANDBOX TO PRODUCTION (DEV/UAT/PROD)           |
+====================================================================================+
|                                                                                    |
|  PHASE 1           PHASE 2          PHASE 3          PHASE 4          PHASE 5      |
|  Sandbox Testing   Record Results   Approval Gate    Dev Pipeline      Use Case     |
|  (Subscription X)  (JIRA story/task)(MR + 2 reviews) (Automated CI)    Testing      |
|                                                                                    |
|  Developer         Developer        Reviewers        Pipeline          Pipeline     |
|  runs locally      documents        approve MR       runs in Dev       runs all     |
|  in Sandbox        test evidence    + security       (Subscription Y)  scenarios    |
|                                                                                    |
|  terraform plan    Screenshots      Code review      terraform plan    basic        |
|  terraform apply   Output logs      Security scan    terraform apply   complete     |
|  manual validate   Pass/Fail        Architecture     automated destroy PE test      |
|  terraform destroy recorded         review           cleanup           tagging test |
|                                                                                    |
|  ----------------------- promote through dev -> uat -> prod ---------------------- |
|                          (uat / prod on Subscription Z, pipeline only)             |
|                                                                                    |
+====================================================================================+
```

> Modules start in the **Sandbox (Subscription X)**, get promoted to **Dev (Subscription Y)** via
> the pipeline after approval, then continue through **UAT and Prod (Subscription Z)** — all
> pipeline-driven, no manual applies outside the Sandbox.

---

## Phase 1 — Develop & Test in Sandbox (Primary / Playground)

> **Where:** Sandbox Subscription (primary testing environment & playground — platform engineers only)
> **Who:** Module developer (Platform Engineer)
> **Purpose:** Develop, experiment, and validate the module before promoting it to dev → uat → prod
>
> The Sandbox is where you break things freely, iterate, and prove the module works. Nothing is
> promoted out of the Sandbox until it passes here and clears the approval gate.

### Sandbox Environment Configuration

```hcl
# backends/sandbox.backend.hcl
resource_group_name  = "kaas-iao-sandbox-va-rg"
storage_account_name = "kaasiao00001sbxvasa"
container_name       = "tfstate-00001-platform"
key                  = "modules/sandbox/<module-name>.terraform.tfstate"
use_azuread_auth     = true
subscription_id      = "<sandbox-subscription-id>"
tenant_id            = "<tenant-id>"
```

---

## Phase 2 — Record Test Results

> **Where:** JIRA story/task linked to the MR
> **Who:** Module developer
> **Purpose:** Document evidence that the module was tested and working in Sandbox

### What to Record

Record results on the JIRA story/task using the [Test Result Template](#test-result-template) below and attach:

| Evidence | How to Capture | Where to Store |
|----------|---------------|----------------|
| `terraform plan` output | `terraform plan -no-color > plan-output.txt` | Attach to JIRA story/task |
| `terraform apply` output | `terraform apply -no-color > apply-output.txt` | Attach to JIRA story/task |
| Resource verification (screenshot or CLI) | `az resource show` output or Portal screenshot | Attach to JIRA story/task |
| Terratest output | `go test -v 2>&1 > terratest-output.txt` | Attach to JIRA story/task |
| `tfsec` scan results | `tfsec . --format json > tfsec-results.json` | Attach to JIRA story/task |
| Destroy confirmation | `terraform destroy` output | Attach to JIRA story/task |

### JIRA Story/Task Title Format

```
[KAAS-XXX] Module Test: <module-name> — Sandbox Validation Results
```

---

## Phase 3 — Approval Gate

> **Where:** GitLab MR
> **Who:** 2-3 Reviewers (Platform Engineers + Security)
> **Purpose:** Code review, security review, and approval before pipeline testing

### MR Submission Checklist

| # | Requirement | Status |
|---|-------------|--------|
| 1 | Lab test issue linked to MR | [ ] |
| 2 | All test results attached (plan, apply, destroy, terratest) | [ ] |
| 3 | `terraform fmt -check` passes | [ ] |
| 4 | `terraform validate` passes | [ ] |
| 5 | `tflint` passes | [ ] |
| 6 | `tfsec` / `checkov` passes (no HIGH/CRITICAL) | [ ] |
| 7 | `terraform-docs` generated and current | [ ] |
| 8 | CHANGELOG.md updated | [ ] |
| 9 | Examples deploy successfully in lab | [ ] |
| 10 | Terratest passes locally | [ ] |

### Reviewer Responsibilities

| Reviewer | Focus | Must Verify |
|----------|-------|-------------|
| Reviewer 1 (Platform Eng) | Code quality | Variables, naming, for_each, locals, comments |
| Reviewer 2 (Platform Eng) | Functionality | Examples work, outputs correct, test coverage |
| Reviewer 3 (Security) | Security posture | Private endpoints, RBAC, encryption, no public access, tags |

### Approval Rules

- **Minimum 2 approvals** required to merge
- MR cannot merge until CI pipeline passes
- Security reviewer must approve if module creates network or identity resources

---

## Phase 4 — Promote to NonProd (Pipeline Testing)

> **Where:** NonProd Subscription (Dev Cluster) — automated via CI pipeline
> **Who:** Pipeline (triggered on MR merge or manual)
> **Purpose:** Validate module works via automated pipeline in a real environment

### What Happens After MR Merge

```
MR merged to dev branch
        |
        v
GitLab CI Pipeline triggered (NonProd Dev Cluster)
        |
        +-- Stage: validate
        |   - terraform fmt -check
        |   - terraform init -backend=false
        |   - terraform validate
        |   - tflint
        |   - tfsec
        |   - terraform-docs --output-check
        |
        +-- Stage: plan
        |   - terraform init -backend-config=backends/dev.backend.hcl
        |   - terraform plan -var-file=dev.tfvars -out=plan.tfplan
        |   - (plan artifact saved)
        |
        +-- Stage: apply (manual gate for first run)
        |   - terraform apply plan.tfplan
        |   - (resources created in NonProd)
        |
        +-- Stage: test (Terratest)
        |   - cd test
        |   - go test -v -timeout 45m ./...
        |   - (all use cases validated)
        |
        +-- Stage: destroy (automated cleanup)
            - terraform destroy -auto-approve
            - (resources removed)
```

---

## Phase 5 — Multi Use Case Testing

> **Where:** NonProd Subscription (via pipeline)
> **Who:** Automated pipeline (all tests run)
> **Purpose:** Validate module across different configurations and edge cases

### Use Cases Tested

| # | Test | What It Validates | Pass Criteria |
|---|------|-------------------|---------------|
| 1 | Basic deployment | Module deploys with minimum required vars | Resources created, outputs non-empty |
| 2 | Complete deployment | All features enabled (PE, versioning, tags, encryption) | All features functional |
| 3 | Private endpoint | PE created and resolves via private DNS | Private IP assigned, DNS resolves |
| 4 | No public access | Public access disabled, not reachable externally | Connection refused from public |
| 5 | Multi-instance | Multiple resources via for_each | No naming conflicts, all independent |
| 6 | Tagging compliance | All 5 mandatory tags applied | Tags present on every resource |
| 7 | Idempotency | `terraform apply` twice with no changes | Second apply shows "no changes" |
| 8 | Destroy clean | All resources removed on destroy | No orphaned resources |
| 9 | Different environments | Deploy with dev.tfvars, then stage.tfvars | Both work, no env-specific issues |

---

## Phase 6 — Record Results & Publish

> **Where:** JIRA story/task + Pipeline artifacts
> **Who:** Pipeline (automated) + Developer (review)
> **Purpose:** Document all test results and publish the module

### Automated Recording

Pipeline automatically saves:
- `plan-output.txt` — Terraform plan for each use case
- `apply-output.txt` — Terraform apply output
- `test-results.txt` — Terratest output with pass/fail per test
- `tfsec-results.json` — Security scan results
- `report.xml` — JUnit format for GitLab test visualization

### Final Checklist Before Publishing

| # | Check | Source | Status |
|---|-------|--------|--------|
| 1 | Lab tests passed (Phase 1) | Lab test issue | [ ] |
| 2 | MR approved by 2+ reviewers (Phase 3) | MR approvals | [ ] |
| 3 | Pipeline validate stage green | CI | [ ] |
| 4 | Pipeline apply stage green | CI | [ ] |
| 5 | All use case tests passed (Phase 5) | CI test artifacts | [ ] |
| 6 | Destroy clean — no orphaned resources | CI destroy stage | [ ] |
| 7 | Security scan clean (no HIGH/CRITICAL) | tfsec artifact | [ ] |
| 8 | Documentation generated and current | terraform-docs | [ ] |
| 9 | CHANGELOG updated with version | CHANGELOG.md | [ ] |
| 10 | Ready to tag and publish | — | [ ] |

### Publish

```bash
git checkout main
git pull
git tag v25.08
git push origin v25.08
```

---

## Process Diagram

```mermaid
flowchart TD
    START([Developer creates module]) --> LAB

    subgraph LAB["Phase 1: Lab Testing (Dev Subscription)"]
        direction TB
        L1["Write module code"]
        L2["terraform fmt + validate + tflint + tfsec"]
        L3["terraform plan + apply (basic example)"]
        L4["terraform plan + apply (complete example)"]
        L5["Manual verification (Portal / CLI)"]
        L6["Terratest (local)"]
        L7["terraform destroy (cleanup)"]
        L1 --> L2 --> L3 --> L4 --> L5 --> L6 --> L7
    end

    LAB --> RECORD

    subgraph RECORD["Phase 2: Record Results"]
        direction TB
        R1["Create JIRA story/task"]
        R2["Attach plan/apply/destroy outputs"]
        R3["Attach terratest results"]
        R4["Attach tfsec scan"]
        R1 --> R2 --> R3 --> R4
    end

    RECORD --> REVIEW

    subgraph REVIEW["Phase 3: Approval Gate"]
        direction TB
        V1["Submit MR with lab test issue linked"]
        V2["Reviewer 1: Code quality"]
        V3["Reviewer 2: Functionality"]
        V4["Reviewer 3: Security"]
        V5{2+ Approvals?}
        V1 --> V2 & V3 & V4 --> V5
        V5 -->|No| V1
    end

    V5 -->|Yes| MERGE["MR Merged to dev"]
    MERGE --> PIPELINE

    subgraph PIPELINE["Phase 4: NonProd Pipeline (Automated)"]
        direction TB
        P1["validate: fmt + init + validate + tflint + tfsec"]
        P2["plan: terraform plan (NonProd Dev)"]
        P3["apply: terraform apply"]
        P4["test: Terratest (all use cases)"]
        P5["destroy: cleanup"]
        P1 --> P2 --> P3 --> P4 --> P5
    end

    PIPELINE --> USECASE

    subgraph USECASE["Phase 5: Multi Use Case Testing"]
        direction LR
        U1["Basic"]
        U2["Complete"]
        U3["Private EP"]
        U4["Tagging"]
        U5["Idempotency"]
        U6["Multi-instance"]
    end

    USECASE --> PUBLISH

    subgraph PUBLISH["Phase 6: Record & Publish"]
        direction TB
        PB1["All test artifacts saved"]
        PB2["Final checklist passed"]
        PB3["git tag v25.08"]
        PB4(["Module Published"])
        PB1 --> PB2 --> PB3 --> PB4
    end

    style LAB fill:#e8f5e9,stroke:#2e7d32
    style RECORD fill:#e3f2fd,stroke:#1565c0
    style REVIEW fill:#fff3e0,stroke:#e65100
    style PIPELINE fill:#f3e5f5,stroke:#7b1fa2
    style USECASE fill:#fce4ec,stroke:#c62828
    style PUBLISH fill:#e0f2f1,stroke:#00695c
```

---

## Test Result Template

Use this template when recording test results in a JIRA story/task:

```markdown
## Module Test Results: <module-name>

### Module Info
- **Module:** catalog/iac/terraform/azure/<module-name>
- **Version:** v25.08
- **Developer:** [Name]
- **Date:** [YYYY-MM-DD]
- **Branch:** feat/KAAS-XXX-<description>

### Lab Testing (Dev Subscription)

| # | Test | Command | Result | Duration |
|---|------|---------|--------|----------|
| 1 | Format | `terraform fmt -check` | PASS / FAIL | — |
| 2 | Validate | `terraform validate` | PASS / FAIL | — |
| 3 | Lint | `tflint` | PASS / FAIL | — |
| 4 | Security scan | `tfsec .` | PASS / FAIL (findings: X) | — |
| 5 | Plan (basic) | `terraform plan` | PASS / FAIL (resources: X to add) | Xs |
| 6 | Apply (basic) | `terraform apply` | PASS / FAIL | Xs |
| 7 | Verify (basic) | Manual / CLI check | PASS / FAIL | — |
| 8 | Plan (complete) | `terraform plan` | PASS / FAIL (resources: X to add) | Xs |
| 9 | Apply (complete) | `terraform apply` | PASS / FAIL | Xs |
| 10 | Verify (complete) | Manual / CLI check | PASS / FAIL | — |
| 11 | Terratest | `go test -v ./...` | PASS / FAIL (X/Y tests passed) | Xs |
| 12 | Destroy | `terraform destroy` | PASS / FAIL | Xs |

### Pipeline Testing (NonProd Subscription)

| # | Use Case | Result | Duration | Notes |
|---|----------|--------|----------|-------|
| 1 | Basic deployment | PASS / FAIL | Xs | |
| 2 | Complete deployment | PASS / FAIL | Xs | |
| 3 | Private endpoint | PASS / FAIL | Xs | |
| 4 | No public access | PASS / FAIL | Xs | |
| 5 | Multi-instance | PASS / FAIL | Xs | |
| 6 | Tagging compliance | PASS / FAIL | Xs | |
| 7 | Idempotency | PASS / FAIL | Xs | |
| 8 | Destroy clean | PASS / FAIL | Xs | |

### Attached Evidence
- [ ] plan-output.txt
- [ ] apply-output.txt
- [ ] terratest-output.txt
- [ ] tfsec-results.json
- [ ] destroy-output.txt
- [ ] Screenshot / CLI verification

### Sign-Off
- [ ] Developer confirms all tests pass
- [ ] Ready for MR review
```

---

## Quick Reference

```
Process:     Sandbox Test → Record → Approve (2+ reviewers) → Pipeline Test → Publish
Sandbox:     Subscription X (manual terraform plan/apply/destroy)
Pipeline:    Dev/UAT/Prod (automated CI: validate → plan → apply → test → destroy)
Evidence:    JIRA story/task with test outputs attached
Approval:    MR with 2+ approvals (platform eng + security)
Use Cases:   basic, complete, PE, tagging, multi-instance, idempotency, destroy-clean
Publish:     git tag vYY.MM after all phases pass
```

---

## Recording Test Results for Future Reference

> Every test run — whether in Sandbox, Dev pipeline, or scheduled regression — must be recorded
> in a structured format so the team can reference historical results, compare versions,
> audit compliance, and onboard new engineers.

### Where to Store Test Records

| Record Type | Storage Location | Retention |
|-------------|-----------------|-----------|
| Sandbox test results (per module, per version) | JIRA story/task (label: `test-result`) | Permanent — never delete |
| Pipeline test artifacts | GitLab CI job artifacts | 90 days (auto-expire) |
| Regression comparison (version A vs B) | JIRA story/task (label: `regression`) | Permanent |
| Monthly scheduled regression | JIRA story/task (auto-created by pipeline) | Permanent |
| Test evidence archive | `support/test-records/<module>/<version>/` repo | Permanent |

### Test Record Folder Structure

Create a dedicated folder per module per version in the `support/` repo:

```
support/test-records/
|
|-- storage-account/
|   |-- v25.07/
|   |   |-- lab-results.md            <- Lab test results (copy of Issue)
|   |   |-- plan-basic.txt            <- terraform plan output (basic)
|   |   |-- plan-complete.txt         <- terraform plan output (complete)
|   |   |-- apply-basic.txt           <- terraform apply output
|   |   |-- apply-complete.txt
|   |   |-- terratest-output.txt      <- Full Terratest log
|   |   |-- tfsec-results.json        <- Security scan
|   |   |-- destroy-output.txt
|   |   +-- screenshots/              <- Azure Portal / CLI screenshots
|   |
|   |-- v25.08/
|   |   |-- lab-results.md
|   |   |-- pipeline-results.md       <- Dev pipeline results
|   |   |-- regression-results.md     <- Regression comparison (v25.07 → v25.08)
|   |   |-- ...
|   |   +-- screenshots/
|   |
|   +-- v25.08.1/
|       |-- ...
|
|-- keyvault/
|   |-- v25.08/
|   |   |-- ...
|
+-- network/
    |-- v25.08/
        |-- ...
```

### How to Record (Step by Step)

| # | When | Action | Output |
|---|------|--------|--------|
| 1 | After Sandbox testing | Copy all terminal outputs to text files | `plan-basic.txt`, `apply-basic.txt`, etc. |
| 2 | After Sandbox testing | Take screenshots of resource in Azure Portal | `screenshots/resource-created.png` |
| 3 | After Sandbox testing | Create JIRA story/task with [Sandbox Results Template](#sandbox-results-template) | KAAS-XXX |
| 4 | After Sandbox testing | Push text files + screenshots to `support/test-records/<module>/<version>/` | Committed to repo |
| 5 | After Pipeline run | Download CI artifacts (auto-saved by pipeline) | `terratest-output.txt`, `tfsec-results.json` |
| 6 | After Pipeline run | Create or update JIRA story/task with pipeline results | KAAS-XXX updated |
| 7 | After Regression | Create JIRA story/task comparing previous vs current version | KAAS-YYY |
| 8 | On publish | Add final sign-off comment to the JIRA story/task | KAAS-XXX closed |

### Sandbox Results Template

Create this as a JIRA story/task after every Sandbox test:

```markdown
## Sandbox Test Record: <module-name> v<YY.MM>

### Metadata
| Field | Value |
|-------|-------|
| Module | `catalog/iac/terraform/azure/<module-name>` |
| Version | `v25.08` |
| Tester | [Name] |
| Date | YYYY-MM-DD |
| Environment | Sandbox (Subscription X) |
| Subscription | `<subscription-id>` |
| Branch | `feat/KAAS-XXX-<description>` |
| Jira | KAAS-XXX |

### Test Results

| # | Test | Command | Result | Duration | Notes |
|---|------|---------|--------|----------|-------|
| 1 | Format check | `terraform fmt -check` | PASS | — | |
| 2 | Validate | `terraform validate` | PASS | — | |
| 3 | Lint | `tflint` | PASS | — | 0 warnings |
| 4 | Security scan | `tfsec .` | PASS | — | 0 HIGH/CRITICAL |
| 5 | Plan (basic) | `terraform plan` | PASS | 12s | 3 resources to add |
| 6 | Apply (basic) | `terraform apply` | PASS | 45s | |
| 7 | Verify (basic) | Azure CLI / Portal | PASS | — | Resource exists, config correct |
| 8 | Plan (complete) | `terraform plan` | PASS | 15s | 7 resources to add |
| 9 | Apply (complete) | `terraform apply` | PASS | 1m20s | PE + tags + versioning |
| 10 | Verify (complete) | Azure CLI / Portal | PASS | — | PE resolves, tags present |
| 11 | Idempotency | `terraform apply` (2nd run) | PASS | 5s | "No changes" |
| 12 | Terratest (all) | `go test -v ./...` | PASS | 3m45s | 6/6 tests passed |
| 13 | Destroy | `terraform destroy` | PASS | 30s | All resources removed |

### Immutable Resource Verification
> These resources should NOT change after initial creation:

| Resource | Created | Verified Immutable | Notes |
|----------|---------|-------------------|-------|
| Storage Account name | Yes | Name unchanged after re-apply | |
| Private Endpoint | Yes | PE ID unchanged after re-apply | |
| Encryption key | Yes | Key reference unchanged | |

### Mutable Resource Verification
> These resources can be updated without recreation:

| Resource | Updated | Verified Mutable | Notes |
|----------|---------|-----------------|-------|
| Tags | Updated | Tags changed without destroy | |
| Blob versioning | Toggled | Enabled/disabled without recreate | |
| Soft delete days | Changed | Updated in-place | |

### Attached Evidence
- [x] `plan-basic.txt`
- [x] `apply-basic.txt`
- [x] `plan-complete.txt`
- [x] `apply-complete.txt`
- [x] `terratest-output.txt`
- [x] `tfsec-results.json`
- [x] `destroy-output.txt`
- [x] `screenshots/resource-created.png`
- [x] `screenshots/pe-private-ip.png`
- [x] `screenshots/tags-applied.png`

### Sign-Off
- [x] All tests pass
- [x] Evidence committed to `support/test-records/<module>/v25.08/`
- [x] Ready for MR submission
```

### Pipeline Results Template

Append to the same JIRA story/task after Dev pipeline runs:

```markdown
## Pipeline Test Record: <module-name> v<YY.MM>

### Pipeline Info
| Field | Value |
|-------|-------|
| Pipeline ID | #12345 |
| Branch | `dev` |
| Environment | NonProd (Dev Cluster) |
| Triggered by | MR merge / Manual / Schedule |
| Date | YYYY-MM-DD |

### Stage Results

| Stage | Status | Duration | Job ID |
|-------|--------|----------|--------|
| validate | PASS | 15s | #67890 |
| plan | PASS | 20s | #67891 |
| apply | PASS | 1m30s | #67892 |
| test | PASS | 4m15s | #67893 |
| destroy | PASS | 35s | #67894 |

### Use Case Results

| # | Use Case | Result | Duration | Artifacts |
|---|----------|--------|----------|-----------|
| 1 | Basic deployment | PASS | 45s | plan-basic.txt |
| 2 | Complete deployment | PASS | 1m20s | plan-complete.txt |
| 3 | Private endpoint | PASS | 1m35s | pe-test-output.txt |
| 4 | Tagging compliance | PASS | 40s | tag-test-output.txt |
| 5 | Multi-instance | PASS | 2m10s | multi-test-output.txt |
| 6 | Idempotency | PASS | 20s | idempotency-output.txt |
| 7 | Destroy clean | PASS | 30s | destroy-output.txt |

### Pipeline Artifacts Downloaded
- [x] All artifacts saved to `support/test-records/<module>/v25.08/`
```

### Regression Results Template

Create a separate Issue when comparing versions:

```markdown
## Regression Record: <module-name> v25.07 → v25.08

### Change Summary
| Field | Value |
|-------|-------|
| Previous version | v25.07 |
| New version | v25.08 |
| Change type | Feature / Bugfix / Refactor |
| What changed | [Brief description] |

### Side-by-Side Comparison

| # | Test | v25.07 Result | v25.08 Result | Status |
|---|------|---------------|---------------|--------|
| 1 | Basic deployment | PASS | PASS | OK |
| 2 | Complete deployment | PASS | PASS | OK |
| 3 | Private endpoint | PASS | PASS | OK |
| 4 | Tagging | PASS | PASS | OK |
| 5 | Multi-instance | PASS | PASS | OK |
| 6 | Idempotency | PASS | PASS | OK |
| 7 | Destroy clean | PASS | PASS | OK |
| 8 | Backward compat (v25.07 tfvars) | — | PASS | OK |

### Verdict
- [x] No regressions detected
- [ ] Regression found (describe + fix)
```

### Why Record Everything

| Reason | How Records Help |
|--------|-----------------|
| **Audit & compliance** | Prove to governance that every module version was tested before publishing |
| **Incident investigation** | "Did we test this scenario?" — look up the exact test results for that version |
| **Onboarding** | New engineers see real test examples from past versions |
| **Regression baseline** | Compare current run against historical pass/fail to detect drift |
| **Version rollback** | Know exactly which version was last-known-good based on test records |
| **Knowledge transfer** | When a developer leaves, their test evidence remains in the repo |

### Recording Checklist

| # | Action | When | Who |
|---|--------|------|-----|
| 1 | Create JIRA story/task with Sandbox Results Template | After Sandbox testing | Developer |
| 2 | Commit evidence files to `support/test-records/<module>/<version>/` | After Sandbox testing | Developer |
| 3 | Update JIRA story/task with Pipeline Results Template | After Dev pipeline completes | Developer / Auto |
| 4 | Create Regression JIRA story/task (if version update) | After regression run | Developer |
| 5 | Download and archive pipeline artifacts | After Dev pipeline | Developer |
| 6 | Add final sign-off comment and close JIRA story/task | After publishing | Developer |
| 7 | Link JIRA story/task to the module MR | During MR submission | Developer |
| 8 | Link JIRA story/task to Jira epic | During MR submission | Developer |