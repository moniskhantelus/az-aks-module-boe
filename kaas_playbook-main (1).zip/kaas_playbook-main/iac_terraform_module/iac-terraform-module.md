# KaaS Platform — Terraform Module Structure

> Standard structure for all reusable Terraform modules in `catalog/iac/terraform/azure/`.
> Every module must follow this layout to be publishable and consumable.

---

## Why This Structure?

A Terraform module without structure is just a collection of `.tf` files. It works for the person who wrote it, but fails everyone else — the next developer can't use it without guessing, the reviewer can't validate it without running it, and the consumer can't trust it without testing it.

This structure exists because:

| Problem Without Structure | How This Structure Solves It |
|--------------------------|------------------------------|
| "How do I use this module?" | `examples/basic-deployment/` — copy, paste, deploy |
| "What does this module actually create?" | `architecture/module-overview.drawio.png` — visual diagram |
| "Does this module work?" | `test/module_example_test.go` — Terratest proves it deploys and validates |
| "What inputs does it need?" | `README.md` — auto-generated from `variables.tf` by terraform-docs |
| "What changed in this version?" | `CHANGELOG.md` — CalVer entries with clear descriptions |
| "Is this module safe to use?" | `.gitlab-ci.yml` — lint, security scan, validate on every MR |
| "Can I trust the docs are current?" | `.terraform-docs.yml` — CI fails if docs are stale |
| "What version should I pin?" | Git tags with CalVer (`v25.08`) — predictable, traceable |
| "How do I contribute a fix?" | Standard layout — any engineer knows where everything lives |
| "Can I reuse internal patterns?" | `modules/` sub-modules — DRY within the module, not exposed externally |

**The goal:** Any platform engineer or app team can consume a module by reading the README, copying the basic example, and deploying — without needing to read the module's internal code or ask the author.

**The standard ensures:**
- **Discoverability** — consistent naming means you know where to look
- **Trustworthiness** — tests prove it works, CI proves it's secure
- **Self-documentation** — terraform-docs auto-generates from code, so docs never drift
- **Reusability** — examples show real usage, not abstract documentation
- **Maintainability** — changelog tracks history, versioning enables safe upgrades
- **Quality** — linting, scanning, and testing catch issues before publishing

---

## Table of Contents

1. [Module Directory Layout](#module-directory-layout)
2. [File Descriptions](#file-descriptions)
3. [Examples Directory](#examples-directory)
4. [Documentation (terraform-docs)](#documentation)
5. [Architecture Diagrams](#architecture-diagrams)
6. [Testing (Terratest)](#testing-terratest)
7. [Versioning & Publishing](#versioning--publishing)
8. [Module Checklist](#module-checklist)

---

## Module Directory Layout

```
catalog/iac/terraform/azure/<module-name>/
|
|-- main.tf                      <- Primary resource definitions
|-- variables.tf                 <- All input variable declarations
|-- outputs.tf                   <- All output value declarations
|-- versions.tf                  <- Required providers + Terraform version
|-- locals.tf                    <- Computed values, naming logic
|-- data.tf                      <- Data sources (lookups, existing resources)
|-- README.md                    <- Main entry point documentation (auto-generated)
|-- CHANGELOG.md                 <- Version history (CalVer YY.MM)
|-- LICENSE                      <- Boeing proprietary license
|
|-- examples/                    <- Real-world usage examples (deployable)
|   |-- basic/        <- Minimal usage — calls the root module
|   |   |-- main.tf
|   |   |-- variables.tf
|   |   +-- outputs.tf
|   |
|   +-- complete/                <- Full-featured example (all options)
|       |-- main.tf
|       |-- variables.tf
|       +-- outputs.tf
|
|-- test/                        <- Terratest integration tests
|   |-- go.mod                   <- Go module definition
|   |-- go.sum                   <- Go dependency lock
|   +-- module_example_test.go   <- Tests the example directory (deploy + validate)
|
|-- modules/                     <- Sub-modules (internal, reusable within this module)
|   |-- private-endpoint/        <- Sub-module: creates PE for any target resource
|   |   |-- main.tf
|   |   |-- variables.tf
|   |   +-- outputs.tf
|   |
|   +-- diagnostic-settings/     <- Sub-module: attaches diagnostic settings
|       |-- main.tf
|       |-- variables.tf
|       +-- outputs.tf
|
+-- architecture/                <- Module architecture diagrams
    |-- module-overview.drawio       <- draw.io source
    +-- module-overview.drawio.png   <- Rendered for README embedding
```

---

## File Descriptions

| File | Purpose | Required |
|------|---------|----------|
| `main.tf` | Resource definitions - the core logic of the module | **Yes** |
| `variables.tf` | All input variables with type, description, validation | **Yes** |
| `outputs.tf` | All outputs exposed to the caller | **Yes** |
| `versions.tf` | required_version + required_providers with pinned versions | **Yes** |
| `locals.tf` | Computed names, tags, conditional logic | **Yes** |
| `data.tf` | Data sources for lookups (resource groups, subnets, etc.) | If needed |
| `README.md` | Main entry point documentation - auto-generated by terraform-docs | **Yes** |
| `CHANGELOG.md` | Version history with CalVer entries (YY.MM) | **Yes** |
| `LICENSE` | Boeing proprietary license file | **Yes** |
| `.gitignore` | Ignore .terraform/, *.tfstate, *.tfplan | **Yes** |
| `examples/basic/` | Minimal working example - calls the root module | **Yes** |
| `examples/complete/` | Full example using all features/options | **Yes** |
| `test/module_example_test.go` | Terratest Go test - deploys example directory and validates | **Yes** |
| `test/go.mod` | Go module definition for Terratest | **Yes** |
| `modules/` | Sub-modules (internal reusable components within this module) | If needed |
| `architecture/` | draw.io diagrams showing what the module creates | **Yes** |

---

## Examples Directory

### Purpose

Examples are **deployable Terraform projects** that demonstrate how to consume the module. They serve as both documentation and integration test targets.

### Requirements

| Rule | Detail |
|------|--------|
| Every example must `terraform plan` successfully | CI validates this |
| Every example has its own `README.md` | Explains what the example does |
| `basic/` uses minimum required variables only | Shows simplest usage |
| `complete/` uses all available variables | Shows full feature set |
| Scenario examples show specific patterns | e.g., private endpoint, multi-region |

### Example: `examples/basic/main.tf`

```hcl
module "keyvault" {
  source = "../../"

  name                = "kaas-hr-12345-appa-dev-va-kv"
  resource_group_name = "kaas-hr-dev-va-rg"
  location            = "USGov Virginia"
  environment         = "dev"
  maintain_org        = "hr"

  tags = {
    environment  = "dev"
    maintain_org = "hr"
    managed_by   = "terraform"
  }
}
```

### Example: `examples/complete/main.tf`

```hcl
module "keyvault" {
  source = "../../"

  name                       = "kaas-hr-12345-appa-dev-va-kv"
  resource_group_name        = "kaas-hr-dev-va-rg"
  location                   = "USGov Virginia"
  environment                = "dev"
  maintain_org               = "hr"
  sku_name                   = "standard"
  soft_delete_retention_days = 90
  purge_protection_enabled   = true
  enable_rbac_authorization  = true
  public_network_access      = false

  private_endpoint = {
    subnet_id            = "/subscriptions/.../subnets/kaas_subnet_1"
    private_dns_zone_ids = ["/subscriptions/.../privateDnsZones/privatelink.vaultcore.azure.net"]
  }

  secrets = {
    "db-connection-string" = "Server=..."
    "api-key"              = "abc123"
  }

  tags = {
    environment  = "dev"
    maintain_org = "hr"
    esats_id     = "12345"
    managed_by   = "terraform"
  }
}
```

---

# Module: <module-name>

## When to Use

Describe when this module should be used vs alternatives.

## Architecture

![Module Architecture](../architecture/module-overview.drawio.png)

## Usage Scenarios

### Scenario 1: Basic Key Vault for an app
...

### Scenario 2: Key Vault with Private Endpoint
...

## Decision Matrix

| Need | Use This Module? | Alternative |
|------|-----------------|-------------|
| ... | ... | ... |

## Known Limitations

```markdown
# limitations

- Example

```


### Changelog (CHANGELOG.md)

```markdown
# Changelog

( NOTE: Please keep the latest release always in the top )

## 25.08.1
- Fixed: Private endpoint DNS zone linking
- Added: purge_protection_enabled variable

## 25.08 (August 2025)
- Initial release
- Supports Key Vault with RBAC, private endpoint, soft delete


```

---

## Architecture Diagrams

Each module includes a draw.io diagram showing what resources it creates and their relationships:

```
architecture/
|-- module-overview.drawio           <- Editable source
+-- module-overview.drawio.png       <- Rendered for docs
```

**Naming:** `<module-name>-<diagram-type>.drawio`

**Example for Key Vault module:**

```
+---------------------------------------------------+
|  Module: catalog/iac/terraform/azure/keyvault     |
+---------------------------------------------------+
|                                                   |
|  Creates:                                         |
|  +-- Azure Key Vault                              |
|  |   +-- Access Policies / RBAC                   |
|  |   +-- Secrets (optional)                       |
|  |   +-- Diagnostic Settings                      |
|  |                                                |
|  +-- Private Endpoint (optional)                  |
|  |   +-- NIC                                      |
|  |   +-- Private DNS Zone Link                    |
|  |                                                |
|  Inputs:                                          |
|  <- resource_group_name                           |
|  <- subnet_id (for PE)                            |
|  <- private_dns_zone_ids                          |
|                                                   |
|  Outputs:                                         |
|  -> key_vault_id                                  |
|  -> key_vault_uri                                 |
|  -> private_endpoint_ip                           |
+---------------------------------------------------+
```


## Versioning & Publishing

| Aspect | Standard |
|--------|----------|
| Version format | CalVer `vYY.MM` (e.g., `v25.08`) |
| Patch format | `vYY.MM.patch` (e.g., `v25.08.1`) |
| Published via | Git tag on the module repo |
| Consumed as | `source = "git::https://git.web.boeing.com/kaas/catalog/iac/terraform/azure/<module>.git?ref=v25.08"` |
| Future registry | JFrog Terraform Registry (when module count > 10) |

### Consuming a Module

```hcl
module "keyvault" {
  source = "git::https://git.web.boeing.com/kaas/catalog/iac/terraform/azure/keyvault.git?ref=v25.08"

  name                = local.kv_name
  resource_group_name = azurerm_resource_group.main.name
  location            = var.location
  environment         = var.environment
  maintain_org        = var.maintain_org
  tags                = local.common_tags
}
```

---

## Module Checklist

Before publishing a module version, verify:

| # | Check | Status |
|---|-------|--------|
| 1 | `main.tf`, `variables.tf`, `outputs.tf`, `versions.tf` present | [ ] |
| 2 | Every variable has `description` and `type` | [ ] |
| 3 | Validation blocks on enum variables (environment, region) | [ ] |
| 4 | `locals.tf` handles naming logic (no hardcoded names) | [ ] |
| 5 | `terraform fmt -check` passes | [ ] |
| 6 | `terraform validate` passes | [ ] |
| 7 | `tflint` passes with no errors | [ ] |
| 8 | `tfsec` / `checkov` passes (no HIGH/CRITICAL) | [ ] |
| 9 | `docs/README.md` auto-generated by terraform-docs | [ ] |
| 10 | `docs/USAGE.md` written with scenarios | [ ] |
| 11 | `docs/CHANGELOG.md` updated with new version entry | [ ] |
| 12 | `architecture/` has draw.io diagram of module resources | [ ] |
| 13 | `examples/basic/` deploys successfully | [ ] |
| 14 | `examples/complete/` deploys successfully | [ ] |
| 15 | Terratest `basic_test.go` passes | [ ] |
| 16 | Terratest `complete_test.go` passes | [ ] |
| 18 | Tagged with CalVer (`vYY.MM`) | [ ] |
| 19 | MR reviewed and approved by 2+ engineers | [ ] |

---

## Quick Reference

```
Module location:    catalog/iac/terraform/azure/<module-name>/
Structure:          main.tf | variables.tf | outputs.tf | versions.tf | locals.tf | data.tf
Documentation:      docs/README.md (auto) + docs/USAGE.md (manual) + docs/CHANGELOG.md
Architecture:       architecture/<module>-overview.drawio + .drawio.png
Examples:           examples/basic/ + examples/complete/ + examples/<scenario>/
Tests:              tests/basic_test.go + tests/complete_test.go (Terratest / Go)
CI Pipeline:        validate → test (Terratest) → publish (git tag)
Version:            CalVer vYY.MM (git tag)
Consume:            source = "git::https://.../<module>.git?ref=vYY.MM"
```