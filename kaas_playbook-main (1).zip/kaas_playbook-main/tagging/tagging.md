# KaaS Platform — Azure Resource Tagging Standards

> Defines the mandatory tags applied to all Azure resources provisioned by the KaaS platform.
> Tags enable cost attribution, compliance, operational support, and application traceability.

---

## Table of Contents

1. [Overview](#overview)
2. [Why Tags Matter](#why-tags-matter)
3. [Tag Categories](#tag-categories)
4. [ECS_CSF_TAG — Compliance & Security Framework](#ecs_csf_tag)
5. [ECS_HPOO_TAG — Operations & Support](#ecs_hpoo_tag)
6. [KAAS_TAG — Identity & Classification](#kaas_tag)
7. [KAAS_EXT_TAG — Contacts & Operations](#kaas_ext_tag)
8. [KAAS_INFRA_TAG — Workload & Network](#kaas_infra_tag)
9. [Tag Application Rules](#tag-application-rules)
10. [Examples](#examples)

---

## Overview

Every Azure resource created by the KaaS platform must carry five mandatory tag groups:

| Tag Name | Purpose | Applied To |
|----------|---------|------------|
| `ECS_CSF_TAG` | Compliance, security framework, asset ownership | All resources |
| `ECS_HPOO_TAG` | Operations support, incident routing, vendor info | All resources |
| `KAAS_TAG` | Identity & classification: BU, ESATS, environment, SLA, tier | All resources |
| `KAAS_EXT_TAG` | Contacts & operations: DL, charge line, DR, backup, data residency | All resources |
| `KAAS_INFRA_TAG` | Workload & network: persistence, storage type, ingress, network policy, scaling | App-scoped resources |

Tags are applied at provisioning time via Terraform and enforced by Azure Policy.

---

## Why Tags Matter

Tags are not just metadata — they are the foundation for compliance, financial governance, and operational excellence across the shared KaaS platform.

### Compliance & Security

| Use Case | How Tags Help | Which Tag |
|----------|--------------|-----------|
| **Audit trail** | Every resource is traceable to an owner, environment, and application | `ECS_CSF_TAG` → `SIS_RESP_ORG`, `SIS_ASSET_OWNER_BEMS_ID` |
| **Environment classification** | Resources are classified by environment (dev/stage/prod) for access control and policy enforcement | `ECS_CSF_TAG` → `SIS_ENVIRONMENT_ID`, `KAAS_TAG` → `env` |
| **Data classification** | Sensitive resources are identified and protected according to their classification level | `KAAS_TAG` → `classification` |
| **Regulatory reporting** | Generate compliance reports by filtering resources on org, environment, and classification | All tags combined |
| **Non-compliant detection** | Azure Policy flags any resource missing mandatory tags — prevents shadow resources | Policy enforcement on all tags |

### Finance & FinOps

| Use Case | How Tags Help | Which Tag |
|----------|--------------|-----------|
| **Cost attribution** | Every resource cost is attributed to a specific application via FinOps UUID | `KAAS_TAG` → `finops_uuid` |
| **Chargeback / showback** | Monthly invoices are generated per `finops_uuid` — teams pay for what they consume | `KAAS_TAG` → `finops_uuid`, `charge_line` |
| **Budget tracking** | Filter Cloud Health or Azure Cost Management by `mo`, `env`, or `esats_id` to track spend per BU or app | `KAAS_TAG` → `mo`, `esats_id`, `env` |
| **Cost anomaly detection** | Alert when a tagged namespace or app exceeds expected spend | `KAAS_TAG` → `finops_uuid`, `namespace` |
| **Tier-based SLA costing** | Different cost models for tier-1 vs tier-3 applications | `KAAS_TAG` → `tier` |

### Operations & Incident Management

| Use Case | How Tags Help | Which Tag |
|----------|--------------|-----------|
| **Incident routing** | When a resource alerts, the tag tells the system which team to page | `ECS_HPOO_TAG` → `HPOO_CAGASSIGNMENTGROUP` |
| **Contact lookup** | On-call engineers quickly identify who owns a resource and who to escalate to | `KAAS_TAG` → `dl`, `contact_primary`, `contact_secondary` |
| **Change management** | Associate infrastructure changes with the correct responsible manager | `ECS_HPOO_TAG` → `HPOO_SISRESPONSIBLEMANAGER` |
| **Blast radius assessment** | During an incident, filter all resources by `mo` or `namespace` to assess impact scope | `KAAS_TAG` → `mo`, `namespace`, `tier` |
| **Deployment traceability** | Know exactly how an app was deployed and where to look for issues | `KAAS_TAG` → `deploy_type`, `namespace`, `env` |

### Platform Engineering

| Use Case | How Tags Help | Which Tag |
|----------|--------------|-----------|
| **Resource inventory** | Query all resources for a BU, app, or environment in seconds | `KAAS_TAG` → `mo`, `esats_id`, `env` |
| **Lifecycle management** | Identify resources tied to decommissioned apps for cleanup | `KAAS_TAG` → `esats_id`, `namespace` |
| **Capacity planning** | Aggregate resource usage by tier and BU for forecasting | `KAAS_TAG` → `tier`, `mo` |
| **Multi-cluster governance** | Track which resources belong to which cluster and namespace across environments | `KAAS_TAG` → `namespace`, `env` |

### Summary: Tag → Consumer Mapping

```
+-------------------+---------------------------------------------------+
|  Consumer         |  Tags They Rely On                                |
+-------------------+---------------------------------------------------+
|  Compliance Team  |  ECS_CSF_TAG (owner, env, classification)         |
|  FinOps Team      |  KAAS_TAG (finops_uuid, charge_line, mo, tier)    |
|  Ops / SRE        |  ECS_HPOO_TAG (routing, manager) + KAAS_TAG (dl)  |
|  Security Team    |  ECS_CSF_TAG (env, ASE) + KAAS_TAG (classification)|
|  Platform Eng     |  KAAS_TAG (mo, esats_id, namespace, deploy_type)  |
|  App Team         |  KAAS_TAG (namespace, env, tier)                  |
+-------------------+---------------------------------------------------+
```

---

## Tag Categories

```
+------------------------------------------------------------------+
|  RESOURCE (e.g., AKS Cluster, ACR, Key Vault, Namespace)         |
+------------------------------------------------------------------+
|  ECS_CSF_TAG    → WHO owns it, WHO is responsible, WHAT env      |
|  ECS_HPOO_TAG   → WHO supports it, HOW to route incidents        |
|  KAAS_TAG       → WHAT app, WHICH BU, WHAT tier, WHAT SLA        |
|  KAAS_EXT_TAG   → WHO to contact, HOW to bill, DR/backup config  |
|  KAAS_INFRA_TAG → HOW deployed, WHAT storage, WHAT network       |
+------------------------------------------------------------------+
```

---

## ECS_CSF_TAG

> Compliance & Security Framework tag. Identifies asset ownership, responsible organisation,
> environment classification, and administrative contact.

**Format:** JSON string as tag value

```json
{
  "SIS_RESP_ORG": "ENT-STRATA-KAAS-EIC-AZ",
  "SIS_CONTACT_BEMS_ID": "2939955",
  "SIS_ASSET_OWNER_BEMS_ID": "3492862",
  "SIS_ENVIRONMENT_ID": "DEVELOPMENT",
  "SIS_ASE_ID": "strata-k8s-azure",
  "LAPIC_ADMIN_ACCOUNT": "naveenkumar.ranganathan@boeing.com"
}
```

| Field | Description | Values |
|-------|-------------|--------|
| `SIS_RESP_ORG` | Responsible organisation assignment group | `ENT-STRATA-KAAS-EIC-AZ` |
| `SIS_CONTACT_BEMS_ID` | BEMS ID of the primary contact | `2939955` |
| `SIS_ASSET_OWNER_BEMS_ID` | BEMS ID of the asset owner | `3492862` |
| `SIS_ENVIRONMENT_ID` | Environment classification | `DEVELOPMENT`, `STAGE`, `PRODUCTION`, `DR` |
| `SIS_ASE_ID` | Application Service Element identifier | `strata-k8s-azure` |
| `LAPIC_ADMIN_ACCOUNT` | LAPIC administrative account (email) | `naveenkumar.ranganathan@boeing.com` |

---

## ECS_HPOO_TAG

> Operations & Support tag. Routes incidents to the correct support group and identifies
> the requestor and vendor responsibility.

**Format:** JSON string as tag value

```json
{
  "HPOO_CAGASSIGNMENTGROUP": "ENT-STRATA-KAAS-EIC-AZ",
  "HPOO_REQUESTORBEMSID": "2939955",
  "HPOO_SISRESPONSIBLEMANAGER": "3492862",
  "HPOO_SISVENDORSUPPORT": "BOEING"
}
```

| Field | Description | Values |
|-------|-------------|--------|
| `HPOO_CAGASSIGNMENTGROUP` | CAG assignment group for incident routing | `ENT-STRATA-KAAS-EIC-AZ` |
| `HPOO_REQUESTORBEMSID` | BEMS ID of the requestor | `2939955` |
| `HPOO_SISRESPONSIBLEMANAGER` | BEMS ID of the responsible manager | `3492862` |
| `HPOO_SISVENDORSUPPORT` | Vendor support identifier | `BOEING` |

---

## KAAS_TAG

> Application & Platform Metadata tag. Carries KaaS-specific information for billing,
> namespace mapping, classification, and deployment method.

**Format:** JSON string as tag value (must be <= 256 characters)

```json
{
  "mo": "hr",
  "esats_id": "123456",
  "namespace": "ns-payment-service",
  "env": "dev",
  "finops_uuid": "LK09123",
  "classification": "confidential",
  "tier": "tier-1",
  "aec": "AEC-001",
  "charge_line": "cc-8843",
  "contact_primary": "john.doe@boeing.com",
  "contact_secondary": "jane.smith@boeing.com"
}
```

### KAAS_TAG (Primary) — Identity & Classification

> Core application identification and platform metadata. Always applied. Must be <= 256 characters.

**Format:** JSON string as tag value

```json
{"mo":"hr","esats_id":"123456","namespace":"ns-payment-svc","env":"dev","finops_uuid":"LK09123","classification":"confidential","tier":"tier-1"}
```

| # | Field | Key | Description | Required | Values / Examples |
|---|-------|-----|-------------|----------|-------------------|
| 1 | Maintaining Org | `mo` | Business Unit that owns the resource | **Required** | `hr`, `cs`, `fs`, `ps`, `cdp` |
| 2 | ESATS ID | `esats_id` | Enterprise application identifier | **Required** | `123456`, `234567` |
| 3 | Namespace | `namespace` | Kubernetes namespace for the workload | **Required** | `ns-payment-svc`, `ns-auth-api` |
| 4 | Environment | `env` | Deployment environment | **Required** | `dev`, `stage`, `prod`, `dr` |
| 5 | FinOps UUID | `finops_uuid` | Cost attribution identifier | **Required** | `LK09123`, `LK09456` |
| 6 | Classification | `classification` | Data classification level | **Required** | `confidential`, `internal`, `public` |
| 7 | Tier | `tier` | Application criticality tier | **Required** | `tier-1`, `tier-2`, `tier-3` |


> Estimated character count: ~160–200 characters (safely within 256 limit)

---

### KAAS_EXT_TAG (Extended) — Contacts & Operations

> Extended metadata for operational support, contacts, and billing details.
> Applied alongside KAAS_TAG. Must be <= 256 characters.
> Split into a separate tag to keep both within Azure's 256-character tag value limit.

**Format:** JSON string as tag value

```json
{"dl":"strata-hr@boeing.com","contact_primary":"john@boeing.com","contact_secondary":"jane@boeing.com","charge_line":"cc-8843","aec":"AEC-001","dr_enabled":"true","backup_policy":"daily","data_residency":"us-gov","response_sla":"4h"}
```

| # | Field | Key | Description | Required | Values / Examples |
|---|-------|-----|-------------|----------|-------------------|
| 1 | Distribution List | `dl` | Team distribution list (email) | **Required** | `strata-hr@boeing.com` |
| 2 | Primary Contact | `contact_primary` | Primary contact email | Optional | `john.doe@boeing.com` |
| 3 | Secondary Contact | `contact_secondary` | Secondary contact email | Optional | `jane.smith@boeing.com` |
| 4 | Charge Line | `charge_line` | Cost centre / charge line for billing | Optional | `cc-8843`, `cc-9012` |
| 5 | AEC | `aec` | Application Element Code | Optional | `AEC-001` |
| 6 | DR Enabled | `dr_enabled` | Whether disaster recovery is configured | Optional | `true`, `false` |
| 7 | Backup Policy | `backup_policy` | Backup frequency/retention policy | Optional | `daily`, `weekly`, `none` |
| 8 | Data Residency | `data_residency` | Data residency requirement | Optional | `us-gov`, `us-gov-az`, `any` |
| 9 | Response SLA | `response_sla` | Incident response time commitment | Optional | `1h`, `4h`, `8h`, `24h`, `best-effort` |

> Estimated character count: ~130–200 characters depending on field usage (within 256 limit)

---

### KAAS_INFRA_TAG (Infrastructure) — Workload & Network Characteristics

> Infrastructure-level metadata describing how the workload is deployed, scaled, and secured.
> Applied to app-scoped resources where platform engineering needs visibility into workload posture.
> Separate tag to avoid overloading KAAS_EXT_TAG and to keep infrastructure concerns isolated.

**Format:** JSON string as tag value (must be <= 256 characters)

```json
{"persistence":"stateful","storage_type":"disk","ingress":"internal","network_policy":"enabled","scaling":"hpa","replicas":"3","image_source":"platform","secrets_provider":"csi-kv","mesh_enabled":"false"}
```

| # | Field | Key | Description | Required | Values / Examples |
|---|-------|-----|-------------|----------|-------------------|
| 1 | Persistence | `persistence` | Whether the app requires persistent storage | **Required** | `stateful`, `stateless` |
| 2 | Storage Type | `storage_type` | Azure storage backend used | **Required** | `disk`, `blob`, `file`, `nfs`, `none` |
| 3 | Ingress | `ingress` | How the app is exposed | **Required** | `public`, `internal`, `none` |
| 4 | Network Policy | `network_policy` | Whether K8s network policies are enforced | **Required** | `enabled`, `disabled` |
| 5 | Scaling | `scaling` | Auto-scaling method | Optional | `hpa`, `keda`, `vpa`, `fixed` |
| 6 | Replicas | `replicas` | Baseline replica count | Optional | `1`, `2`, `3`, `5` |
| 7 | Image Source | `image_source` | Whether app uses platform base images or custom | Optional | `platform`, `custom`, `vendor` |
| 8 | Secrets Provider | `secrets_provider` | How secrets are injected into the workload | Optional | `csi-kv`, `external-secrets`, `env` |
| 9 | Service Mesh | `mesh_enabled` | Whether service mesh sidecar is enabled | Optional | `true`, `false` |

> Estimated character count: ~150–210 characters (within 256 limit)

---

### Tag Summary — All Five Tags 

| Tag Name | Concern | Unique Fields | Limit |
|----------|---------|---------------|-------|
| `ECS_CSF_TAG` | Compliance & Security Framework | SIS_RESP_ORG, SIS_CONTACT_BEMS_ID, SIS_ASSET_OWNER_BEMS_ID, SIS_ENVIRONMENT_ID, SIS_ASE_ID, LAPIC_ADMIN_ACCOUNT | <= 256 chars |
| `ECS_HPOO_TAG` | Operations & Incident Routing | HPOO_CAGASSIGNMENTGROUP, HPOO_REQUESTORBEMSID, HPOO_SISRESPONSIBLEMANAGER, HPOO_SISVENDORSUPPORT | <= 256 chars |
| `KAAS_TAG` | Identity & Classification | mo, esats_id, namespace, env, finops_uuid, classification, deploy_type, tier, sla | <= 256 chars |
| `KAAS_EXT_TAG` | Contacts & Operations | dl, contact_primary, contact_secondary, charge_line, aec, dr_enabled, backup_policy, data_residency, response_sla | <= 256 chars |
| `KAAS_INFRA_TAG` | Workload & Network | persistence, storage_type, ingress, network_policy, scaling, replicas, image_source, secrets_provider, mesh_enabled | <= 256 chars |

> **No field appears in more than one tag.** Each tag has a distinct, non-overlapping concern.

---

### Why Three KAAS Tags?

Azure enforces a **256-character limit per tag value**. Grouping all metadata into a single tag is impossible. Splitting by concern gives room for future fields and keeps each tag focused:

| Tag | Concern | Char Budget | Required On |
|-----|---------|-------------|-------------|
| `KAAS_TAG` | Identity & classification — *what is this resource* | <= 256 | All resources |
| `KAAS_EXT_TAG` | Contacts & operations — *who supports it and how* | <= 256 | All resources |
| `KAAS_INFRA_TAG` | Workload & network — *how is it deployed and secured* | <= 256 | App-scoped resources |

---

### Additional Tags to Consider (Future)

| Tag Key | Purpose | When to Add |
|---------|---------|-------------|
| `chargeline` | Direct charge line mapping for finance billing | If finance requires a dedicated charge line field beyond KAAS_EXT_TAG |
| `project_code` | Project tracking identifier | If PMO requires project-level tracking |
| `compliance_framework` | Which compliance framework applies (FedRAMP, ITAR, etc.) | If multi-framework environments exist |
| `maintenance_window` | Scheduled maintenance window | If auto-patching or upgrade scheduling is needed |
| `auto_shutdown` | Whether resource auto-shuts down in dev/stage | Cost savings in non-prod |
| `retention_days` | Log/data retention requirement in days | If retention varies per app |

> These can be added to `KAAS_EXT_TAG` as optional fields when the need arises.

---

## Tag Application Rules

| Rule | Description |
|------|-------------|
| Five tags are mandatory | Every resource must have `ECS_CSF_TAG`, `ECS_HPOO_TAG`, `KAAS_TAG`, `KAAS_EXT_TAG`, and `KAAS_INFRA_TAG` |
| Applied at provisioning time | Tags are set by Terraform during resource creation |
| Enforced by Azure Policy | Resources without mandatory tags are flagged as non-compliant |
| `SIS_ENVIRONMENT_ID` must match `env` | Both fields should reflect the same environment |
| Each tag value <= 256 characters | Azure limit — this is why KAAS is split into three tags |
| KAAS_TAG mandatory fields never empty | `mo`, `esats_id`, `namespace`, `env`, `finops_uuid`, `classification`, `deploy_type`, `tier`, `sla` |
| KAAS_EXT_TAG mandatory field | `dl` is always required; other fields are optional |
| KAAS_INFRA_TAG mandatory fields | `persistence`, `storage_type`, `ingress`, `network_policy` are always required |
| Platform resources use `cdp` as mo | Shared platform resources (ACR, core cluster) use `mo: cdp` |
| Platform resources use `cdp` as mo | Shared platform resources (ACR, core cluster) use `mo: cdp` |

---

## Examples

### Platform Resource (Core AKS Cluster)

```
Resource: kaas-cdp-prod-va-aks

ECS_CSF_TAG = {"SIS_RESP_ORG":"ENT-STRATA-KAAS-EIC-AZ","SIS_CONTACT_BEMS_ID":"2939955","SIS_ASSET_OWNER_BEMS_ID":"3492862","SIS_ENVIRONMENT_ID":"PRODUCTION","SIS_ASE_ID":"strata-k8s-azure","LAPIC_ADMIN_ACCOUNT":"naveenkumar.ranganathan@boeing.com"}

ECS_HPOO_TAG = {"HPOO_CAGASSIGNMENTGROUP":"ENT-STRATA-KAAS-EIC-AZ","HPOO_REQUESTORBEMSID":"2939955","HPOO_SISRESPONSIBLEMANAGER":"3492862","HPOO_SISVENDORSUPPORT":"BOEING"}

KAAS_TAG = {"mo":"cdp","esats_id":"3678542","namespace":"","env":"prod","finops_uuid":"","classification":"confidential","deploy_type":"argocd+helm","dl":"strata-platform@boeing.com","tier":"tier-1"}
```

### App Resource (HR Payment Service — Dev)

```
Resource: kaas-hr-dev-va-kv (Key Vault)

ECS_CSF_TAG = {"SIS_RESP_ORG":"ENT-STRATA-KAAS-EIC-AZ","SIS_CONTACT_BEMS_ID":"2939955","SIS_ASSET_OWNER_BEMS_ID":"3492862","SIS_ENVIRONMENT_ID":"DEVELOPMENT","SIS_ASE_ID":"strata-k8s-azure","LAPIC_ADMIN_ACCOUNT":"naveenkumar.ranganathan@boeing.com"}

ECS_HPOO_TAG = {"HPOO_CAGASSIGNMENTGROUP":"ENT-STRATA-KAAS-EIC-AZ","HPOO_REQUESTORBEMSID":"2939955","HPOO_SISRESPONSIBLEMANAGER":"3492862","HPOO_SISVENDORSUPPORT":"BOEING"}

KAAS_TAG = {"mo":"hr","esats_id":"123456","namespace":"ns-payment-service","env":"dev","finops_uuid":"LK09123","classification":"confidential","deploy_type":"argocd+helm","dl":"strata-hr@boeing.com","tier":"tier-1","charge_line":"cc-8843","contact_primary":"john@boeing.com"}
```

### Terraform Usage

```hcl
locals {
  ecs_csf_tag = jsonencode({
    SIS_RESP_ORG             = "ENT-STRATA-KAAS-EIC-AZ"
    SIS_CONTACT_BEMS_ID      = "2939955"
    SIS_ASSET_OWNER_BEMS_ID  = "3492862"
    SIS_ENVIRONMENT_ID       = upper(var.environment)
    SIS_ASE_ID               = "strata-k8s-azure"
    LAPIC_ADMIN_ACCOUNT      = "naveenkumar.ranganathan@boeing.com"
  })

  ecs_hpoo_tag = jsonencode({
    HPOO_CAGASSIGNMENTGROUP    = "ENT-STRATA-KAAS-EIC-AZ"
    HPOO_REQUESTORBEMSID       = "2939955"
    HPOO_SISRESPONSIBLEMANAGER = "3492862"
    HPOO_SISVENDORSUPPORT      = "BOEING"
  })

  kaas_tag = jsonencode({
    mo             = var.maintain_org
    esats_id       = var.esats_id
    namespace      = var.namespace
    env            = var.environment
    finops_uuid    = var.finops_uuid
    classification = var.classification
    deploy_type    = var.deployment_type
    dl             = var.distribution_list
    tier           = var.tier
    # Optional fields — include when available
    # aec               = var.aec
    # charge_line       = var.charge_line
    # contact_primary   = var.primary_contact
    # contact_secondary = var.secondary_contact
  })
}

resource "azurerm_resource_....." "main" {
  .....

  tags = {
    ECS_CSF_TAG  = local.ecs_csf_tag
    ECS_HPOO_TAG = local.ecs_hpoo_tag
    KAAS_TAG     = local.kaas_tag
  }
}
```

---

## Related Documentation

- [Azure Naming Standards](../azure_naming_standards/azure_naming_standards.md)
- [FinOps Shared Billing Model](../finops/finops_sharedbilling_model.md)
- [App Onboarding Tracker](../repo-model/app_onboarding_tracker.md)