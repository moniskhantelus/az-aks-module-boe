[![information](https://img.shields.io/badge/information-boeing%20proprietary-blue.svg?style=flat)](https://besweb.web.boeing.com/Information%20Protection/InfoTypes)
[![export](https://img.shields.io/badge/export-earn-00c900.svg?style=flat)](http://globaltradecontrols.web.boeing.com/policyguidance/emip.html#earn)
[![release](https://img.shields.io/badge/release-private%20preview-red.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md#private-preview)
[![esats](https://img.shields.io/badge/esats-3678542-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/MATURITY.md)
[![version](https://img.shields.io/badge/version-26.06-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/governance/contribution/-/blob/main/CONTRIBUTION.md#service-catalog-version-guidance)
[![guidance](https://img.shields.io/badge/guidance-standards-blue.svg?style=flat)](https://git.web.boeing.com/ECS-Catalog/guidance/terraform/-/blob/main/README.md)


# 👤 Platform Engineer (Kubernetes Administrator) Persona

## Overview

The KPlatform Engineer (Kubernetes Administrator) is the platform operator responsible for provisioning, configuring, and maintaining the cluster infrastructure. They ensure the platform is secure, scalable, and available , so application teams can focus purely on shipping features.

---

## Profile

| Attribute | Description |
|-----------|-------------|
| **Role** | Platform Engineer (Kubernetes Administrator) |
| **Team** | Platform / Infrastructure team |
| **Goal** | Provide a reliable, secure, self-service Kubernetes platform |


---

## Responsibilities

| Area | What They Do |
|------|--------------|
| Cluster Provisioning | Create and configure AKS/EKS clusters via Terraform |
| Node Pool Management | Scale, upgrade, and maintain node pools |
| Namespace Management | Create and assign namespaces per team/application |
| Container Registry (ACR) | Set up registries, manage access policies, configure replication |
| Key Vault | Configure secrets management, rotation policies, access |
| Networking | Manage VNets, subnets, DNS zones, ingress controllers, network policies |
| RBAC | Define cluster roles, bind to Azure AD groups, enforce least privilege |
| Upgrades | Plan and execute Kubernetes version upgrades |
| Monitoring | Deploy and maintain cluster-level observability stack |
| Disaster Recovery | Backup configurations, test recovery procedures |

---

## Infrastructure Ownership

```
┌───────────────────────────────────────────────────────────┐
│                 K8s Admin Responsibility                  │
├───────────────────────────────────────────────────────────┤
│                                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │ AKS Cluster │  │ Node Pools  │  │ Namespaces  │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │     ACR     │  │  Key Vault  │  │ Networking  │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │    RBAC     │  │  Ingress    │  │  DNS Zones  │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                           │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐        │
│  │Log Analytics│  │  Defender   │  │  Policies   │        │
│  └─────────────┘  └─────────────┘  └─────────────┘        │
│                                                           │
└───────────────────────────────────────────────────────────┘
```

---

## Access Permissions

| Resource | Access Level |
|----------|-------------|
| AKS clusters (all environments) | ✅ Full admin (cluster-admin) |
| Terraform / infrastructure repos | ✅ Read / Write |
| Azure Portal (AKS, Networking, IAM) | ✅ Full access |
| Node SSH (break-glass) | ✅ Emergency only, audited |
| Container registry (ACR) | ✅ Admin (manage repos, access policies) |
| Key Vault | ✅ Admin (manage policies, not read prod secrets) |
| Azure AD Groups (RBAC) | ✅ Manage group memberships |
| Application CD pipelines | ✅ Full access |
| Production deployments | ❌ Application deployment is developer-owned |

---

## Tooling

| Tool | Purpose |
|------|---------|
| Terraform | Infrastructure provisioning (clusters, networking, ACR, Key Vault) |
| kubectl | Cluster administration (cluster-admin context) |
| Azure CLI | Azure resource management |
| Helm* | Deploy platform components (ingress, cert-manager, monitoring) |
| ArgoCD* | Manage platform-level GitOps deployments |
| GitLab CI | Infrastructure pipelines |
| Azure Monitor / Log Analytics | Cluster health and diagnostics |
| Microsoft Defender* | Security posture management |

---

## Day-to-Day Operations

| Task | Frequency |
|------|-----------|
| Review cluster health dashboards | Daily |
| Respond to node scaling alerts | As needed |
| Process namespace requests | Within X business day |
| Apply Kubernetes upgrades | Monthly (maintenance window) |
| Rotate certificates and secrets | Quarterly/as per the app request |
| Review and update RBAC assignments | Monthly |
| Run disaster recovery drills | Quarterly |
| Audit node pool configurations | Monthly |

---

## Provisioning Workflow

```
TO-DO
```

---

## What K8s Admin Does NOT Do

| Concern | Owned By |
|---------|----------|
| Write application code | Application Developer |
| Build container images | Application Developer |
| Deploy applications (Helm) | Application Developer with help of K8S admin |
| Define security policies | Security Persona (with K8s Admin implementing) |

---

## Key Metrics

| Metric | Target |
|--------|--------|
| Cluster uptime | 99.9%+ |