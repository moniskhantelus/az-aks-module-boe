# 👤 Security Persona (SecOps)

## Overview

The Security persona ensures the KaaS platform and all deployed workloads meet Aerospace and Defense compliance requirements. They define constraints, audit configurations, and respond to security events without blocking developer velocity.

---

## Profile

| Attribute | Description |
|-----------|-------------|
| **Role** | Security Engineer / SecOps |
| **Team** | Security and Compliance |
| **Goal** | Maintain security posture without impeding delivery |


---

## Responsibilities

| Area | What They Do |
|------|--------------|
| Policy Definition | Define security policies enforced via Azure Policy and OPA/Gatekeeper |
| Vulnerability Management | Monitor and triage CVEs across container images and dependencies |
| Compliance Auditing | Verify STIG compliance, generate audit reports |
| Incident Response | Investigate and respond to security alerts (Microsoft Defender) |
| Access Reviews | Periodic review of RBAC assignments and privilege escalation |
| Secret Management | Define rotation policies and audit Key Vault access |
| Network Security | Review and approve network policies and ingress rules |

---

## Security Controls Enforced

### Cluster Level

| Control | Implementation |
|---------|---------------|
| Node compliance | CIS benchmarks applied to node configuration |
| Private cluster | API server not publicly accessible |
| Network policies | Default deny; explicit allow per namespace |
| Pod security | Pod Security Standards enforced (restricted) |
| Image  | Only scaned images from trusted registries |
| Audit logging | All API server actions logged to Log Analytics |
| Defender for Containers | Runtime threat detection enabled |

### Pipeline Level (Gate Checks)

| Gate | Tool | Blocks Deployment |
|------|------|-------------------|
| SAST (Static Analysis) | SonarQube / Semgrep | Yes — critical findings |
| DAST (Dynamic Analysis) | OWASP ZAP | Yes — high/critical findings |
| Container image scan | Prisma / Azure Defender | Yes — critical CVEs |
| Secret detection | GitLeaks | Yes — any secrets found |
| License compliance | License Finder | Warning — review required |
| IaC scan | Checkov / tfsec | Yes — high severity |

### Runtime Level

| Control | Implementation |
|---------|---------------|
| Resource limits | Enforced per namespace (Strata AI guardrails) |
| No privileged containers | OPA policy rejects privileged pods |
| Read-only root filesystem | Enforced via pod security policy |
| No host networking | Blocked by admission controller |
| Secret encryption at rest | Azure Key Vault  |

---

## Access Permissions

| Resource | Access Level |
|----------|-------------|
| Security dashboards (Defender, Sentinel) | ✅ Full access |
| Audit logs (Log Analytics) | ✅ Full access |
| Azure Policy assignments | ✅ Read / Write |
| OPA/Gatekeeper policies | ✅ Read / Write |
| Cluster RBAC definitions | ✅ Read / Approve changes |
| Container registry (scan results) | ✅ Read |
| Application source code | Read only (for security review) |
| Production cluster | Read only (audit, not operate) |
| Key Vault (audit) | ✅ Audit access, no secret read |
| Infrastructure Terraform | ✅ Review / Approve MRs |

---

## Compliance Frameworks

| Framework | Scope |
|-----------|-------|
| DISA STIGs | Kubernetes, OS, and network hardening |
| CIS Benchmarks | Kubernetes and Azure baseline configurations |


---

## Security Review Workflow

```
Developer submits MR
         │
         ▼
  CI Gate Checks run
  (SAST, DAST, Image Scan)
         │
         ├── All pass ──▶ Proceeds to review
         │
         └── Critical finding ──▶ MR blocked
                                      │
                                      ▼
                              Team notified
                              Developer remediates
```

---


---

## Tooling 

| Tool | Purpose |
|------|---------|
| Microsoft Defender for Containers | Runtime threat detection |
| Azure Sentinel* | SIEM, log correlation, alerting |
| Azure Policy* | Cloud-level policy enforcement |
| OPA / Gatekeeper* | Kubernetes admission control |
| Prisma | Container image vulnerability scanning |
| GitLeaks | Secret detection in repositories |
| Checkov / tfsec* | Infrastructure-as-code scanning |
| Azure Key Vault | Secrets management and rotation |

* yet confirm the tools 
