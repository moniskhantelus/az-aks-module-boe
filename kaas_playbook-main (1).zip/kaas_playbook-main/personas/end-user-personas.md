# 👤 End-User / Business User Persona

## Overview

End users consume applications deployed on the KaaS platform. They interact with published services through web browsers, APIs with no awareness of the underlying Kubernetes infrastructure.

---

## Profile

| Attribute | Description |
|-----------|-------------|
| **Role** | Business User / End User |
| **Team** | Business units, external customers, mission operators |
| **Goal** | Access reliable, performant applications to accomplish their work |

---

## Responsibilities

| Area | What They Do |
|------|--------------|
| Application Usage | Access and use published applications |
| Feedback | Report bugs, request features through standard channels |
| Data Entry | Input and manage business data through application UIs |
| Compliance | Follow access policies and acceptable use guidelines |

---

## Interaction Model

```
┌──────────────────┐          ┌───────────────────┐         ┌──────────────────┐
│   End User       │          │   Ingress /       │         │   Application    │
│                  │──HTTPS──▶│   Load Balancer   │────────▶│   (Pods on K8s)  │
│  - Browser       │          │                   │         │                  │
│  - API Client    │          │  - TLS Termination│         │  - API Endpoints │
│                  │          │  - Auth Gateway   │         │  - Web UI        │
└──────────────────┘          └───────────────────┘         └──────────────────┘
```

---

## Access Permissions

| Resource | Access Level |
|----------|-------------|
| Published application URLs | ✅ Full access (authenticated) |
| Application dashboards and UIs | ✅ Based on role |
| API endpoints | ✅ With valid credentials/tokens |
| Kubernetes cluster | ❌ No access |
| Container registry | ❌ No access |
| CI/CD pipelines | ❌ No access |
| kubectl | ❌ No access |
| Azure Portal | ❌ No access |
| Source code repositories | ❌ No access |

---

## What They Experience

| Aspect | Expectation |
|--------|-------------|
| Availability | 99.9%+ uptime for mission-critical applications |
| Security | WSSO authentication, MFA where required |
| Updates | Zero-downtime deployments (rolling updates) |


---

## Authentication Flow

```
End User ──▶ WSSO ──▶ Application Gateway ──▶ Application
                │
                ├── MFA (if required by policy)
                └── Role assignment (RBAC at app level)
```

---
