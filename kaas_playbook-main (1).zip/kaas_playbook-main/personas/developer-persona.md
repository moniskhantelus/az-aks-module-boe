# 👤 Developer Persona

## Overview

The Application Developer builds, packages, and deploys containerized applications to the KaaS platform. They focus exclusively on application logic and delivery , without needing direct access to cluster infrastructure.

---

## Profile

| Attribute | Description |
|-----------|-------------|
| **Role** | Application Developer |
| **Team** | Product / Feature teams |
| **Goal** | Ship application features quickly and safely |

---

## Responsibilities

| Area | What They Do |
|------|--------------|
| Application Code | Write, test, and maintain application source code |
| Containerization | Build container images using Dockerfiles |
| CI Pipeline | Configure builds, run tests, pass gate checks |
| CD Pipeline | Deploy applications via Helm charts |
| Observability | Add application-level logging, metrics, and health checks |
| Documentation | Maintain API docs, README, and runbooks |

---

## Workflow

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│  Write   │───▶│  Build   │───▶│  Gate    │───▶│  Push    │───▶│  Deploy* │
│  Code    │    │  & Test  │    │  Checks  │    │  to ACR* │    │  (Helm)  │
└──────────┘    └──────────┘    └──────────┘    └──────────┘    └──────────┘
     │                               │                               │
     │                    ┌──────────┴──────────┐                    │
     │                    │  - SAST Scan        │                    │
     │                    │  - Lint Check       │                    │
     │                    │  - Image Scan       │                    │
     │                    └─────────────────────┘                    │
     │                                                               │
     └─── Commit with [JIRA-ID]: type(scope): subject ───────────────┘
```

---

## Access Permissions

| Resource | Access Level |
|----------|-------------|
| Application source repos | Read / Write |
| CI/CD pipeline configs | Read / Write* |
| Application CI pipelines | ✅ developer access |
| Helm chart repos* | Read / Write |
| Application CD pipelines | ✅ developer access |
| Production deployments | ❌ Application deploym |
| Container registry (ACR) | Push (after gate checks pass) |
| Kubernetes namespace (own team) | View logs, deployments; deploy via Helm |
| Kubernetes namespace  | ❌ No access |
| Cluster-level resources | ❌ No access |
| Node SSH | ❌ No access |
| Terraform / infrastructure repos | Read only |
| Azure Portal | ❌ No access Limited (own resource group) |
| ACR / KeyVault Resources  |  Limited access on the specified apps,  ❌ No Azure Portal access |

---

## Tooling

| Tool | Purpose |
|------|---------|
| GitLab | Source control, CI/CD pipelines, merge requests |
| Docker / Buildah | Container image builds |
| Helm CLI | Package and deploy to Kubernetes |
| kubectl* | Namespace-scoped: view pods, logs, exec into containers |
| ArgoCD (UI)* | Monitor deployment sync status |
| Azure Container Registry | Store and pull container images |

---

## What the Platform Provides (So Developers Don't Have To)

| Concern | Handled By |
|---------|------------|
| Cluster provisioning | K8s Admin / Terraform |
| Node scaling | K8s Admin / Autoscaler |
| Network policies | Platform team |
| Ingress / TLS | Platform team |
| Secret injection | External Secrets Operator + Key Vault |
| Security hardening (STIGs) | Platform team |
| Monitoring infrastructure | Platform team |
| Resource guardrails | Strata AI |

---