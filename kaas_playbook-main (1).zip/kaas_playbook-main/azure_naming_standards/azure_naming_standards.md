
# Azure AKS Resource Naming Standards


## Overview

This document defines the naming conventions for all Azure resources related to AKS clusters in the KaaS platform. Consistent naming ensures discoverability, automation compatibility, and clear ownership across environments and applications.

---

## General Naming Format

```
<platform>-<maintain-org>-<env>-<purpose>-<region>-<resource-type>
```

| Segment | Description | Required | Values |
|---------|-------------|----------|--------|
| `<platform>` | Platform prefix | **Always** | `kaas` |
| `<maintain-org>` | Business organisation / department | **Always** | `iao`, `hr`, `cs`, `fs`, `cdp`, `ops` |
| `<env>` | Environment | **Always** | `dev`, `stage`, `prod`, `dr` |
| `<purpose>` | Workload, function, or app name | When applicable | `core`, `platform`, `appa`, `appb`, `01`, `02` |
| `<region>` | Azure region abbreviation | **Always** | `va` (Virginia), `az` (Arizona) |
| `<resource-type>` | Resource type suffix | **Always** | `rg`, `aks`, `acr`, `kv`, `mi`, `sp`, `law` |

### Key Segments

| Segment | Example | Notes |
|---------|---------|-------|
| `platform` | `kaas` | Fixed — never changes |
| `maintain-org` | `iao` | The team/org responsible for the resource lifecycle |
| `env` | `dev` | Maps to subscription boundary (dev, stage, prod, dr) |
| `purpose` | `core` | Omit if the resource is general-purpose for the org (e.g., RG) |
| `region` | `va` | `va` = USGov Virginia, `az` = USGov Arizona |
| `resource-type` | `mi` | Azure resource type abbreviation |

### Rules

- All lowercase
- Hyphen-separated (except where Azure prohibits hyphens, e.g., ACR, Storage Account)
- `<purpose>` is omitted when the resource scope is clear from org + env alone
- Max length varies by resource — see [Azure Resource Length Limits](#azure-resource-length-limits)
- No special characters beyond hyphens
- Environment and region always included
- ESATS ID is applied via resource tags (not in the resource name for infra resources)

---

## Resource Naming by Type

### Resource Groups

**Format:** `<platform>-<maintain-org>-<env>-<region>-rg`

| Resource Group | Maintain Org | Env | Purpose |
|----------------|--------------|-----|---------|
| `kaas-iao-dev-va-rg` | IAO | Dev | Platform infrastructure resources (dev) |
| `kaas-iao-stage-va-rg` | IAO | Stage | Platform infrastructure resources (stage) |
| `kaas-iao-prod-va-rg` | IAO | Prod | Platform infrastructure resources (prod) |
| `kaas-cdp-dev-va-rg` | CDP | Dev | Core platform cluster resources (dev) |
| `kaas-hr-prod-va-rg` | HR | Prod | HR org cluster resources (prod) |
| `kaas-cs-prod-va-rg` | CS | Prod | CS org cluster resources (prod) |

**AKS-managed node resource group:**

```
MC_<resource-group-name>_<cluster-name>_<region>
```

Example: `MC_kaas-iao-dev-va-rg_kaas-cdp-dev-va-aks_usgovvirginia`

---

### Managed Identity

**Format:** `<platform>-<maintain-org>-<env>-<purpose>-<region>-mi`

| Identity Name | Maintain Org | Env | Purpose |
|---------------|--------------|-----|---------|
| `kaas-iao-dev-core-va-mi` | IAO | Dev | Core cluster identity (dev) |
| `kaas-iao-prod-core-va-mi` | IAO | Prod | Core cluster identity (prod) |
| `kaas-iao-dev-cs-va-mi` | IAO | Dev | CS cluster identity (dev) |
| `kaas-iao-prod-hr-va-mi` | IAO | Prod | HR cluster identity (prod) |
| `kaas-hr-dev-appa-va-mi` | HR | Dev | App A workload identity (dev) |
| `kaas-cs-prod-appb-va-mi` | CS | Prod | App B workload identity (prod) |

---

### Service Principal

**Format:** `<platform>-<maintain-org>-<env>-<index>-sp`

| Service Principal | Maintain Org | Env | Purpose |
|-------------------|--------------|-----|---------|
| `kaas-iao-dev-01-sp` | IAO | Dev | Primary CI/CD pipeline SP (dev) |
| `kaas-iao-prod-01-sp` | IAO | Prod | Primary CI/CD pipeline SP (prod) |
| `kaas-iao-dev-02-sp` | IAO | Dev | Secondary/backup SP (dev) |

> Index (`01`, `02`) allows multiple SPs per environment for separation of duties (e.g., infra vs app pipelines).

---

### AKS Clusters

**Format:** `<platform>-<maintain-org>-<env>-<region>-aks`

| Cluster Name | Maintain Org | Environment | Purpose |
|--------------|--------------|-------------|---------|
| `kaas-cdp-dev-va-aks` | CDP | Dev | Core platform cluster (dev) |
| `kaas-cdp-stage-va-aks` | CDP | Stage | Core platform cluster (stage) |
| `kaas-cdp-prod-va-aks` | CDP | Prod | Core platform cluster (prod) — hosts ArgoCD, monitoring, ingress |
| `kaas-cs-prod-va-aks` | CS | Prod | CS org workload cluster (prod) |
| `kaas-hr-prod-va-aks` | HR | Prod | HR org workload cluster (prod) |
| `kaas-fs-prod-va-aks` | FS | Prod | FS org workload cluster (prod) |

---

### Node Pools

**Format:** `<app><type><index>` (max 12 characters, no hyphens)

| Node Pool Name | Application | OS | Purpose |
|----------------|-------------|-----|---------|
| `syspool1` | Platform | Linux | System pods (CoreDNS, metrics) |
| `appalin1` | App A | Linux | App A workloads |
| `appblin1` | App B | Linux | App B workloads |
| `appclin1` | App C | Linux | App C workloads |
| `appawin1` | App A | Windows | App A Windows workloads |

**Naming breakdown:**

| Segment | Length | Description |
|---------|--------|-------------|
| `<app>` | 4 chars | Application shortcode (`appa`, `appb`, `sys`) |
| `<type>` | 3 chars | OS type (`lin` = Linux, `win` = Windows) |
| `<index>` | 1 char | Pool index number |

---

### Namespaces

**Format:** `<maintain-org>-<esatsid>-<app>-<component>`

| Segment | Description | Examples |
|---------|-------------|----------|
| `<maintain-org>` | Business organization / department that maintains the resource | `hr`, `cs`, `fin`, `eng`, `ops` |
| `<esatsid>` | ESATS ID for the application | `12345`, `67890` |
| `<app>` | Application name | `appa`, `appb`, `appc` |
| `<component>` | Application component | `api`, `web`, `worker` |


| Namespace | Maintain Org | ESATS ID | Purpose |
|-----------|--------------|----------|---------|
| `hr-12345-appa-api` | HR | 12345 | App A API microservices |
| `hr-12345-appa-web` | HR | 12345 | App A Web frontend |
| `hr-12345-appa-worker` | HR | 12345 | App A Background workers |
| `cs-67890-appb-api` | CS | 67890 | App B API services |
| `cs-67890-appb-web` | CS | 67890 | App B Web frontend |
| `cdp-ingress` | CDP | Platform | Ingress controllers |
| `cdp-monitoring` | CDP | Platform | Prometheus, Grafana |
| `cdp-security` | CDP | Platform | OPA, Falco, cert-manager |

**Rules:**
- Maintain org prefix identifies which business unit owns the namespace
- ESATS ID ensures traceability and cost attribution
- One namespace per application component
- Never deploy multiple applications in the same namespace
- System namespaces (`kube-system`, `kube-public`) are reserved

---

### Azure Container Registry (ACR)

**Format:** `<platform><maintain-org><esatsid><env><region>acr` (no hyphens — Azure restriction)

| ACR Name | ESATS ID | Maintain Org | Environment | Purpose |
|----------|----------|--------------|-------------|---------|
| `kaascdp00001devvaacr` | 00001 | CDP | Dev | Development images |
| `kaascdp00001stagevaacr` | 00001 | CDP | Stage | Pre-production (stage) images |
| `kaascdp00001prodvaacr` | 00001 | CDP | Prod | Production images |

**Max length:** 50 characters, alphanumeric only.

---

### ACR Repository (Individual App Repos)

**Format:** `<platform>/<esatsid>/<app>/<component>`

| Repository Path | Application | ESATS ID | Description |
|-----------------|-------------|----------|-------------|
| `kaas/12345/appa/api` | App A | 12345 | API service image |
| `kaas/12345/appa/web` | App A | 12345 | Web frontend image |
| `kaas/12345/appa/worker` | App A | 12345 | Background worker image |
| `kaas/67890/appb/api` | App B | 67890 | API service image |
| `kaas/67890/appb/web` | App B | 67890 | Web frontend image |
| `kaas/11223/appc/api` | App C | 11223 | API service image |
| `kaas/11223/appc/processor` | App C | 11223 | Data processor image |
| `kaas/00001/platform/ingress-controller` | Platform | 00001 | NGINX ingress image |
| `kaas/00001/platform/cert-manager` | Platform | 00001 | Certificate manager image |

**Full image reference:**

```
kaascdp00001prodvaacr.azurecr.us/kaas/12345/appa/api:26.06
kaascdp00001devvaacr.azurecr.us/kaas/67890/appb/web:a1b2c3d
```

**Tagging within repos:**

| Tag | Purpose |
|-----|---------|
| `<commit-sha>` | CI build artifact |
| `YY.MM` | Production release (CalVer) |
| `YY.MM.patch` | Hotfix release |

* never use the latest for the docker images 
---

### Key Vault

**Format:** `<maintain-org>-<esatsid>-<env>-kv`

> Max length: 24 characters. If name exceeds limit, shorten to: `<org>-<esatsid>-<env>-kv`

| Key Vault Name | ESATS ID | Maintain Org | Environment | Scope |
|----------------|----------|--------------|-------------|-------|
| `cdp-00001-dev-kv` | 00001 | CDP | Dev | Platform-level secrets |
| `cdp-00001-stage-kv` | 00001 | CDP | Stage | Platform secrets |
| `cdp-00001-prod-kv` | 00001 | CDP | Prod | Platform secrets |
| `hr-12345-dev-kv` | 12345 | HR | Dev | App A secrets |
| `hr-12345-prod-kv` | 12345 | HR | Prod | App A secrets |
| `cs-67890-dev-kv` | 67890 | CS | Dev | App B secrets |
| `fin-11223-prod-kv` | 11223 | FIN | Prod | App C secrets |

**Max length:** 24 characters. If name exceeds limit, use shortened format: `<esatsid>-<app>-<env>-kv`


**Secret naming inside Key Vault:**

```
<org>-<esatsid>-<app>-<component>-<secret-name>
```

| Secret Name | ESATS ID | Description |
|-------------|----------|-------------|
| `12345-appa-api-db-connection` | 12345 | App A API database connection string |
| `12345-appa-api-jwt-secret` | 12345 | App A JWT signing key |
| `67890-appb-web-oauth-client-id` | 67890 | App B OAuth client ID |
| `00001-platform-ingress-tls-cert` | 00001 | Platform TLS certificate |

---


### Log Analytics Workspace

**Format:** `<platform>-<maintain-org>-<esatsid>-<env>-<region>-law`

| Workspace Name | ESATS ID | Maintain Org | Environment | Purpose |
|----------------|----------|--------------|-------------|---------|
| `kaas-cdp-00001-dev-va-law` | 00001 | CDP | Dev | Cluster and app logs |
| `kaas-cdp-00001-stage-va-law` | 00001 | CDP | Stage | Pre-production (stage) diagnostics |
| `kaas-cdp-00001-prod-va-law` | 00001 | CDP | Prod | Production monitoring and alerting |

---

### Managed Identities

> See updated format in the [Managed Identity](#managed-identity) section above.

---

### Service Principals

> See updated format in the [Service Principal](#service-principal) section above.

---

### Network Resources

| Resource | Naming Format | Example |
|----------|---------------|---------|
| VNet | `vnet-<team>-<maintain-org>-<env>-<region>` | `vnet-kaas-cdp-dev-va` |
| Subnet | `kaas_subnet_<index>` | `kaas_subnet_1` |
| Subnet (additional) | `kaas_subnet_<index>` (incremental) | `kaas_subnet_2`, `kaas_subnet_3` |
| Route Table | `rt-kaas_subnet_<index>` (prefixed with `rt-` matching the subnet) | `rt-kaas_subnet_1` |
| NSG | `nsg-<team>-<maintain-org>-<env>-<region>` | `nsg-kaas-cdp-dev-va` |
| Private DNS Zone | Azure standard | `privatelink.usgovvirginia.cx.aks.containerservice.azure.us` |

**Subnet naming rules:**
- Use underscore-separated format: `kaas_subnet_<index>`
- Start with `_1` and increment for each additional subnet (`_2`, `_3`, etc.)
- Each subnet gets a corresponding route table prefixed with `rt-`

**Examples:**

| Subnet | Route Table | Purpose |
|--------|-------------|---------|
| `kaas_subnet_1` | `rt-kaas_subnet_1` | AKS node subnet |
| `kaas_subnet_2` | `rt-kaas_subnet_2` | Private endpoint subnet |
| `kaas_subnet_3` | `rt-kaas_subnet_3` | Ingress / load balancer subnet |
| `kaas_subnet_4` | `rt-kaas_subnet_4` | API server VNet integration subnet |

---

### Pods & Deployments (Kubernetes)

**Format:** `<esatsid>-<app>-<component>-<type>`

| Resource | Naming | Example |
|----------|--------|---------|
| Deployment | `<esatsid>-<app>-<component>` | `12345-appa-api`, `67890-appb-web` |
| Pod (auto) | `<deployment>-<replicaset-hash>-<pod-hash>` | `12345-appa-api-7d8f9-x4k2m` |
| Service | `<esatsid>-<app>-<component>-svc` | `12345-appa-api-svc` |
| Ingress | `<esatsid>-<app>-<component>-ingress` | `12345-appa-web-ingress` |
| ConfigMap | `<esatsid>-<app>-<component>-config` | `12345-appa-api-config` |
| Secret | `<esatsid>-<app>-<component>-secret` | `12345-appa-api-secret` |
| HPA | `<esatsid>-<app>-<component>-hpa` | `12345-appa-api-hpa` |

---

## Complete Example: App A (ESATS: 12345, Maintain Org: HR) across Environments

| Resource | Dev | Prod |
|----------|-----|------|
| Resource Group | `kaas-hr-dev-va-rg` | `kaas-hr-prod-va-rg` |
| AKS Cluster | `kaas-cdp-dev-va-aks` (shared) | `kaas-cdp-prod-va-aks` (shared) |
| Node Pool | `appalin1` | `appalin1` |
| Namespace | `hr-12345-appa-api` | `hr-12345-appa-api` |
| ACR Repo | `kaascdp00001devvaacr/kaas/12345/appa/api` | `kaascdp00001prodvaacr/kaas/12345/appa/api` |
| Key Vault | `kaas-hr-12345-appa-dev-va-kv` | `kaas-hr-12345-appa-prod-va-kv` |
| Log Analytics | `kaas-cdp-00001-dev-va-law` (shared) | `kaas-cdp-00001-prod-va-law` (shared) |
| Managed Identity | `kaas-hr-dev-appa-va-mi` | `kaas-hr-prod-appa-va-mi` |
| Deployment | `12345-appa-api` | `12345-appa-api` |
| Service | `12345-appa-api-svc` | `12345-appa-api-svc` |
| Ingress | `12345-appa-web-ingress` | `12345-appa-web-ingress` |
| VNet | `vnet-kaas-cdp-dev-va` (shared) | `vnet-kaas-cdp-prod-va` (shared) |
| Subnet | `kaas_subnet_1` (shared) | `kaas_subnet_1` (shared) |
| Route Table | `rt-kaas_subnet_1` | `rt-kaas_subnet_1` |
| NSG | `nsg-kaas-cdp-dev-va` | `nsg-kaas-cdp-prod-va` |

---

## Azure Resource Length Limits

| Resource | Max Length | Allowed Characters |
|----------|-----------|-------------------|
| Resource Group | 90 | Alphanumeric, hyphens, underscores, periods |
| AKS Cluster | 63 | Alphanumeric, hyphens |
| Node Pool | 12 | Lowercase alphanumeric |
| ACR Name | 50 | Alphanumeric only (no hyphens) |
| Key Vault | 24 | Alphanumeric, hyphens |
| Log Analytics | 63 | Alphanumeric, hyphens |
| Managed Identity | 128 | Alphanumeric, hyphens, underscores |
| K8s Namespace | 63 | Lowercase alphanumeric, hyphens |

---


## Quick Reference Card

| Resource | Format | Sample | Max Length | Allowed Characters |
|----------|--------|--------|-----------|-------------------|
| Resource Group | `kaas-<org>-<env>-<region>-rg` | `kaas-iao-dev-va-rg` | 90 | Alphanumeric, hyphens, underscores, periods |
| AKS Cluster | `kaas-<org>-<env>-<region>-aks` | `kaas-cdp-prod-va-aks` | 63 | Alphanumeric, hyphens |
| Node Pool | `<app><os><index>` | `appalin1` | 12 | Lowercase alphanumeric only |
| Namespace | `<org>-<esatsid>-<app>-<component>` | `hr-12345-appa-api` | 63 | Lowercase alphanumeric, hyphens |
| ACR | `kaas<org><esatsid><env><region>acr` | `kaascdp00001prodvaacr` | 50 | Alphanumeric only (no hyphens) |
| ACR Repo | `kaas/<esatsid>/<app>/<component>` | `kaas/12345/appa/api` | 256 | Alphanumeric, hyphens, slashes, dots |
| Key Vault | `<org>-<esatsid>-<env>-<region>-kv` | `hr-12345-dev-va-kv` | 24 | Alphanumeric, hyphens |
| Log Analytics | `kaas-<org>-<esatsid>-<env>-<region>-law` | `kaas-cdp-00001-prod-va-law` | 63 | Alphanumeric, hyphens |
| Managed Identity | `kaas-<org>-<env>-<purpose>-<region>-mi` | `kaas-iao-dev-core-va-mi` | 128 | Alphanumeric, hyphens, underscores |
| Service Principal | `kaas-<org>-<env>-<index>-sp` | `kaas-iao-dev-01-sp` | 120 | Alphanumeric, hyphens |
| VNet | `vnet-kaas-<org>-<env>-<region>` | `vnet-kaas-cdp-dev-va` | 64 | Alphanumeric, hyphens, underscores, periods |
| Subnet | `kaas_subnet_<index>` | `kaas_subnet_1` | 80 | Alphanumeric, hyphens, underscores |
| Route Table | `rt-kaas_subnet_<index>` | `rt-kaas_subnet_1` | 80 | Alphanumeric, hyphens, underscores |
| NSG | `nsg-kaas-<org>-<env>-<region>` | `nsg-kaas-cdp-dev-va` | 80 | Alphanumeric, hyphens, underscores |
| Deployment | `<esatsid>-<app>-<component>` | `12345-appa-api` | 63 | Lowercase alphanumeric, hyphens |
| Service | `<esatsid>-<app>-<component>-svc` | `12345-appa-api-svc` | 63 | Lowercase alphanumeric, hyphens |
| Ingress | `<esatsid>-<app>-<component>-ingress` | `12345-appa-web-ingress` | 63 | Lowercase alphanumeric, hyphens |
| ConfigMap | `<esatsid>-<app>-<component>-config` | `12345-appa-api-config` | 253 | Lowercase alphanumeric, hyphens, dots |
| Secret | `<esatsid>-<app>-<component>-secret` | `12345-appa-api-secret` | 253 | Lowercase alphanumeric, hyphens, dots |
| HPA | `<esatsid>-<app>-<component>-hpa` | `12345-appa-api-hpa` | 63 | Lowercase alphanumeric, hyphens |
| KV Secret | `<esatsid>-<app>-<component>-<secret-name>` | `12345-appa-api-db-connection` | 127 | Alphanumeric, hyphens |