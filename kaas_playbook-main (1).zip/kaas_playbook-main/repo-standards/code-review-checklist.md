# 🏛️ Code Review Checklist

## Overview

Every merge request must be reviewed against this checklist before approval. Reviewers are expected to verify correctness, security, and adherence to team standards.

---

## General

- [ ] Code compiles and passes all CI checks
- [ ] Commit messages follow [Conventional Commits](commit-message-policy.md)
- [ ] Branch is up-to-date with target branch (no conflicts)
- [ ] No unnecessary files committed (`.terraform`, `node_modules`, secrets, `.vscode` etc.,)
- [ ] Changes are scoped to the stated purpose — no unrelated modifications

---

## Code Quality

- [ ] Code is readable and self-documenting
- [ ] Functions and variables have meaningful names
- [ ] No duplicated logic reuse existing utilities where possible
- [ ] Error handling is appropriate (no silent failures)
- [ ] No hardcoded values, use variables or configuration
- [ ] Dead code and commented-out blocks are removed

---

## Security

- [ ] No secrets, passwords, or tokens in code or configuration
- [ ] Input validation is applied where data enters the system
- [ ] Authentication and authorization checks are in place
- [ ] Dependencies are pinned to specific versions
- [ ] No known vulnerabilities in new dependencies
- [ ] RBAC follows principle of least privilege

---

## Testing

- [ ] Unit tests cover new logic
- [ ] Integration tests updated if API contracts change
- [ ] Edge cases and error paths are tested
- [ ] Test names clearly describe what is being tested

---

## Documentation

- [ ] README updated if behavior or usage changes
- [ ] CHANGELOG updated for user-facing changes

---

## Reviewer Responsibilities

| Responsibility | Description |
|----------------|-------------|
| Be constructive | Suggest improvements |
| Be timely | Review ASAP  |
| Ask questions | If intent is unclear, ask rather than assume |
| Approve or request changes | Don't leave MRs in limbo |
| Verify CI status if repo required | Ensure pipeline passed before approving |

---

## Approval Requirements

| Target Branch | Minimum Approvals | Required Reviewers |
|---------------|-------------------|--------------------|
| `dev` | 1 | Any team member |
| `preprod` | 1 | Senior engineer or tech lead |
| `main` | 2 | Tech lead + security review (if applicable) |
