# 🏛️ Commit Message Policy

## Overview

All repositories follow the **Conventional Commits** specification to enable automated changelog generation, clear history, and traceability.

---

## Format

```
[<JIRA-ID>]: <type>(<scope>): <subject>

[optional body]

[optional footer(s)]
```

For multiple stories, separate JIRA IDs with commas:

```
[<JIRA-ID>, <JIRA-ID>]: <type>(<scope>): <subject>
```

---

## Types

| Type | Description | Example |
|------|-------------|---------|
| `feat` | A new feature | `[KAS-123]: feat(auth): add SSO login support` |
| `fix` | A bug fix | `[KAS-456]: fix(api): resolve timeout on large payloads` |
| `docs` | Documentation changes only | `[KAS-789]: docs(readme): update setup instructions` |
| `style` | Code style (formatting, no logic change) | `[KAS-101]: style(lint): apply prettier formatting` |
| `refactor` | Code restructuring without behavior change | `[KAS-202]: refactor(db): simplify query builder` |
| `perf` | Performance improvement | `[KAS-303]: perf(cache): reduce Redis round trips` |
| `test` | Adding or updating tests | `[KAS-404]: test(auth): add unit tests for token refresh` |
| `chore` | Maintenance tasks (deps, configs) | `[KAS-505]: chore(deps): bump azurerm to 3.115` |
| `ci` | CI/CD pipeline changes | `[KAS-606]: ci(gitlab): add security scanning stage` |
| `build` | Build system changes | `[KAS-707]: build(docker): optimize multi-stage build` |

---

## Scope

The scope is optional but recommended. It identifies the area of the codebase affected:

- `auth`, `api`, `db`, `ui`, `helm`, `terraform`, `pipeline`, `network`, etc.

---

## Rules

| Rule | Description |
|------|-------------|
| JIRA ID required | Every commit must start with `[JIRA-ID]:` |
| Multiple stories | Comma-separated within brackets: `[KAS-123, KAS-456]:` |
| Imperative mood | Use "add" not "added" or "adds" |
| Lowercase subject | Start the subject line in lowercase |
| No period at end | Do not end the subject with a period |
| Max 72 characters | Subject line (after JIRA prefix) should not exceed 72 characters |
| Body wraps at 80 | Wrap body text at 80 characters |
| Reference issues | Include additional story/issue IDs in the footer if needed |

---

## Footer Keywords

| Keyword | Purpose | Example |
|---------|---------|---------|
| `Refs:` | References a related issue | `Refs: US12345` |
| `Closes:` | Closes an issue on merge | `Closes: #42` |
| `BREAKING CHANGE:` | Indicates a breaking change | `BREAKING CHANGE: removed legacy API endpoint` |

---

## Examples

### Simple commit

```
[KAS-123]: feat(cluster): add OIDC issuer toggle variable
```

### Multiple stories

```
[KAS-123, KAS-456]: feat(auth): add SSO and MFA support
```

### Commit with body

```
[KAS-789]: fix(networking): resolve DNS resolution failure in private cluster

The private DNS zone was not linked to the Hub VNet, causing
nodes to fail API server resolution via Boeing DNS.

Refs: KAS-790
```

### Breaking change

```
[KAS-101]: refactor(api): remove deprecated v1 endpoints

BREAKING CHANGE: /api/v1/* routes have been removed.
Migrate to /api/v2/* before upgrading.

Closes: KAS-102
```

---

## Enforcement

- **Pre-commit hook**: Validates commit message format locally
- **CI pipeline**: Rejects merge requests with non-compliant commits
- **GitLab push rules**: Enforce regex pattern on commit messages

### Regex Pattern

```regex
^\[[A-Z]+-\d+(,\s*[A-Z]+-\d+)*\]:\s(feat|fix|docs|style|refactor|perf|test|chore|ci|build)(\(.+\))?: .{1,72}$
```
