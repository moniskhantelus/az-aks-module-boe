# 🏛️ Branching Strategy

## Overview

All repositories follow a trunk-based development model with environment-aligned branches. 
This strategy supports continuous delivery while maintaining strict controls for production releases.

---

## Branch Hierarchy

```
sandbox_<experiment>  ──┐
sandbox_<yymmdd>      ──┤
                        ▼
                     sandbox  (Platform Engineer experimentation only)


dev_<story>    ──┐
dev_<yymmdd>   ──┤
dev_<feature>  ──┤
                 ▼
                dev  ────────▶  stage  ────────▶  main
                 ▲                ▲                  ▲
                 │                │                  │
             Development      Staging            Production
             (NonProd)        (NonProd)           Environment
```

---

## Protected Branches

| Branch | Purpose | Deploys To | Tag on Merge |
|--------|---------|------------|--------------|
| `main` | Production-ready, release-tagged code | Production | `YY.MM` (CalVer) |
| `stage` | Pre-production validation and integration testing | Stage (NonProd) | — |
| `dev` | Active development integration | Dev (NonProd) | — |
| `sandbox` | Platform Engineer experimentation and prototyping | Sandbox | — |

---

## Working Branches

| Pattern | Purpose | Example |
|---------|---------|---------|
| `sandbox_<experiment>` | Platform infra experimentation | `sandbox_test-cni-overlay` |
| `sandbox_<yymmdd>` | Date-based sandbox snapshot | `sandbox_260623` |
| `sandbox_<description>` | Descriptive experimentation branch | `sandbox_aks-1.30-upgrade` |
| `dev_<story>` | Feature work linked to a user story | `dev_US12345` |
| `dev_<yymmdd>` | Date-based development snapshot | `dev_260623` |
| `dev_<description>` | Descriptive feature branch | `dev_add-ingress-controller` |
| `stage_<story>` | Stage validation for a specific story | `stage_US12345` |
| `stage_<yymmdd>` | Date-based stage release | `stage_260623` |
| `stage_<description>` | Stage branch for a specific feature | `stage_helm-upgrade` |

---

## Branch Rules

| Rule | Enforcement |
|------|-------------|
| No direct commits to `main` | Merge request from `stage` required |
| No direct commits to `stage` | Merge request from `dev` or `dev_*` required |
| No direct commits to `dev` | Merge request from `dev_*` working branches required |
| Sandbox is isolated | `sandbox` does **not** promote to `dev` — it is experimental only |
| Merge request approvals | Minimum 1 approval for all protected branches |
| Branch prefix required | Working branches must start with `sandbox_`, `dev_`, or `stage_` |
| Delete after merge | Feature branches are deleted after successful merge |
| No force push | Disabled on `main`, `stage`, and `dev` |
| Linear history | Rebase-merge preferred over merge commits |

---

## Sandbox Branch Details

> **Audience:** Platform Engineer (K8s Admins) only

The `sandbox` branch and its working branches (`sandbox_*`) are exclusively for platform infrastructure experimentation. They are **isolated** from the promotion pipeline and never merge into `dev`, `stage`, or `main`.

**Use cases:**
- Testing new Terraform modules or AKS configurations
- Experimenting with cluster upgrades, CNI changes, or add-ons
- Validating infrastructure patterns before writing production-ready code
- Breaking things safely without impacting app teams

**Rules:**
- Only Platform Engineers can push to `sandbox` and `sandbox_*` branches
- No application code — infrastructure/platform code only
- No promotion path to `dev` — successful experiments are re-implemented as proper `dev_*` feature branches
- Force push allowed on `sandbox_*` working branches (experimentation flexibility)
- Force push disabled on `sandbox` protected branch
- No SLA on CI/CD — pipelines may be relaxed or optional

---

## Release Tagging (CalVer)

We use **Calendar Versioning** with format `YY.MM[.patch]`:

| Tag | Meaning |
|-----|---------|
| `26.06` | First release in June 2026 |
| `26.06.1` | First hotfix patch in June 2026 |
| `26.07` | First release in July 2026 |

### Rules

- Tags only on `main`
- No `v` prefix — use `26.06` not `v26.06`
- Annotated tags with release message: `git tag -a 26.06 -m "Release 26.06"`
- One primary release per month; patches use `.N` suffix

---

## Hotfix Process

For critical production issues:

```
main  ──────●────────────────●──
            │                ▲
            ▼                │
         hotfix_<id>  ───────┘
         (branch from main, merge back to main + stage + dev)
```

1. Branch from `main` as `hotfix_<description>`
2. Fix and test locally
3. Merge request to `main` (expedited approval)
4. Tag with patch version (e.g., `26.06.1`)
5. Cherry-pick or merge back to `stage` and `dev`

---

## Merge Request Requirements

- Linked to a story or issue
- All CI checks passing
- Code review approved
- No merge conflicts
- Commit messages follow [Commit Message Policy](commit-message-policy.md)
